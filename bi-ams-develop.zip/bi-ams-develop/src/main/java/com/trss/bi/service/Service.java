package com.trss.bi.service;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.security.SecurityUtils;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.Instant;
import java.util.Optional;

/**
 *
 * @param <Model>
 */
public abstract class Service<Model extends AbstractAuditingEntity> {

    public MongoRepository<Model, ObjectId> repository;

    /**
     * Classes which override this class must call super AND use @Autowired within in their constructor
     * @param repository
     */
    public Service(MongoRepository<Model, ObjectId> repository) {
        this.repository = repository;
    }

    /**
     * This method should be used in order to ensure the accuracy of the created date, created by, last modified by, and last modified date fields when saving.
     * Note -- this method only needs to be invoked if we are saving the model from a resource payload
     * @param model
     * @param id
     * @return saved model
     */
    public Model save(Model model, ObjectId id) {
        Optional<Model> toUpdate = id == null ? Optional.empty() : repository.findById(id);

        // createdDate
        if (!toUpdate.isPresent() || toUpdate.get().getCreatedDate() == null) {
            model.setCreatedDate(Instant.now());
        } else {
            model.setCreatedDate(toUpdate.get().getCreatedDate());
        }

        // createdBy
        if (toUpdate.isPresent() && toUpdate.get().getCreatedBy() != null) {
            model.setCreatedBy(toUpdate.get().getCreatedBy());
        } else {
            model.setCreatedBy(SecurityUtils.getCurrentUserLogin().orElse("Unknown User"));
        }

        // lastModifiedDate
        model.setLastModifiedDate(Instant.now());

        // lastModifiedBy
        model.setLastModifiedBy(SecurityUtils.getCurrentUserLogin().orElse("Unknown User"));

        return repository.save(model);
    }

}
