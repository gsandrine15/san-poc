package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.NewsroomPublisher;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@ChangeLog(order = "010")
public class NewsroomPublisherSetup {

    @ChangeSet(order = "01", author = "admin", id = "010-01-populate-initial-newroom-publishers")
    public void populateInitialNewsroomPublishers(MongoTemplate mongoTemplate) throws IOException {
        BufferedReader fileReader = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/newsroom/publishers.csv"), "UTF-8"));
        CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT);
        Iterable<CSVRecord> csvRecords = csvParser.getRecords();
        for (CSVRecord csvRecord : csvRecords) {
            NewsroomPublisher publisher = new NewsroomPublisher();
            publisher.setJournalCode(csvRecord.get(0));
            publisher.setJournalName(csvRecord.get(1));
            publisher.setStatus(csvRecord.get(2));
            publisher.setIpProductName(csvRecord.get(3));
            publisher.setPubCode(csvRecord.get(4));
            publisher.setType(csvRecord.get(5));
            mongoTemplate.save(publisher);
        }
    }
}
