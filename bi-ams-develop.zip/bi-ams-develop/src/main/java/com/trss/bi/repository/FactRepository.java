package com.trss.bi.repository;

import com.trss.bi.domain.fact.Fact;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface FactRepository extends MongoRepository<Fact, ObjectId> {
    public Fact findByFeedRouterId(String feedRouterId);
    public List<Fact> findAllByCreatedDateLessThan(Instant createdDate);

    public Long deleteAllByIdIn(List<ObjectId> factIds);
}
