package com.trss.bi.config;

import com.trss.bi.service.errors.NewsroomApiResponseErrorHandler;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

/**
 * Spring RestTemplate configuration.
 */
@Configuration
public class RestTemplateConfiguration {

    @Bean
    public RestTemplate newsroomRestTemplate(RestTemplateBuilder restTemplateBuilder) {
        return restTemplateBuilder.errorHandler(new NewsroomApiResponseErrorHandler()).build();
    }
}
