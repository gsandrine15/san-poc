package com.trss.bi.service;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import com.trss.bi.repository.TaxonomyNodeRepository;
import com.trss.bi.repository.TaxonomyRepository;
import com.trss.bi.service.dto.TaxonomyNodeDTO;
import com.trss.bi.service.mapper.TaxonomyNodeMapper;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class TaxonomyNodeService {

    private TaxonomyRepository taxonomyRepository;
    private TaxonomyNodeRepository taxonomyNodeRepository;
    private TaxonomyNodeMapper taxonomyNodeMapper = new TaxonomyNodeMapper();

    public TaxonomyNodeService(TaxonomyRepository taxonomyRepository, TaxonomyNodeRepository taxonomyNodeRepository) {
        this.taxonomyRepository = taxonomyRepository;
        this.taxonomyNodeRepository = taxonomyNodeRepository;
    }

    public List<TaxonomyNode> findAllByTaxonomyCode(String taxonomyCode) {
        Taxonomy taxonomy = taxonomyRepository.findByCode(taxonomyCode);
        if (taxonomy == null) {
            throw new RuntimeException("No taxonomy found for code: '" + taxonomyCode + "'");
        }

        return taxonomyNodeRepository.findAllByTaxonomyId(taxonomy.getId());
    }

    public List<TaxonomyNodeDTO> findAllSortedByTaxonomyCode(String taxonomyCode) {
        List<TaxonomyNode> allNodes = findAllByTaxonomyCode(taxonomyCode);
        List<TaxonomyNode> sortedNodes = new ArrayList<>();

        // find the root
        TaxonomyNode rootNode = allNodes.stream()
            .filter(TaxonomyNode::isRoot).findFirst()
            .orElseThrow(() -> new RuntimeException("No Root Node found in taxonomy"));

        // build the rest of the tree
        addNode(rootNode, allNodes, sortedNodes);

        // remove the root node before returning since there's nothing to display
        sortedNodes.remove(rootNode);

        return taxonomyNodeMapper.toDto(sortedNodes);
    }

    public void addNode(TaxonomyNode currentNode, List<TaxonomyNode> allNodes, List<TaxonomyNode> sortedNodes) {
        sortedNodes.add(currentNode);
        allNodes.remove(currentNode);

        if (currentNode.hasChildren()) {
            List<TaxonomyNode> childNodes = allNodes.stream().filter(n -> currentNode.getChildNodeIds().contains(n.getId())).collect(Collectors.toList());

            for(TaxonomyNode taxonomyNode : childNodes) {
                addNode(taxonomyNode, allNodes, sortedNodes);
            }
        }
    }

    public Optional<TaxonomyNode> findByUri(String uri) {
        return taxonomyNodeRepository.findByUri(uri);
    }

    public Map<String, String> getUriDisplayName () {
        return findAllByTaxonomyCode("RISK")
            .stream()
            .filter(n -> !n.isRoot()) // remove the root node
            .collect(Collectors.toMap(TaxonomyNode::getUri, TaxonomyNode::getDisplayName));
        // if we ever have null values, the above will fail due to an OpenJDK bug, and we'll need to switch to the below collect()
        //.collect(HashMap::new, (m, v) -> m.put(v.getUri(), v.getDisplayName()), HashMap::putAll);
    }
}
