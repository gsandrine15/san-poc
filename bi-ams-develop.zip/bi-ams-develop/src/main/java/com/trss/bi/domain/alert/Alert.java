package com.trss.bi.domain.alert;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.domain.factinstance.FactInstance;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "alert")
public class Alert extends AbstractAuditingEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private ObjectId id;

    private String clientEntityId;
    private Long customerId;

    private ClientEntity clientEntity;

    private List<FactInstance> factInstances = new ArrayList<>();

    private String analystNotes = "";
    private String clientNotes = "";

    // TODO: enum for valid values
    private String severity = "Critical";

    public void addFactInstance(FactInstance factInstance) {
        factInstances.add(factInstance);
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getClientEntityId() {
        return clientEntityId;
    }

    public void setClientEntityId(String clientEntityId) {
        this.clientEntityId = clientEntityId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public ClientEntity getClientEntity() {
        return clientEntity;
    }

    public void setClientEntity(ClientEntity clientEntity) {
        this.clientEntity = clientEntity;
    }

    public List<FactInstance> getFactInstances() {
        return factInstances;
    }

    public void setFactInstances(List<FactInstance> factInstances) {
        this.factInstances = factInstances;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getClientNotes() {
        return clientNotes;
    }

    public void setClientNotes(String clientNotes) {
        this.clientNotes = clientNotes;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }
}
