package com.trss.bi.web.rest;

import com.trss.bi.service.HistoricalFactInstanceService;
import com.trss.bi.service.dto.HistoricalFactInstanceDTO;
import com.trss.bi.service.dto.HistoricalFactInstanceFilterDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static com.trss.bi.security.AuthorizationConstants.ACCESS_TRASH;

@RestController
@PreAuthorize(ACCESS_TRASH)
@RequestMapping("/api")
public class HistoricalFactInstanceResource {

    private HistoricalFactInstanceService historicalFactInstanceService;

    public HistoricalFactInstanceResource(HistoricalFactInstanceService historicalFactInstanceService) {
        this.historicalFactInstanceService = historicalFactInstanceService;
    }

    @PostMapping("/historical-alerts")
    public Page<HistoricalFactInstanceDTO> getFactInstances(Pageable pageable, @RequestBody HistoricalFactInstanceFilterDTO filters) {
        return historicalFactInstanceService.findHistoricalFactInstances(pageable, filters);
    }

    @PostMapping("/historical-alerts/search/entity-names")
    public List<String> searchClientEntityNamesByNameSubstring(@RequestBody Map<String, String> params) {
        return historicalFactInstanceService.findClientEntityNamesByNameSubstring(params.get("nameSubstring").toLowerCase());
    }

    @PostMapping("historical-alerts/move/inbox")
    public void moveInstanceToInbox(@RequestBody Map<String, String> params) {
        historicalFactInstanceService.sendToInbox(params.get("factId"), params.get("queueId"));
    }

    @PostMapping("historical-alerts/move/outbox")
    public void moveInstanceToOutbox(@RequestBody Map<String, String> params) {
        historicalFactInstanceService.sendToOutbox(params.get("factId"), Boolean.valueOf(params.get("overwriteNotes")));
    }

    @GetMapping("/historical-alerts/risks")
    public List getDistinctRisks() {
        return historicalFactInstanceService.findDistinctRisks();
    }

    @GetMapping("/historical-alerts/predicates")
    public List getDistinctPredicates() {
        return historicalFactInstanceService.findDistinctPredicates();
    }

    @GetMapping("/historical-alerts/resolutions")
    public List getDistinctResolutions() {
        return historicalFactInstanceService.findDistinctResolutions();
    }

    @GetMapping("/historical-alerts/screeners")
    public List getDistinctScreeners() {
        return historicalFactInstanceService.findDistinctScreeners();
    }

}
