package com.trss.bi.service.dto;

import com.trss.bi.domain.factinstance.ClientEntity;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

public class AlertDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String clientEntityId;
    private Long customerId;
    private ClientEntity clientEntity;
    private List<FactInstanceDTO> factInstances;
    private String analystNotes;
    private String clientNotes;
    private String severity;
    private Instant createdDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClientEntityId() {
        return clientEntityId;
    }

    public void setClientEntityId(String clientEntityId) {
        this.clientEntityId = clientEntityId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public ClientEntity getClientEntity() {
        return clientEntity;
    }

    public void setClientEntity(ClientEntity clientEntity) {
        this.clientEntity = clientEntity;
    }

    public List<FactInstanceDTO> getFactInstances() {
        return factInstances;
    }

    public void setFactInstances(List<FactInstanceDTO> factInstances) {
        this.factInstances = factInstances;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getClientNotes() {
        return clientNotes;
    }

    public void setClientNotes(String clientNotes) {
        this.clientNotes = clientNotes;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }
}
