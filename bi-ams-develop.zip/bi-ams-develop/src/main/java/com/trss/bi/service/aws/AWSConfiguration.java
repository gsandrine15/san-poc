package com.trss.bi.service.aws;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AWSConfiguration {

    @Value("${aws.sns.accessKeyId}")
    private String snsAccessKey;

    @Value("${aws.sns.secretKey}")
    private String snsSecretKey;

    @Value("${aws.dynamo.accessKeyId}")
    private String dynamoAccessKey;

    @Value("${aws.dynamo.secretKey}")
    private String dynamoSecretKey;

    @Bean
    public AmazonDynamoDB dynamoDBClient() {
        AmazonDynamoDBClientBuilder builder = AmazonDynamoDBClientBuilder.standard();
        builder.withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(dynamoAccessKey, dynamoSecretKey)));
        builder.withRegion(Regions.US_EAST_1);
        return builder.build();
    }
    @Bean
    public AmazonSNS snsClient() {
        AmazonSNSClientBuilder builder = AmazonSNSClientBuilder.standard();
        builder.withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(snsAccessKey, snsSecretKey)));
        builder.withRegion(Regions.US_EAST_1);
        return builder.build();
    }
}
