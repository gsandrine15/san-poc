package com.trss.bi.web.rest;

import com.trss.bi.service.AmsFeedbackService;
import com.trss.bi.service.dto.feedback.AmsFeedbackDTO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * API for accepting AMS feedback and forwarding it to AWS.
 */
@RestController
@RequestMapping("/api")
public class FeedbackResource {

    protected AmsFeedbackService amsFeedbackService;

    /**
     * Constructor.
     *
     * @param amsFeedbackService AmsFeedbackService
     */
    public FeedbackResource(AmsFeedbackService amsFeedbackService) {
        this.amsFeedbackService = amsFeedbackService;
    }

    @PostMapping("/feedback")
    public void postFactQueue(@RequestBody AmsFeedbackDTO amsFeedbackDTO) {
        amsFeedbackService.publishFeedback(amsFeedbackDTO);
    }
}
