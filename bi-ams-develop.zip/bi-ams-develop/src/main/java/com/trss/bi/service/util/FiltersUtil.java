package com.trss.bi.service.util;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FiltersUtil {

    public static final String PARAM_RISKS = "risks";
    public static final String PARAM_PREDICATES = "predicates";
    public static final String PARAM_ENTITY_TYPES = "entityTypes";
    public static final String PARAM_MINIMUM_CONFIDENCE_SCORE = "minimumConfidenceScore";
    public static final String PARAM_FLAG = "flag";
    public static final String PARAM_ENTITIES = "entities";

    public static final String PERSON = "person";
    public static final String COMPANY = "company";

    public static List<String> getRiskFilterValues(Map<String, String> filters) {
        return FiltersUtil.getFilterValues(filters.get(PARAM_RISKS));
    }

    public static List<String> getPredicateFilterValues(Map<String, String> filters) {
        return FiltersUtil.getFilterValues(filters.get(PARAM_PREDICATES));
    }

    public static Boolean getFlagFilterValue(Map<String, String> filters) {
        return !FiltersUtil.getFilterValues(filters.get(PARAM_FLAG)).isEmpty();
    }

    public static List<String> getEntitiesFilterValue(Map<String, String> filters) {
        return FiltersUtil.getFilterValues(filters.get(PARAM_ENTITIES));
    }

    public static Double getMinimumConfidenceScoreValue(Map<String, String> filters) {
        String value = filters.get(PARAM_MINIMUM_CONFIDENCE_SCORE);
        if (StringUtils.isNotBlank(value)) {
            return Double.valueOf(value);
        }
        return 0.0;
    }

    public static List<String> getFilterValues(String filtersString) {
        List<String> values = new ArrayList<>();
        if (filtersString != null) {
            values = Arrays.stream(filtersString.split(",")).filter(v -> v.length() > 0).collect(Collectors.toList());
        }

        return values;
    }

    public static List<String> getEntityTypeFilters(Map<String, String> filters) {
        Boolean individualsFilter = getEntityByType(filters, PERSON);
        Boolean organizationsFilter = getEntityByType(filters, COMPANY);

        List<String> entityTypeFilters = new ArrayList<>();

        if(individualsFilter) {
            entityTypeFilters.add(PERSON);
        }
        if(organizationsFilter) {
            entityTypeFilters.add(COMPANY);
        }
        return entityTypeFilters;
    }

    private static Boolean getEntityByType(Map<String, String> filters, String type) {
        return FiltersUtil.getFilterValues(filters.get(PARAM_ENTITY_TYPES)).stream().anyMatch(value -> value.equals(type));
    }
}
