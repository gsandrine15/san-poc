package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.FactQueue;
import com.trss.bi.domain.alert.Alert;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.domain.factinstance.HistoricalFactInstance;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

@ChangeLog(order = "008")
public class MultitenancyUpdates {

    @ChangeSet(order = "01", author = "admin", id = "008-01-add-customer-ids-to-alerts")
    public void addCustomerIdToAlerts(MongoTemplate mongoTemplate){
        List<Alert> alerts = mongoTemplate.findAll(Alert.class);
        for (Alert alert : alerts) {
            if (alert.getCustomerId() == null) {
                alert.setCustomerId(1L); // default to TRSS customerId
                mongoTemplate.save(alert);
            }
        }
    }

    @ChangeSet(order = "02", author = "admin", id = "008-02-add-customer-ids-to-historical-fact-instances")
    public void addCustomerIdToHistoricalFactInstances(MongoTemplate mongoTemplate){
        List<HistoricalFactInstance> historicalFactInstances = mongoTemplate.findAll(HistoricalFactInstance.class);
        for (HistoricalFactInstance historicalFactInstance : historicalFactInstances) {
            if (historicalFactInstance.getCustomerId() == null) {
                historicalFactInstance.setCustomerId(1L); // default to TRSS customerId
                mongoTemplate.save(historicalFactInstance);
            }
        }
    }
}
