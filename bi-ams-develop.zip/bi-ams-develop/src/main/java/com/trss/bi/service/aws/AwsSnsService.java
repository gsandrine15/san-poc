package com.trss.bi.service.aws;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Service to interact with AWS SQS resources.
 */
@Service
public class AwsSnsService {

    protected AmazonSNS amazonSNSClient;

    /**
     * Constructor.
     */
    public AwsSnsService() {
        amazonSNSClient = AmazonSNSClientBuilder.standard().build();
    }

    /**
     * Publish a message to a SNS topic.
     *
     * @param topicArn The SNS topic arn
     * @param message The message to publish
     * @param messageAttributes The message attributes
     * @return The PublishResult
     */
    public PublishResult publishTopicMessage(String topicArn, String message, Map<String,
            MessageAttributeValue> messageAttributes) {
        PublishRequest publishRequest = new PublishRequest(topicArn, message);
        publishRequest.setMessageAttributes(messageAttributes);
        return amazonSNSClient.publish(publishRequest);
    }

}
