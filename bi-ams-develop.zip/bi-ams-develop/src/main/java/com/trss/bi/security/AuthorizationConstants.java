package com.trss.bi.security;

import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;
import org.mapstruct.ap.internal.util.Collections;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;

/**
 * Constants for Spring Security authorizations.
 */
public final class AuthorizationConstants {

    public static final String ADMIN = "ADMIN";

    public static final String CUSTOMER_ADMIN = "CUSTOMER_ADMIN";

    public static final String USER = "USER";

    public static final String ANONYMOUS = "ANONYMOUS";

    public static final String ACCESS_ADMIN = "hasAnyRole('" + ADMIN + "')";

    public static final String ACCESS_INBOX = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAuthority('INBOX')";

    public static final String ACCESS_VIEW_FOLDERS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('INBOX_VIEW_MY_FOLDERS', 'INBOX_VIEW_ALL_FOLDERS')";

    public static final String ACCESS_EDIT_FACTS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('INBOX_EDIT_MY_FACTS', 'INBOX_EDIT_ALL_FACTS')";

    public static final String ACCESS_PROVIDE_FEEDBACK = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('INBOX_PROVIDE_FEEDBACK')";

    public static final String ACCESS_RESOLVE_FACTS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('INBOX_RESOLVE_ALL_FACTS', 'INBOX_RESOLVE_MY_FACTS')";

    public static final String ACCESS_ADMIN_TOOLS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN + "') or hasAnyAuthority('ADMIN_TOOLS')";

    public static final String ACCESS_EDIT_FOLDERS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAuthority('INBOX_EDIT_FOLDERS')";

    public static final String ACCESS_CREATE_FOLDERS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAuthority('INBOX_CREATE_FOLDERS')";

    public static final String ACCESS_DELETE_FOLDERS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('INBOX_DELETE_FOLDERS')";

    public static final String ACCESS_SEARCH = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('SEARCH')";

    public static final String ACCESS_EDIT_ALERTS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('OUTBOX_EDIT_ALERTS')";

    public static final String ACCESS_REMOVE_ALERTS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('OUTBOX_REMOVE_ALERTS')";

    public static final String ACCESS_EXPORT_ALERTS = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('OUTBOX_EXPORT_ALERTS')";

    public static final String ACCESS_OUTBOX = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('OUTBOX')";

    public static final String ACCESS_TRASH = "hasAnyRole('" + ADMIN + "', '" + CUSTOMER_ADMIN +"', '"+ USER + "') or hasAnyAuthority('TRASH')";

    private AuthorizationConstants() {
    }
}
