package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.config.dbmigrations.risktaxonomy.*;
import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

@ChangeLog(order = "001")
public class RiskTaxonomySetup {
    @ChangeSet(order = "01", author = "admin", id = "01-taxonomy")
    public void createRiskTaxonomy(MongoTemplate mongoTemplate) {
        Taxonomy taxonomy = new Taxonomy();
        taxonomy.setCode("RISK");
        taxonomy.setName("Risk Taxonomy");
        taxonomy.setDescription("The initial version of the risk taxonomy that mirrors the Reuters taxonomy.");
        taxonomy.setVersion("1.0");

        mongoTemplate.insert(taxonomy);
    }

    @ChangeSet(order = "02", author= "admin", id = "02-root")
    public void createRiskTaxonomyLevel1(MongoTemplate mongoTemplate) {
        Taxonomy taxonomy = new TaxonomySetupHelper(mongoTemplate).getTaxonomy();

        TaxonomyNode taxonomyNode = new TaxonomyNode();
        taxonomyNode.setCode("ROOT");
        taxonomyNode.setTaxonomyId(taxonomy.getId());

        mongoTemplate.insert(taxonomyNode);
    }

    @ChangeSet(order = "03", author= "admin", id = "03-other")
    public void createOther(MongoTemplate mongoTemplate) {
        OtherHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "04", author= "admin", id = "04-corporate-crime")
    public void createCorporateCrime(MongoTemplate mongoTemplate) {
        CorporateCrimeHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "05", author= "admin", id = "05-non-corporate-crime")
    public void createNonCorporateCrime(MongoTemplate mongoTemplate) {
        NonCorporateCrimeHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "06", author= "admin", id = "06-taxation")
    public void createTaxation(MongoTemplate mongoTemplate) {
        TaxationHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "07", author= "admin", id = "07-legalaction")
    public void createLegalAction(MongoTemplate mongoTemplate) {
        LegalActionHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "08", author= "admin", id = "08-itissues")
    public void createITIssues(MongoTemplate mongoTemplate) {
        ITIssuesHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "09", author= "admin", id = "09-political")
    public void createPolitical(MongoTemplate mongoTemplate) {
        PoliticalHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "10", author= "admin", id = "10-sanctioned")
    public void createSanctioned(MongoTemplate mongoTemplate) {
        SanctionedHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "11", author= "admin", id = "11-ethicalissues")
    public void createEthicalIssues(MongoTemplate mongoTemplate) {
        EthicalIssuesHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "12", author= "admin", id = "12-productfaults")
    public void createProductFaults(MongoTemplate mongoTemplate) {
        ProductFaultsHelper.create(mongoTemplate);
    }
}
