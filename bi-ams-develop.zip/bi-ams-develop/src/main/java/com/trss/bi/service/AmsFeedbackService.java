package com.trss.bi.service;

import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.trss.bi.service.aws.AwsSnsService;
import com.trss.bi.service.dto.feedback.AmsFeedbackDTO;
import com.trss.bi.service.dto.feedback.EntityMatcherFeedbackDTO;
import com.trss.bi.service.dto.feedback.MediaScreenerFeedbackDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service for handling AMS feedback.
 */
@Service
public class AmsFeedbackService {

    protected static final Gson gson = new GsonBuilder().create();

    @Value("${feedback.snsTopicArn}")
    protected String feedbackSnsArn;

    protected AwsSnsService awsSnsService;

    /**
     * Constructor.
     *
     * @param awsSnsService The SNS service
     */
    public AmsFeedbackService(AwsSnsService awsSnsService) {
        this.awsSnsService = awsSnsService;
    }

    /**
     * Publish feedback to SNS.
     *
     * @param amsFeedbackDTO The feedback
     * @return PublishResult
     */
    public List<PublishResult> publishFeedback(AmsFeedbackDTO amsFeedbackDTO) {
        List<PublishResult> publishResultList = new ArrayList<>();

        MediaScreenerFeedbackDTO mediaScreenerFeedback = amsFeedbackDTO.getMediaScreenerFeedback();
        if(mediaScreenerFeedback!= null) {
            String msJson = gson.toJson(mediaScreenerFeedback);

            Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();
            MessageAttributeValue typeMessageAttribute = new MessageAttributeValue()
                .withDataType("String")
                .withStringValue("MEDIA_SCREENER");
            messageAttributes.put("feedback_type", typeMessageAttribute);

            publishResultList.add(awsSnsService.publishTopicMessage(feedbackSnsArn, msJson, messageAttributes));
        }

        EntityMatcherFeedbackDTO entityMatcherFeedback = amsFeedbackDTO.getEntityMatcherFeedback();
        if(entityMatcherFeedback != null) {
            String emJson = gson.toJson(entityMatcherFeedback);

            Map<String, MessageAttributeValue> messageAttributes = new HashMap<>();
            MessageAttributeValue typeMessageAttribute = new MessageAttributeValue()
                .withDataType("String")
                .withStringValue("ENTITY_MATCHER");
            messageAttributes.put("feedback_type", typeMessageAttribute);

            publishResultList.add(awsSnsService.publishTopicMessage(feedbackSnsArn, emJson, messageAttributes));
        }

        return publishResultList;
    }

}
