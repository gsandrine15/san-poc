package com.trss.bi.service.dto;

import com.trss.bi.domain.NewsroomPublisher;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

/**
 * DTO for Newsroom API response article data.
 */
public class ArticleTextDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String articleTitle;
    private Instant publishedDate;
    private String articleHtml;
    private String articleSummaryHtml;
    private String journalName;
    private String url;
    private String errorMessage;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public Instant getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Instant publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getArticleHtml() {
        return articleHtml;
    }

    public void setArticleHtml(String articleHtml) {
        this.articleHtml = articleHtml;
    }

    public String getArticleSummaryHtml() {
        return articleSummaryHtml;
    }

    public void setArticleSummaryHtml(String articleSummaryHtml) {
        this.articleSummaryHtml = articleSummaryHtml;
    }

    public String getJournalName() {
        return journalName;
    }

    public void setJournalName(String journalName) {
        this.journalName = journalName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ArticleTextDTO that = (ArticleTextDTO) o;
        return Objects.equals(id, that.id) &&
            Objects.equals(articleTitle, that.articleTitle) &&
            Objects.equals(publishedDate, that.publishedDate) &&
            Objects.equals(articleHtml, that.articleHtml) &&
            Objects.equals(articleSummaryHtml, that.articleSummaryHtml) &&
            Objects.equals(journalName, that.journalName) &&
            Objects.equals(url, that.url) &&
            Objects.equals(errorMessage, that.errorMessage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, articleTitle, publishedDate, articleHtml, articleSummaryHtml, journalName, url, errorMessage);
    }

    @Override
    public String toString() {
        return "ArticleTextDTO{" +
            "id='" + id + '\'' +
            ", articleTitle='" + articleTitle + '\'' +
            ", publishedDate=" + publishedDate +
            ", articleHtml='" + articleHtml + '\'' +
            ", articleSummaryHtml='" + articleSummaryHtml + '\'' +
            ", journalName='" + journalName + '\'' +
            ", url='" + url + '\'' +
            ", errorMessage='" + errorMessage + '\'' +
            '}';
    }
}
