package com.trss.bi.service.mapper;

import com.trss.bi.domain.FactQueue;
import com.trss.bi.service.dto.FactQueueDTO;
import org.bson.types.ObjectId;

//@Mapper(componentModel = "spring", uses = {})
public class FactQueueMapper extends BaseEntityMapper<FactQueueDTO, FactQueue> {

    @Override
    public FactQueue toEntity(FactQueueDTO dto) {
        if (dto == null) {
            return null;
        } else {
            FactQueue entity = new FactQueue();
            if (dto.getId() != null) {
                entity.setId(new ObjectId(dto.getId()));
            }

            entity.setFactQueueConfigId(dto.getFactQueueConfigId());
            entity.setName(dto.getName());
            entity.setDescription(dto.getDescription());
            entity.setOwnerId(dto.getOwnerId());
            entity.setOwnerUsername(dto.getOwnerUsername());
            entity.setCustomerId(dto.getCustomerId());
            entity.setIsFavorite(dto.getIsFavorite());
            entity.setCreatedDate(dto.getCreatedDate());

            return entity;
        }
    }

    @Override
    public FactQueueDTO toDto(FactQueue entity) {
        if (entity == null) {
            return null;
        } else {
            FactQueueDTO dto = new FactQueueDTO();
            if (entity.getId() != null) {
                dto.setId(entity.getId().toString());
            }

            dto.setFactQueueConfigId(entity.getFactQueueConfigId());
            dto.setName(entity.getName());
            dto.setDescription(entity.getDescription());
            dto.setOwnerId(entity.getOwnerId());
            dto.setOwnerUsername(entity.getOwnerUsername());
            dto.setCustomerId(entity.getCustomerId());
            dto.setIsFavorite(entity.getIsFavorite());
            dto.setCreatedDate(entity.getCreatedDate());
            dto.setLastModifiedDate(entity.getLastModifiedDate());

            return dto;
        }
    }
}
