package com.trss.bi.domain.factinstance;

import com.trss.bi.domain.AbstractAuditingEntity;

import java.io.Serializable;
import java.util.List;

public class RiskItem extends AbstractAuditingEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<ClientEntity> entities; // or full entity info?
    private String riskTaxonomyNodeId; // or full risk taxonomy nodes?

    public List<ClientEntity> getEntities() {
        return entities;
    }

    public void setEntities(List<ClientEntity> entities) {
        this.entities = entities;
    }

    public String getRiskTaxonomyNodeId() {
        return riskTaxonomyNodeId;
    }

    public void setRiskTaxonomyNodeId(String riskTaxonomyNodeId) {
        this.riskTaxonomyNodeId = riskTaxonomyNodeId;
    }
}
