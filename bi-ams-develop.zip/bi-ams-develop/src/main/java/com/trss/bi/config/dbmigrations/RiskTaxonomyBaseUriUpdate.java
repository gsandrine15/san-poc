package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.alert.Alert;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

@ChangeLog(order = "002")
public class RiskTaxonomyBaseUriUpdate {

    private static final String OLD_BASE_URI = "graph.mediascreener.com";
    private static final String NEW_BASE_URI = "graph.thomsonreuters.com";

    private static final String OLD_HTTP = "http://";
    private static final String NEW_HTTP = "https://";

    @ChangeSet(order = "01", author = "admin", id = "002-01-base-uri-update")
    public void baseUriUpdate(MongoTemplate mongoTemplate) {
        updateBaseUri(mongoTemplate, OLD_BASE_URI, NEW_BASE_URI);
    }

    public static void updateBaseUri(MongoTemplate mongoTemplate, String oldValue, String newValue) {
        // update the taxonomy nodes themselves
        List<TaxonomyNode> taxonomyNodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : taxonomyNodes) {
            if (node.getUri() != null) {
                node.setUri(node.getUri().replace(oldValue, newValue));
                mongoTemplate.save(node);
            }
        }

        // update the fact instances
        List<FactInstance> factInstances = mongoTemplate.findAll(FactInstance.class);
        for (FactInstance factInstance : factInstances) {
            if (factInstance.getRiskTaxonomyNodeId() != null) {
                factInstance.setRiskTaxonomyNodeId(factInstance.getRiskTaxonomyNodeId().replace(oldValue, newValue));
                mongoTemplate.save(factInstance);
            }
        }

        // update the facts
        List<Fact> facts = mongoTemplate.findAll(Fact.class);
        for (Fact fact : facts) {
            if (fact.getRiskTaxonomyNodeId() != null) {
                fact.setRiskTaxonomyNodeId(fact.getRiskTaxonomyNodeId().replace(oldValue, newValue));
                mongoTemplate.save(fact);
            }
        }

        // update the alerts
        List<Alert> alerts = mongoTemplate.findAll(Alert.class);
        for (Alert alert : alerts) {
            for (FactInstance factInstance : alert.getFactInstances()) {
                factInstance.setRiskTaxonomyNodeId(factInstance.getRiskTaxonomyNodeId().replace(oldValue, newValue));
            }
            mongoTemplate.save(alert);
        }
    }

    @ChangeSet(order = "02", author = "admin", id = "002-02-http-https")
    public void httpsUpdate(MongoTemplate mongoTemplate) {
        updateBaseUri(mongoTemplate, OLD_HTTP, NEW_HTTP);
    }
}
