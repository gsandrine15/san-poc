package com.trss.bi.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.annotation.RabbitListenerConfigurer;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistrar;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.handler.annotation.support.DefaultMessageHandlerMethodFactory;
import org.springframework.messaging.handler.annotation.support.MessageHandlerMethodFactory;

@Configuration
public class RabbitConfiguration implements RabbitListenerConfigurer {
    /*
     * Fact Feed
     */
    public final static String KEY_FACT_FEED = "ai2.fact-feed";

    @Bean
    public DirectExchange factFeedExchange(@Value("${rabbit.fact-feed.exchange}") String exchange) {
        return new DirectExchange(exchange);
    }

    @Bean
    Queue factFeedQueue(@Value("${rabbit.fact-feed.queue}") String queueName,
                        @Value("${rabbit.fact-feed.exchange}") String exchange) {
        return QueueBuilder.durable(queueName)
            .withArgument("x-dead-letter-exchange", deadLetterExchangeName(exchange))
            .withArgument("x-dead-letter-routing-key", KEY_FACT_FEED_DEAD)
            .build();
    }

    @Bean
    Binding factFeedQueueBinding(@Qualifier("factFeedQueue") Queue queue, @Qualifier("factFeedExchange") DirectExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(KEY_FACT_FEED);
    }

    /*
     * Fact Feed DLQ
     */
    public final static String KEY_FACT_FEED_DEAD = "ai2.fact-feed.dead";

    @Bean
    public DirectExchange factFeedDlqExchange(@Value("${rabbit.fact-feed.exchange}") String exchange) {
        return new DirectExchange(deadLetterExchangeName(exchange));
    }

    @Bean
    Queue factFeedDlqQueue(@Value("${rabbit.fact-feed.queue}") String queueName) {
        return QueueBuilder.durable(deadLetterQueueName(queueName)).build();
    }

    @Bean
    Binding factFeedQueueDlqBinding(@Qualifier("factFeedDlqQueue") Queue queue, @Qualifier("factFeedDlqExchange") DirectExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(KEY_FACT_FEED_DEAD);
    }

    /*
     * Delete Fact Instances
     */
    public final static String KEY_FACT_INSTANCE_DELETE = "ai2.fact-instance.delete";

    @Bean
    public DirectExchange factInstanceDeleteExchange(@Value("${rabbit.fact-instance.delete.exchange}") String exchange) {
        return new DirectExchange(exchange);
    }

    @Bean
    Queue factInstanceDeleteQueue(@Value("${rabbit.fact-instance.delete.queue}") String queueName,
                                  @Value("${rabbit.fact-instance.delete.exchange}") String exchange) {
        return QueueBuilder.durable(queueName)
            .withArgument("x-dead-letter-exchange", deadLetterExchangeName(exchange))
            .withArgument("x-dead-letter-routing-key", KEY_FACT_INSTANCE_DELETE_DEAD)
            .build();
    }

    @Bean
    Binding factInstanceDeleteBinding(@Qualifier("factInstanceDeleteQueue") Queue queue, @Qualifier("factInstanceDeleteExchange") DirectExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(KEY_FACT_INSTANCE_DELETE);
    }

    /*
     * Delete Fact Queue DLQ
     */
    public final static String KEY_FACT_INSTANCE_DELETE_DEAD = "ai2.fact-instance.delete.dead";

    @Bean
    public DirectExchange factInstanceDeleteDlqExchange(@Value("${rabbit.fact-instance.delete.exchange}") String exchange) {
        return new DirectExchange(deadLetterExchangeName(exchange));
    }

    @Bean
    Queue factInstanceDeleteDlqQueue(@Value("${rabbit.fact-instance.delete.queue}") String queueName) {
        return QueueBuilder.durable(deadLetterQueueName(queueName)).build();
    }

    @Bean
    Binding factInstanceDeleteDlqBinding(@Qualifier("factInstanceDeleteDlqQueue") Queue queue, @Qualifier("factInstanceDeleteDlqExchange") DirectExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(KEY_FACT_INSTANCE_DELETE_DEAD);
    }

    /*
     * Beans to support Listener / JSON mappings
     */
    @Bean
    public RabbitTemplate rabbitTemplate(final ConnectionFactory connectionFactory) {
        final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(producerJackson2MessageConverter());
        return rabbitTemplate;
    }

    @Bean
    public Jackson2JsonMessageConverter producerJackson2MessageConverter() {
        // Create object mapper and register modules for java8 datatypes (Instant)
        ObjectMapper objectMapper = new ObjectMapper();
//            .serializerByType(ObjectId.class, new ToStringSerializer());

        objectMapper.findAndRegisterModules();
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    @Bean
    MessageHandlerMethodFactory messageHandlerMethodFactory() {
        DefaultMessageHandlerMethodFactory messageHandlerMethodFactory = new DefaultMessageHandlerMethodFactory();
        messageHandlerMethodFactory.setMessageConverter(consumerJackson2MessageConverter());
        return messageHandlerMethodFactory;
    }

    @Override
    public void configureRabbitListeners(RabbitListenerEndpointRegistrar registrar) {
        registrar.setMessageHandlerMethodFactory(messageHandlerMethodFactory());
    }

    @Bean
    public MappingJackson2MessageConverter consumerJackson2MessageConverter() {
        MappingJackson2MessageConverter mappingJackson2MessageConverter = new MappingJackson2MessageConverter();
        // Register modules for java8 datatypes (Instant)
        mappingJackson2MessageConverter.getObjectMapper().findAndRegisterModules();
        return mappingJackson2MessageConverter;
    }

    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory srlcFactory = new SimpleRabbitListenerContainerFactory();
        srlcFactory.setConnectionFactory(connectionFactory);
        srlcFactory.setDefaultRequeueRejected(false);
        return srlcFactory;
    }

    @Bean
    public RabbitAdmin rabbitAdmin(ConnectionFactory connectionFactory) {
        return new RabbitAdmin(connectionFactory);
    }

    /*
     * Helper methods to standardize dead letter queue / exchange naming.
     */
    public static String deadLetterExchangeName(String originalExchangeName) {
        return originalExchangeName + ".dlx";
    }

    public static String deadLetterQueueName(String originalQueueName) {
        return originalQueueName + ".dlq";
    }
}
