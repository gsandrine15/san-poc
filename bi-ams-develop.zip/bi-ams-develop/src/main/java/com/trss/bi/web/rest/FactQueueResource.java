package com.trss.bi.web.rest;

import com.trss.bi.service.FactInstanceService;
import com.trss.bi.service.FactQueueService;
import com.trss.bi.service.dto.FactInstanceFilterDTO;
import com.trss.bi.service.dto.FactQueueDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.trss.bi.security.AuthorizationConstants.*;

@RestController
@RequestMapping("/api")
public class FactQueueResource {

    private FactQueueService factQueueService;
    private FactInstanceService factInstanceService;

    public FactQueueResource(FactQueueService factQueueService, FactInstanceService factInstanceService) {
        this.factQueueService = factQueueService;
        this.factInstanceService = factInstanceService;
    }

    @PreAuthorize(ACCESS_CREATE_FOLDERS)
    @PostMapping("/fact-queues")
    public FactQueueDTO postFactQueue(@RequestBody FactQueueDTO factQueueDTO) {
        return factQueueService.createFactQueue(factQueueDTO);
    }

    @PreAuthorize(ACCESS_EDIT_FOLDERS)
    @PutMapping("/fact-queues")
    public FactQueueDTO putFactQueue(@RequestBody FactQueueDTO factQueueDTO) {
        return factQueueService.updateFactQueue(factQueueDTO);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues")
    public List<FactQueueDTO> getFactQueues() {
        return factQueueService.findAll();
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/{id}")
    public FactQueueDTO getFactQueue(@PathVariable String id) {
        return factQueueService.findById(id);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/")
    public FactQueueDTO getFactQueueByConfig(@RequestParam String factQueueConfigId) {
        return factQueueService.findDTOByFactQueueConfigId(factQueueConfigId);
    }

    @PreAuthorize(ACCESS_DELETE_FOLDERS)
    @DeleteMapping("/fact-queues/{id}")
    public void deleteFactQueue(@PathVariable String id) {
        factQueueService.deleteById(id);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/{id}/risks")
    public List getDistinctRisks(@PathVariable String id) {
        return factInstanceService.findDistinctRisks(id);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/{id}/predicates")
    public List getDistinctPredicates(@PathVariable String id) {
        return factInstanceService.findDistinctPredicates(id);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/{id}/count")
    public Long getFactInstanceCount(@PathVariable String id) {
        return factInstanceService.count(id);
    }

    @PreAuthorize(ACCESS_INBOX)
    @PostMapping("/fact-queues/{id}/older-than")
    public Long countOlderThan(@PathVariable("id") String queueId, @RequestParam("date") String date, @RequestBody FactInstanceFilterDTO filters){
        return factInstanceService.countNumFactInstancesBeforeDate(queueId, date, filters);
    }

    @PreAuthorize(ACCESS_INBOX)
    @PostMapping("/fact-queues/{id}/newer-than")
    public Long countNewerThan(@PathVariable("id") String queueId, @RequestParam("date") String date, @RequestBody FactInstanceFilterDTO filters){
        return factInstanceService.countNumFactInstancesAfterDate(queueId, date, filters);
    }

    @PreAuthorize(ACCESS_INBOX)
    @PostMapping("fact-queues/{id}/between-dates")
    public Long countBetweenDates(@PathVariable("id") String queueId, @RequestParam("startDate") String startDate, @RequestParam("endDate") String endDate, @RequestBody FactInstanceFilterDTO filters){
        return factInstanceService.countNumFactInstancesBetweenDates(queueId, startDate, endDate, filters);
    }

    @PreAuthorize(ACCESS_INBOX)
    @GetMapping("/fact-queues/{id}/flagged")
    public int countFlagged(@PathVariable("id") String queueId){
        return factInstanceService.countNumFactInstancesFlagged(queueId);
    }
}
