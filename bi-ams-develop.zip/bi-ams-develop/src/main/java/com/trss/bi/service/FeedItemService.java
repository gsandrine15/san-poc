package com.trss.bi.service;

import com.trss.bi.config.RabbitConfiguration;
import com.trss.bi.domain.FactQueue;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.service.dto.FeedItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class FeedItemService {
    private Logger logger = LoggerFactory.getLogger(FeedItemService.class);

    private FactService factService;
    private FactQueueService factQueueService;
    private FactInstanceService factInstanceService;
    private TaxonomyNodeService taxonomyNodeService;
    private FeedItemSender feedItemSender;
    private RabbitTemplate rabbitTemplate;
    private RabbitAdmin rabbitAdmin;

    private static Set<String> SKIP_QUEUE_KEYWORDS = new HashSet<>();
    static {
        SKIP_QUEUE_KEYWORDS.add("demo:");
        SKIP_QUEUE_KEYWORDS.add("testing:");
    }
    private static Set<String> ALWAYS_ENTITY_MATCH_KEYWORDS = new HashSet<>();
    static {
        ALWAYS_ENTITY_MATCH_KEYWORDS.add("match:");
        ALWAYS_ENTITY_MATCH_KEYWORDS.add("entity:");
    }
    static double MINIMUM_ENTITY_CONFIDENCE = .5;

    public FeedItemService(FactService factService, FactQueueService factQueueService, FactInstanceService factInstanceService,
                           TaxonomyNodeService taxonomyNodeService, FeedItemSender feedItemSender,
                           RabbitTemplate rabbitTemplate, RabbitAdmin rabbitAdmin) {
        this.factService = factService;
        this.factQueueService = factQueueService;
        this.factInstanceService = factInstanceService;
        this.taxonomyNodeService = taxonomyNodeService;
        this.feedItemSender = feedItemSender;
        this.rabbitTemplate = rabbitTemplate;
        this.rabbitAdmin = rabbitAdmin;
    }

    @RabbitListener(queues = "${rabbit.fact-feed.queue}")
    @Transactional
    public void consumeFeedItem(FeedItemDTO feedItemDTO) {
        logger.debug("Received Feed Item: " + feedItemDTO);
        try {
            loadFeedItem(feedItemDTO);
        }
        catch (Exception e) {
            logger.warn("Error loading feedItem: " + feedItemDTO + ", Message: " + e.getMessage());
            // this will send the item to the dead letter queue
            throw e;
        }
    }

    @Transactional
    public void loadFeedItem(FeedItemDTO feedItemDTO) {
        validate(feedItemDTO);

        Fact fact = factService.create(feedItemDTO);

        // sort entities in the list in descending order by confidence score
        List<ClientEntity> entities = fact.getEntities();
        entities.sort(Comparator.comparingDouble((ClientEntity entity) -> entity.getConfidenceScore()).reversed());
        fact.setEntities(entities);

        // for each matching queue config, create an fact instance
        for (String factQueueConfigId : feedItemDTO.getMatchingFactQueueConfigIds()) {
            FactQueue factQueue = findFactQueueByFactQueueConfigId(factQueueConfigId);
            if (factQueue == null) {
                logger.warn("No fact queue / folder found with fact queue config id: {}", factQueueConfigId);
            }
            else {
                // get a list of matches for this particular queue
                List<ClientEntity> queueMatchingEntities = fact.getEntities().stream().filter(
                    e -> e.getFactQueueConfigIds().contains(factQueue.getFactQueueConfigId())).collect(Collectors.toList());

                factInstanceService.create(fact, factQueue, queueMatchingEntities);
            }
        }
    }

    private void validate(FeedItemDTO feedItemDTO) {
        checkIfFactAlreadyExists(feedItemDTO.getFeedRouterId());

        // verify the taxonomy node is valid
        taxonomyNodeService.findByUri(feedItemDTO.getRisk())
            .orElseThrow(() -> new RuntimeException("No Taxonomy Node found for risk uri: '" + feedItemDTO.getRisk() + "'"));
    }

    private void checkIfFactAlreadyExists(String feedRouterId) {
        Fact fact = factService.findByFeedRouterId(feedRouterId);
        if (fact != null) throw new RuntimeException("Already loaded fact with feedRouterId: '" + feedRouterId + "'");
    }

    private FactQueue findFactQueueByFactQueueConfigId(String factQueueConfigId) {
        FactQueue factQueue = factQueueService.findByFactQueueConfigId(factQueueConfigId);
        //if (factQueue == null) throw new RuntimeException("No Fact Queue found with config id: " + factQueueConfigId);
        // return null instead of throwing exception
        return factQueue;
    }

    public Integer getDLQCount(String queueName) {
        return (Integer) rabbitAdmin.getQueueProperties(RabbitConfiguration.deadLetterQueueName(queueName)).get("QUEUE_MESSAGE_COUNT");
    }

    public Integer retryDLQMessages(String queueName) {
        int originalDlqCount = getDLQCount(queueName);
        int dlqCount = originalDlqCount;

        // if we have messages on the dql, retry them
        List<FeedItemDTO> feedItemDTOsToRetry = new ArrayList<>();
        FeedItemDTO feedItemDTO;
        while (dlqCount > 0) {
            feedItemDTO = (FeedItemDTO) rabbitTemplate.receiveAndConvert(RabbitConfiguration.deadLetterQueueName(queueName));
            logger.info("pulled feedItemDTO from DLQ: {}", feedItemDTO);
            feedItemDTOsToRetry.add(feedItemDTO);
            dlqCount = getDLQCount(queueName);
        }

        logger.info("found {} feedItemDTOs to retry", feedItemDTOsToRetry.size());

        for (FeedItemDTO feedItemDTOToRetry : feedItemDTOsToRetry) {
            feedItemSender.sendFeedItem(feedItemDTOToRetry);
            logger.info("Sent: {}", feedItemDTOToRetry);
        }

        return originalDlqCount;
    }
}
