package com.trss.bi.config;

import freemarker.template.Configuration;
import org.springframework.context.annotation.Bean;

/**
 * Freemarker template configuration.
 */
@org.springframework.context.annotation.Configuration
public class FreemarkerConfiguration {

    @Bean
    public Configuration newsroomFreemarkerConfiguration() {
        Configuration configuration = new Configuration(Configuration.VERSION_2_3_28);
        configuration.setClassForTemplateLoading(this.getClass(), "/newsroom");
        configuration.setDefaultEncoding("UTF-8");
        return configuration;
    }
}
