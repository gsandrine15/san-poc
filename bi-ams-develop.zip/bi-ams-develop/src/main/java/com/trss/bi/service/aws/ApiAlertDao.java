package com.trss.bi.service.aws;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.trss.bi.domain.api.ApiAlert;
import org.springframework.stereotype.Component;


/**
 * DAO for DynamoDB database.
 */
@Component
public class ApiAlertDao {

    protected String alertsTable;
    protected DynamoDBMapper dynamoDbMapper;

    public ApiAlertDao(AWSConfiguration configuration) {
        alertsTable = "rai-dynamodb-bixer-alerts-dev";
        dynamoDbMapper = new DynamoDBMapper(configuration.dynamoDBClient(), new DynamoDBMapperConfig.Builder()
            .withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement(alertsTable))
            .build());
    }

    /**
     * Save a Report.
     *
     * @param alert The Report to save
     */
    public void saveReport(ApiAlert alert) {
        dynamoDbMapper.save(alert);
    }

    /**
     * Get a ApiAlert.
     *
     * @param collabKey The ApiAlert collabKey
     * @return The retrieved ApiAlert
     */
    public ApiAlert getApiAlert(String collabKey) {
        return dynamoDbMapper.load(ApiAlert.class, collabKey);
    }

}
