package com.trss.bi.repository;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.domain.factinstance.FactInstance;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FactInstanceRepository extends MongoRepository<FactInstance, ObjectId> {
    List<FactInstance> findByRiskTaxonomyNodeIdOrderByCreatedDateDesc(String riskTaxonomyNodeId);
    Page<FactInstance> findByEntities_IdOrderByCreatedDateDesc(Pageable pageable, String entitityId);
    List<FactInstance> findBySelectedClientEntity_IdOrderByCreatedDateDesc(String selectedClientEntityId);
    Page<FactInstance> findBySelectedClientEntity_NameOrderByCreatedDateDesc(Pageable pageable, String selectedClientEntityId);

    Long countByFactQueueId(ObjectId factQueueId);
    int countByFactQueueIdAndFlagged(Object factQueueId, boolean flagged);

    Long countAllBy();

    void deleteAllByFactQueueId(ObjectId factQueueId);

    void deleteAllByFactId(ObjectId factId);
    Long deleteAllByFactIdIn(List<ObjectId> factIds);

    /**
     * @deprecated use {@link com.trss.bi.service.Service#save(AbstractAuditingEntity, ObjectId)} instead
     * @param factInstance
     * @return
     */
    @Deprecated
    FactInstance save(FactInstance factInstance);
}
