/**
 * Spring Data JPA repositories.
 */
package com.trss.bi.repository;
