package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class CorporateCrimeHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/corporatecrime";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();
        TaxonomyNode corporateCrime = helper.insertNode(rootNode, BASE_URI, "CORP_CRIME", "Corporate Crime", "This is corporate crime");

        // insert all children
        helper.insertNode(corporateCrime, BASE_URI + "/laundering", "LAUNDERING", "Laundering", "This is laundering");

        helper.insertNode(corporateCrime,
            BASE_URI + "/bribery", "BRIBERY", "Bribery", "This is bribery");

        helper.insertNode(corporateCrime,
            BASE_URI + "/bizcompliance", "BIZ_COMPLIANCE", "Business Compliance", "This is business compliance");

        helper.insertNode(corporateCrime,
            BASE_URI + "/embezzlement", "EMBEZZLEMENT", "Embezzlement", "This is embezzlement");

        helper.insertNode(corporateCrime,
            BASE_URI + "/insider", "INSIDER_TRADING", "Insider Trading", "This is insider trading");

        helper.insertNode(corporateCrime,
            BASE_URI + "/manipulation", "MANIPULATION", "Manipulation", "This is manipulation");

        helper.insertNode(corporateCrime,
            BASE_URI + "/moneyservice", "MONEY_SERVICE", "Money Service (MSB)", "This is money service");

        helper.insertNode(corporateCrime,
            BASE_URI + "/perjury", "PERJURY", "Perjury", "This is perjury");

        helper.insertNode(corporateCrime,
            BASE_URI + "/regaction", "REG_ACTION", "Regulatory Action", "This is regulatory action");

        helper.insertNode(corporateCrime,
            BASE_URI + "/secfraud", "SEC_FRAUD", "SEC Fraud", "This is SEC fraud");
    }
}
