package com.trss.bi.web.rest;

import com.trss.bi.security.AuthorizationConstants;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.ArticleTextService;
import com.trss.bi.service.NewsroomService;
import com.trss.bi.service.dto.ArticleTextDTO;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/api")
public class ArticleTextResource {

    private NewsroomService newsroomService;

    public ArticleTextResource(NewsroomService newsroomService){
        this.newsroomService = newsroomService;
    }

    @GetMapping("/article/{id}/text")
    public ArticleTextDTO articleText(@PathVariable("id") String id) {
        if (SecurityUtils.isCurrentUserInRole(AuthorizationConstants.ADMIN, AuthorizationConstants.CUSTOMER_ADMIN, AuthorizationConstants.USER)){
            return newsroomService.getArticleText(id);
        } else {
            throw new UnauthorizedUserException("user is trying to access article without at least user permissions");
        }
    }
}
