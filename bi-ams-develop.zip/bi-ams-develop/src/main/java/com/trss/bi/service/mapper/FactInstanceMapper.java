package com.trss.bi.service.mapper;

import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.service.dto.FactInstanceDTO;
import org.bson.types.ObjectId;

public class FactInstanceMapper extends BaseEntityMapper<FactInstanceDTO, FactInstance> {

    @Override
    public FactInstance toEntity(FactInstanceDTO dto) {
        if (dto == null) {
            return null;
        }

        FactInstance entity = new FactInstance();
        if (dto.getId() != null) {
            entity.setId(new ObjectId(dto.getId()));
        }

        entity.setFactId(new ObjectId(dto.getFactId()));
        entity.setFeedRouterId(dto.getFeedRouterId());
        entity.setFactQueueId(new ObjectId(dto.getFactQueueId()));
        entity.setMsFactId(dto.getMsFactId());
        entity.setEntities(dto.getEntities());
        entity.setSelectedClientEntity(dto.getSelectedClientEntity());
        entity.setRiskTaxonomyNodeId(dto.getRiskTaxonomyNodeId());
        entity.setPredicateTaxonomyNodeId(dto.getPredicateTaxonomyNodeId());
        entity.setArticles(dto.getArticles());
        entity.setFlagged(dto.getFlagged());
        entity.setEvents(dto.getEvents());
        entity.setAnalystNotes(dto.getAnalystNotes());
        entity.setRationale(dto.getRationale());
        entity.setCreatedDate(dto.getCreatedDate());
        entity.setSentDateDetails(dto.getSentDateDetails());
        entity.setSent(dto.getSent());
        entity.setFeedbackItems(dto.getFeedbackItems());
        //TODO: add created by field as well

        return entity;
    }

    @Override
    public FactInstanceDTO toDto(FactInstance entity) {
        if (entity == null) {
            return null;
        }

        FactInstanceDTO dto = new FactInstanceDTO();
        if (entity.getId() != null) {
            dto.setId(entity.getId().toString());
        }

        dto.setFactId(entity.getFactId().toString());
        dto.setFeedRouterId(entity.getFeedRouterId());
        dto.setFactQueueId(entity.getFactQueueId().toString());
        dto.setMsFactId(entity.getMsFactId());
        dto.setEntities(entity.getEntities());
        dto.setSelectedClientEntity(entity.getSelectedClientEntity());
        dto.setRiskTaxonomyNodeId(entity.getRiskTaxonomyNodeId());
        dto.setPredicateTaxonomyNodeId(entity.getPredicateTaxonomyNodeId());
        dto.setArticles(entity.getArticles());
        dto.setFlagged(entity.getFlagged());
        dto.setEvents(entity.getEvents());
        dto.setCreatedDate(entity.getCreatedDate());
        dto.setSentDateDetails(entity.getSentDateDetails());
        dto.setSent(entity.getSent());
        dto.setLastModifiedBy(entity.getLastModifiedBy());
        dto.setLastModifiedDate(entity.getLastModifiedDate());
        dto.setAnalystNotes(entity.getAnalystNotes());
        dto.setRationale(entity.getRationale());
        dto.setFeedbackItems(entity.getFeedbackItems());

        return dto;
    }
}
