package com.trss.bi.service.dto;

import java.io.Serializable;

public class HistoricalFactInstanceDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    public HistoricalFactInstanceDTO(FactInstanceDTO factInstanceDTO, String archivedReason, String analystNotes, String clientNotes, Long customerId) {
        this.factInstanceDTO = factInstanceDTO;
        this.archivedReason = archivedReason;
        this.analystNotes = analystNotes;
        this.clientNotes = clientNotes;
        this.customerId = customerId;
    }

    public FactInstanceDTO factInstanceDTO;
    public String archivedReason;
    public String analystNotes;
    public String clientNotes;
    public Long customerId;

    public FactInstanceDTO getFactInstanceDTO() {
        return this.factInstanceDTO;
    }

    public void setFactInstanceDTO(FactInstanceDTO factInstanceDTO) {
        this.factInstanceDTO = factInstanceDTO;
    }

    public String getArchivedReason() {
        return archivedReason;
    }

    public void setArchivedReason(String archivedReason) {
        this.archivedReason = archivedReason;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getClientNotes() {
        return clientNotes;
    }

    public void setClientNotes(String clientNotes) {
        this.clientNotes = clientNotes;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
