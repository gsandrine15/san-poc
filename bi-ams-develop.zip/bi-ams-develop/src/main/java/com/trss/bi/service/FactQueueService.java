package com.trss.bi.service;

import com.google.common.collect.Lists;
import com.trss.bi.config.RabbitConfiguration;
import com.trss.bi.domain.FactQueue;
import com.trss.bi.repository.FactQueueRepository;
import com.trss.bi.security.AuthorizationConstants;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.dto.FactQueueDTO;
import com.trss.bi.service.mapper.FactQueueMapper;
import org.bson.types.ObjectId;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FactQueueService extends com.trss.bi.service.Service<FactQueue> {

    private FactQueueMapper factQueueMapper = new FactQueueMapper();
    private FactQueueRepository factQueueRepository;
    private FactInstanceService factInstanceService;
    private RabbitTemplate rabbitTemplate;

    @Value("${rabbit.fact-instance.delete.exchange}")
    private String factInstanceDeleteExchange;
    private static final List<String> VIEW_ALL_FOLDERS_AUTHORITIES = Lists.newArrayList("ROLE_ADMIN", "ROLE_CUSTOMER_ADMIN", "ROLE_USER", "INBOX_VIEW_ALL_FOLDERS");
    private static final String VIEW_MY_FOLDERS = "INBOX_VIEW_MY_FOLDERS";


    @Autowired
    public FactQueueService(FactQueueRepository factQueueRepository, FactInstanceService factInstanceService,
                            RabbitTemplate rabbitTemplate) {
        super(factQueueRepository);
        this.factQueueRepository = factQueueRepository;
        this.factInstanceService = factInstanceService;
        this.rabbitTemplate = rabbitTemplate;
    }

    public FactQueueDTO createFactQueue(FactQueueDTO factQueueDTO) {
        factQueueDTO.setOwnerId(SecurityUtils.getCurrentUserId());
        factQueueDTO.setOwnerUsername(SecurityUtils.getCurrentUserLogin().orElse(""));
        factQueueDTO.setCustomerId(SecurityUtils.getCurrentCustomerId());

        return save(factQueueDTO);
    }

    public FactQueueDTO updateFactQueue(FactQueueDTO factQueueDTO) {
        FactQueueDTO factQueueDTOToUpdate = findById(factQueueDTO.getId());

        // control explicitly what can be updated
        factQueueDTOToUpdate.setName(factQueueDTO.getName());
        factQueueDTOToUpdate.setDescription(factQueueDTO.getDescription());

        return save(factQueueDTOToUpdate);
    }

    public List<FactQueueDTO> findAll() {
        final Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        final String username = (String) auth.getPrincipal();
        Long customerId = SecurityUtils.getCurrentCustomerId();
        if (auth != null && auth.getAuthorities().stream().anyMatch(a -> VIEW_ALL_FOLDERS_AUTHORITIES.contains(a.getAuthority()))) {
            return factQueueMapper.toDto(factQueueRepository.findAllByCustomerId(customerId));
        }
        if (auth != null && auth.getAuthorities().stream().anyMatch(a -> VIEW_MY_FOLDERS.equals(a.getAuthority()))) {
            return factQueueMapper.toDto(factQueueRepository.findAllByCustomerId(customerId).stream().filter(factQueue -> factQueue.getOwnerUsername().equals(username)).collect(Collectors.toList()));
        }
        else return Collections.emptyList();
    }

    public FactQueueDTO findById(String id) {
        if (!(SecurityUtils.isCurrentUserInRole(AuthorizationConstants.ADMIN, AuthorizationConstants.CUSTOMER_ADMIN, AuthorizationConstants.USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_MY_FOLDERS", "INBOX_VIEW_ALL_FOLDERS"))) {
            return new FactQueueDTO();
        }
        if (SecurityUtils.isAdmin()) {
            return factQueueMapper.toDto(factQueueRepository.findById(new ObjectId(id))
                .orElseThrow(() -> new RuntimeException("No Fact Queue found with id: " + id)));
        }
        Long customerId = SecurityUtils.getCurrentCustomerId();
        return factQueueMapper.toDto(factQueueRepository.findByIdAndCustomerId(new ObjectId(id), customerId)
        .orElseThrow(() -> new RuntimeException("No Fact Queue found with id: " + id + " with customerId: " + customerId)));
    }

    public FactQueueDTO findDTOByFactQueueConfigId(String factQueueConfigId) {
        if (!(SecurityUtils.isCurrentUserInRole(AuthorizationConstants.ADMIN, AuthorizationConstants.CUSTOMER_ADMIN, AuthorizationConstants.USER)) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_MY_FOLDERS", "INBOX_VIEW_ALL_FOLDERS")) {
            return new FactQueueDTO();
        }
        return factQueueMapper.toDto(factQueueRepository.findByFactQueueConfigIdAndCustomerId(factQueueConfigId, SecurityUtils.getCurrentCustomerId()));
    }

    // Need to not have customer ID to support RabbitMQ
    public FactQueue findByFactQueueConfigId(String factQueueConfigId) {
        return factQueueRepository.findByFactQueueConfigId(factQueueConfigId);
    }

    public FactQueueDTO findByName(String name) {
        List<FactQueue> factQueues = factQueueRepository.findByName(name);
        if (factQueues != null && factQueues.size() > 0) {
            return factQueueMapper.toDto(factQueues.get(0));
        }
        return null;
    }

    public FactQueueDTO save(FactQueueDTO factQueueDTO) {
        FactQueue factQueue = factQueueMapper.toEntity(factQueueDTO);
        return factQueueMapper.toDto(save(factQueue, factQueue.getId()));
    }

    /**
     * Hard delete the fact queue and any associated fact instances
     */
    public void deleteById(String id) {
        // Delete fact queue record
        factQueueRepository.deleteById(new ObjectId(id));

        // Kick off fact instance delete(s)
        rabbitTemplate.convertAndSend(factInstanceDeleteExchange, RabbitConfiguration.KEY_FACT_INSTANCE_DELETE,
            id);
    }

    @RabbitListener(queues = "${rabbit.fact-instance.delete.queue}")
    public void deleteFactInstancesByFactQueueId(String factQueueId) {
        factInstanceService.deleteByFactQueueId(factQueueId);
    }
}
