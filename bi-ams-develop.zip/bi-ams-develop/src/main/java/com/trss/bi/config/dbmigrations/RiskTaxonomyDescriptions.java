package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.config.dbmigrations.risktaxonomy.*;
import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.List;

@ChangeLog(order = "004")
public class RiskTaxonomyDescriptions {
    @ChangeSet(order = "01", author= "admin", id = "004-01-add-descriptions")
    public void addDescriptions(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> nodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : nodes) {
            if (!node.isRoot()) {
                String description = DescriptionsConfig.URI_DESCRIPTIONS.get(node.getUri());
                if (description != null && description.length() > 0) {
                    node.setDescription(description);
                    mongoTemplate.save(node);
                } else {
                    System.out.println("No description found for node: " + node.getUri());
                }
            }
        }
    }

    @ChangeSet(order = "02", author= "admin", id = "004-02-kidnapping-name")
    public void updateKidnappingName(MongoTemplate mongoTemplate) {
        Query query = new Query();
        query.addCriteria(Criteria.where("displayName").is("Kidnap"));
        TaxonomyNode taxonomyNode = mongoTemplate.findOne(query, TaxonomyNode.class);
        if (taxonomyNode != null) {
            taxonomyNode.setDisplayName("Kidnapping");
            mongoTemplate.save(taxonomyNode);
        }
    }

    @ChangeSet(order = "03", author= "admin", id = "004-03-update-descriptions-4-30-21")
    public void updateDescriptions_4_30_21(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> nodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : nodes) {
            if (!node.isRoot()) {
                String description = DescriptionsConfig.URI_DESCRIPTIONS_4_30_2021.get(node.getUri());
                if (description != null && description.length() > 0) {
                    node.setDescription(description);
                    mongoTemplate.save(node);
                } else {
                    System.out.println("No description found for node: " + node.getUri());
                }
            }
        }
    }
}
