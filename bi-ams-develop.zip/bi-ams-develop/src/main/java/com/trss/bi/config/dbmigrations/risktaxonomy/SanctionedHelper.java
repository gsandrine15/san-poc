package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class SanctionedHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/sanctioned";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode sanctioned = helper.insertNode(rootNode, BASE_URI, "SANCTIONED", "Sanctioned",
            "This is sanctioned");

        // insert all the children
        helper.insertNode(sanctioned, BASE_URI + "/sanctcountry", "SANCT_COUNTRY", "Sanctioned Country",
            "This is sanctioned country");

        helper.insertNode(sanctioned, BASE_URI + "/sanctcompany", "SANCT_COMPANY", "Sanctioned Company",
            "This is sanctioned company");

        helper.insertNode(sanctioned, BASE_URI + "/sanctperson", "SANCT_PERSON", "Sanctioned Person",
            "This is sanctioned person");
    }
}
