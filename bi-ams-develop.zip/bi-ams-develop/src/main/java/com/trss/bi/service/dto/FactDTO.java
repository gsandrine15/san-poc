package com.trss.bi.service.dto;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.FeedbackItem;
import com.trss.bi.domain.fact.Note;
import com.trss.bi.domain.fact.Subject;
import com.trss.bi.domain.factinstance.ClientEntity;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class FactDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;

    private String msFactId; // GUID from media screener

    private String feedRouterId; // GUID from AWS

    private Subject subject;

    private List<Note> notes = new ArrayList<>();

    private List<ClientEntity> entities;
    private String riskTaxonomyNodeId;
    private String predicateTaxonomyNodeId;

    private List<Article> articles;

    private List<FeedbackItem> feedbackItems;

    private Instant sent;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public List<Note> getNotes() {
        return notes;
    }

    public void setNotes(List<Note> notes) {
        this.notes = notes;
    }

    public List<ClientEntity> getEntities() {
        return entities;
    }

    public void setEntities(List<ClientEntity> entities) {
        this.entities = entities;
    }

    public String getRiskTaxonomyNodeId() {
        return riskTaxonomyNodeId;
    }

    public void setRiskTaxonomyNodeId(String riskTaxonomyNodeId) {
        this.riskTaxonomyNodeId = riskTaxonomyNodeId;
    }

    public String getPredicateTaxonomyNodeId() {
        return predicateTaxonomyNodeId;
    }

    public void setPredicateTaxonomyNodeId(String predicateTaxonomyNodeId) {
        this.predicateTaxonomyNodeId = predicateTaxonomyNodeId;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public Instant getSent() {
        return sent;
    }

    public void setSent(Instant sent) {
        this.sent = sent;
    }

    public List<FeedbackItem> getFeedbackItems() {
        return feedbackItems;
    }

    public void setFeedbackItems(List<FeedbackItem> feedbackItems) {
        this.feedbackItems = feedbackItems;
    }
}
