package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class TaxonomySetupHelper {

    private MongoTemplate mongoTemplate;
    private Taxonomy taxonomy;
    public Taxonomy getTaxonomy() {
        return this.taxonomy;
    }

    public TaxonomySetupHelper(MongoTemplate mongoTemplate) {
        this(mongoTemplate, "RISK");
    }

    public TaxonomySetupHelper(MongoTemplate mongoTemplate, String defaultTaxonomyCode) {
        this.mongoTemplate = mongoTemplate;
        this.taxonomy = findTaxonomy(mongoTemplate, defaultTaxonomyCode);
    }

    public TaxonomySetupHelper(MongoTemplate mongoTemplate, Taxonomy taxonomy) {
        this.mongoTemplate = mongoTemplate;
        this.taxonomy = taxonomy;
    }

    public Taxonomy findTaxonomy(MongoTemplate mongoTemplate, String taxonomyCode) {
        Query query = new Query();
        query.addCriteria(Criteria.where("code").is(taxonomyCode));
        return mongoTemplate.findOne(query, Taxonomy.class);
    }

    public TaxonomyNode findRootNode() {
        return findRootNode("ROOT");
    }

    public TaxonomyNode findRootNode(String code) {
        Query query = new Query();
        query.addCriteria(Criteria.where("code").is(code).and("taxonomyId").is(taxonomy.getId()));
        return mongoTemplate.findOne(query, TaxonomyNode.class);
    }

    public TaxonomyNode insertNode(TaxonomyNode parentNode, String uri, String code, String displayName, String description) {
        TaxonomyNode node = new TaxonomyNode()
            .taxonomyId(taxonomy.getId())
            .uri(uri)
            .code(code)
            .displayName(displayName)
            .description(description);

        // set the entire lineage back to the root
        LinkedHashSet<ObjectId> dedupedParentIds = new LinkedHashSet<>(parentNode.getParentNodeIds());
        dedupedParentIds.add(parentNode.getId());

        node.setParentNodeIds(new ArrayList<>(dedupedParentIds));
        mongoTemplate.insert(node);

        parentNode.addChildNodeId(node.getId());
        mongoTemplate.save(parentNode);

        return node;
    }
}
