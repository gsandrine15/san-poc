package com.trss.bi.repository;

import com.trss.bi.domain.taxonomy.Taxonomy;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TaxonomyRepository extends MongoRepository<Taxonomy, ObjectId> {
    Taxonomy findByCode(String code);
}
