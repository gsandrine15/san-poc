package com.trss.bi.service;

import com.trss.bi.service.dto.ArticleTextDTO;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class ArticleTextService {
    public ArticleTextDTO getText(String id){
        ArticleTextDTO articleTextDTO = new ArticleTextDTO();
        articleTextDTO.setId (id);
        articleTextDTO.setArticleTitle("This article has id " + id + ".");
        articleTextDTO.setPublishedDate(Instant.now());
        articleTextDTO.setArticleHtml("<body><li>This is the article text for article " + id + ".</li></body>");
        articleTextDTO.setArticleSummaryHtml("<li>Article " + id + ".</li>");
        return articleTextDTO;
    }
}
