package com.trss.bi.service.mapper;

import com.trss.bi.domain.alert.Alert;
import com.trss.bi.service.dto.AlertDTO;
import org.bson.types.ObjectId;

public class AlertMapper extends BaseEntityMapper<AlertDTO, Alert> {

    private FactInstanceMapper factInstanceMapper = new FactInstanceMapper();

    @Override
    public Alert toEntity(AlertDTO dto) {
        if (dto == null) {
            return null;
        }

        Alert entity = new Alert();
        if (dto.getId() != null) {
            entity.setId(new ObjectId(dto.getId()));
        }

        entity.setClientEntityId(dto.getClientEntityId());
        entity.setCustomerId(dto.getCustomerId());
        entity.setClientEntity(dto.getClientEntity());
        entity.setFactInstances(factInstanceMapper.toEntity(dto.getFactInstances()));
        entity.setAnalystNotes(dto.getAnalystNotes());
        entity.setClientNotes(dto.getClientNotes());
        entity.setSeverity(dto.getSeverity());

        return entity;
    }

    @Override
    public AlertDTO toDto(Alert entity) {
        if (entity == null) {
            return null;
        }

        AlertDTO dto = new AlertDTO();
        if (entity.getId() != null) {
            dto.setId(entity.getId().toString());
        }

        dto.setClientEntityId(entity.getClientEntityId());
        dto.setCustomerId(entity.getCustomerId());
        dto.setClientEntity(entity.getClientEntity());
        dto.setFactInstances(factInstanceMapper.toDto(entity.getFactInstances()));
        dto.setAnalystNotes(entity.getAnalystNotes());
        dto.setClientNotes(entity.getClientNotes());
        dto.setSeverity(entity.getSeverity());
        dto.setCreatedDate(entity.getCreatedDate());

        return dto;
    }
}
