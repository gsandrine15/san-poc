package com.trss.bi.web.rest;

import com.trss.bi.config.AsyncConfiguration;
import com.trss.bi.domain.FactQueue;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.service.FactInstanceService;
import com.trss.bi.service.FactQueueService;
import com.trss.bi.service.FactService;
import com.trss.bi.service.dto.*;
import com.trss.bi.service.mapper.FactQueueMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class HistoricalSearchResource {
    private FactService factService;
    private FactInstanceService factInstanceService;
    private FactQueueService factQueueService;
    private FactQueueMapper factQueueMapper =  new FactQueueMapper();

    private final Logger log = LoggerFactory.getLogger(HistoricalSearchResource.class);
    public HistoricalSearchResource(FactService factService, FactInstanceService factInstanceService, FactQueueService factQueueService) {
        this.factService = factService;
        this.factInstanceService = factInstanceService;
        this.factQueueService = factQueueService;
    }

    /**
     * NOTE: This came from BIXER-1121 and we are on-hold for this feature as of now
     * @param searchDTO
     */
    @PostMapping("/history/inbox")
    public void addToInbox(@RequestBody HistoricalSearchDTO searchDTO) {
        if (true) {
            throw new UnsupportedOperationException("Implementation is unfinished. BIXER-1121 is on hold.");
        }
        Fact fact = factService.create(searchDTO);
        FactQueue factQueue = factQueueMapper.toEntity(factQueueService.findDTOByFactQueueConfigId(searchDTO.getQueueId()));
        factInstanceService.create(fact, factQueue, fact.getEntities());
    }
}
