package com.trss.bi.domain.factinstance;

import com.trss.bi.domain.alert.Alert;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.dto.HistoricalFactInstanceDTO;
import com.trss.bi.service.util.StringUtil;
import lombok.Data;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.time.Instant;

@Document(collection = "hisFacIns")
public class HistoricalFactInstance {

    public HistoricalFactInstance() {
    }

    public HistoricalFactInstance(FactInstance factInstance, @NotNull EventType eventType, String analystNotes, String clientNotes, Long customerId) {
        this.factInstance = factInstance;
        this.analystNotes = analystNotes;
        this.clientNotes = clientNotes;
        this.archivedReason = eventType.getValue();
        this.customerId = customerId;
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        this.factInstance.getEvents().add(
            new Event()
                .type(eventType)
                .description(StringUtil.capitalize(eventType.getValue()))
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
        );
        this.factInstance.setLastModifiedBy(username);
        this.factInstance.setLastModifiedDate(Instant.now());
    }

    public HistoricalFactInstance(FactInstance factInstance, String archivedReason, String analystNotes, String clientNotes, Long customerId) {
        this.factInstance = factInstance;
        this.archivedReason = archivedReason;
        this.analystNotes = analystNotes;
        this.clientNotes = clientNotes;
        this.customerId = customerId;
    }


    private FactInstance factInstance;
    private String archivedReason;
    private String analystNotes;
    private String clientNotes;
    private Long customerId;

    public FactInstance getFactInstance() {
        return factInstance;
    }

    public void setFactInstance(FactInstance factInstance) {
        this.factInstance = factInstance;
    }

    public String getArchivedReason() {
        return this.archivedReason;
    }

    public void setArchivedReason(String archivedReason) {
        this.archivedReason = archivedReason;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getClientNotes() {
        return clientNotes;
    }

    public void setClientNotes(String clientNotes) {
        this.clientNotes = clientNotes;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
