package com.trss.bi.repository;

import com.trss.bi.domain.NewsroomPublisher;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface NewsroomPublisherRepository extends MongoRepository<NewsroomPublisher, ObjectId> {

    NewsroomPublisher findByPubCode(String pubCode);
    NewsroomPublisher findByJournalCode(String journalCode);
    NewsroomPublisher findByPubCodeAndJournalCode(String pubCode, String journalCode);

}
