package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@ChangeLog(order = "006")
public class RiskTaxonomyEthicalIssuesUpdate {

    @ChangeSet(order = "01", author = "admin", id = "006-01-update-ethicalissues")
    public void updateUris(MongoTemplate mongoTemplate) {
        updateTaxonomyNodeUri(mongoTemplate, "ANIMAL_WELFARE", "https://graph.thomsonreuters.com/fact_type/risk/ethical_issues/animal_welfare");
        updateTaxonomyNodeUri(mongoTemplate, "ECO_CRIME", "https://graph.thomsonreuters.com/fact_type/risk/ethical_issues/eco_crime");
        updateTaxonomyNodeUri(mongoTemplate, "HEALTH_SAFETY", "https://graph.thomsonreuters.com/fact_type/risk/ethical_issues/health_safety");
    }

    private void updateTaxonomyNodeUri(MongoTemplate mongoTemplate, String code, String newUri) {
        Query query = new Query();
        query.addCriteria(Criteria.where("code").is(code));
        TaxonomyNode taxonomyNode = mongoTemplate.findOne(query, TaxonomyNode.class);
        if(taxonomyNode != null) {
            taxonomyNode.setUri(newUri);
            mongoTemplate.save(taxonomyNode);
        }
    }
}
