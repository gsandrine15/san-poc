package com.trss.bi.web.rest;

import com.trss.bi.security.AuthorizationConstants;
import com.trss.bi.service.FactInstanceService;
import com.trss.bi.service.dto.FactInstanceDTO;
import com.trss.bi.service.dto.FactInstanceFilterDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class FactInstanceResource {
    private FactInstanceService factInstanceService;

    public FactInstanceResource(FactInstanceService factInstanceService) {
        this.factInstanceService = factInstanceService;
    }

    @PostMapping("/fact-instance/filter")
    public Page<FactInstanceDTO> getFactInstances(Pageable pageable, @RequestParam("factQueueId") String factQueueId, @RequestBody FactInstanceFilterDTO filters) {
        return factInstanceService.findFactInstances(pageable, factQueueId, filters);
    }

    @PostMapping("/fact-instance/search/entity-names")
    public List<String> searchClientEntityNamesByNameSubstring(@RequestParam("factQueueId") String factQueueId, @RequestBody Map<String,String> params) {
        return factInstanceService.findClientEntityNamesByNameSubstring(factQueueId, params.get("nameSubstring").toLowerCase());
    }

    @GetMapping("/fact-instance/count")
    public Long countAllFactInstances(@RequestParam(value = "factQueueIds[]") String[] factQueueIds) {
        return Arrays.stream(factQueueIds)
            .map(factQueueId -> factInstanceService.count(factQueueId))
            .reduce((results, count) -> results + count)
            .orElse(0L);
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_EDIT_FACTS)
    @PostMapping("/fact-instance")
    public FactInstanceDTO save(@RequestBody FactInstanceDTO factInstanceDTO) {
        return factInstanceService.save(factInstanceDTO);
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_EDIT_FACTS)
    @PutMapping("/fact-instance")
    public FactInstanceDTO update(@RequestBody FactInstanceDTO factInstanceDTO, @RequestParam String editType){
        if (!editType.equals("NONE")){
            return factInstanceService.saveWithType(factInstanceDTO, editType);
        }
        return factInstanceService.save(factInstanceDTO);
    }

    @PutMapping("/fact-instance/{id}/open")
    public FactInstanceDTO setOpened(@PathVariable("id") String factInstanceId) {
        return factInstanceService.setOpened(factInstanceId);
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_RESOLVE_FACTS)
    @PutMapping("/fact-instance/{id}/ignore")
    public void ignore(@PathVariable("id") String factInstanceId, @RequestBody Map<String,String> params) {
        System.out.println("params: " + params);
        factInstanceService.ignore(factInstanceId, params.get("reason"), params.get("comments"));
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_EDIT_FACTS)
    @PutMapping("/fact-instance/{id}/notes")
    public FactInstanceDTO putNotes(@PathVariable("id") String factInstanceId, @RequestBody Map<String,String> params) {
        return factInstanceService.saveAnalystNotes(factInstanceId, params.get("analystNotes"));
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_EDIT_FACTS)
    @PutMapping("/fact-instance/{id}/flag")
    public FactInstanceDTO toggleFlagged(@PathVariable("id") String factInstanceId) {
        return factInstanceService.toggleFlagged(factInstanceId);
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_VIEW_FOLDERS)
    @GetMapping(path = "/fact-instance/related", params = "riskId")
    public List<FactInstanceDTO> getRelatedRisk(@RequestParam("riskId") String riskId) {
        return factInstanceService.getByRisk(riskId);
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_VIEW_FOLDERS)
    @GetMapping(path = "/fact-instance/related", params = "clientEntityId")
    public List<FactInstanceDTO> getRelatedEntity(@RequestParam("clientEntityId") String clientEntityId) {
        return factInstanceService.getByEntity(clientEntityId);
    }
}
