package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.github.mongobee.exception.MongobeeException;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import org.springframework.data.mongodb.core.index.Indexed;

@ChangeLog(order = "003")
public class Indexes {

    /**
     * FactInstance
     *  - created_date ascending
     *  - factQueueId
     *  - riskTaxonomyNodeId
     *  - flagged
     */
    @ChangeSet(order = "01", author = "admin", id = "003-01-factInstance")
    public void indexFactInstance(DB db) {
        DBCollection collection = db.getCollection("factInstance");

        // created_date ascending
        DBObject indexKeys = BasicDBObjectBuilder.start().add("created_date", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-created_date-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // factQueueId
        indexKeys = BasicDBObjectBuilder.start().add("factQueueId",1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-factQueueId-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // riskTaxonomyNodeId
        indexKeys = BasicDBObjectBuilder.start().add("riskTaxonomyNodeId",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-riskTaxonomyNodeId-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // riskTaxonomyNodeId
        indexKeys = BasicDBObjectBuilder.start().add("flagged",1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-flagged-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  FactQueue
     *  - factQueueConfigId
     */
    @ChangeSet(order = "02", author = "admin", id = "003-02-factQueue")
    public void indexFactQueue(DB db) {
        DBCollection collection = db.getCollection("factQueue");

        // factQueueConfigId
        DBObject indexKeys = BasicDBObjectBuilder.start().add("factQueueConfigId", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "factQueue-factQueueConfigId-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  Fact
     *  - feedRouterId
     */
    @ChangeSet(order = "03", author = "admin", id = "003-03-fact")
    public void indexFact(DB db) {
        DBCollection collection = db.getCollection("fact");

        // feedRouterId
        DBObject indexKeys = BasicDBObjectBuilder.start().add("feedRouterId", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "fact-feedRouterId-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  Taxonomy
     *  - code
     */
    @ChangeSet(order = "04", author = "admin", id = "003-04-taxonomy")
    public void indexTaxonomy(DB db) {
        DBCollection collection = db.getCollection("taxonomy");

        // code
        DBObject indexKeys = BasicDBObjectBuilder.start().add("code", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "taxonomy-code-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  TaxonomyNode
     *  - taxonomyId
     *  - uri
     */
    @ChangeSet(order = "05", author = "admin", id = "003-05-taxonomyNode")
    public void indexTaxonomyNode(DB db) {
        DBCollection collection = db.getCollection("taxonomyNode");

        // taxonomyId
        DBObject indexKeys = BasicDBObjectBuilder.start().add("taxonomyId", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "taxonomyNode-taxonomyId-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // uri
        indexKeys = BasicDBObjectBuilder.start().add("uri", 1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "taxonomyNode-uri-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  Alert
     *  - clientEntityId
     *  - created_date asc
     */
    @ChangeSet(order = "05", author = "admin", id = "003-05-alert")
    public void indexAlert(DB db) {
        DBCollection collection = db.getCollection("alert");

        // clientEntityId
        // (already handled by annotation on Alert.java)

        // created_date
        DBObject indexKeys = BasicDBObjectBuilder.start().add("created_date", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "alert-created_date-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    /**
     *  Alert
     *  - clientEntityId
     *  remove existing index from annotation and create explicitly
     */
    @ChangeSet(order = "06", author = "admin", id = "003-06-alert")
    public void indexAlertPart2(DB db) {
        DBCollection collection = db.getCollection("alert");

        // clientEntityId
        try {
            collection.dropIndex("clientEntityId");
        } catch (Exception e) {
            System.out.println("Exception thrown dropping index (most likely was already removed)");
        }

        DBObject indexKeys = BasicDBObjectBuilder.start().add("clientEntityId", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "alert-clientEntityId-idx").add("unique", true).get();
        collection.createIndex(indexKeys, indexOptions);
    }

    @ChangeSet(order = "07", author = "admin", id = "003-07-additional-factInstance-idxs")
    public void indexFactInstance2(DB db) {
        DBCollection collection = db.getCollection("factInstance");

        // entities.type
        DBObject indexKeys = BasicDBObjectBuilder.start().add("entities.type", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-entities.type-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // sent
        indexKeys = BasicDBObjectBuilder.start().add("sent",1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-sent-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // sent_date_details
        indexKeys = BasicDBObjectBuilder.start().add("sent_date_details",1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-sent_date_details-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        // predicateTaxonomyNodeId
        indexKeys = BasicDBObjectBuilder.start().add("predicateTaxonomyNodeId",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "factInstance-predicateTaxonomy-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }

    @ChangeSet(order = "08", author = "admin", id = "003-08-historical-factInstance-idxs")
    public void indexHistoricalFactInstance(DB db) {
        DBCollection collection = db.getCollection("historicalFactInstance");

        // Wrapping indexes in try/catch to avoid "namespace name generated from index name is too long" exception with
        // AWS DocumentDB. Migrations 9 and 10 below recreate the indexes with shorter names.
        try {
            // entities.type
            DBObject indexKeys = BasicDBObjectBuilder.start().add("factInstance.entities.type", 1).get();
            DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-entities.type-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            // entities.name
            indexKeys = BasicDBObjectBuilder.start().add("factInstance.entities.name", 1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-entities.name-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            // predicateTaxonomyNodeId
            indexKeys = BasicDBObjectBuilder.start().add("factInstance.predicateTaxonomyNodeId",-1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-predicateTaxonomy-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            // riskTaxonomyNodeId
            indexKeys = BasicDBObjectBuilder.start().add("factInstance.riskTaxonomyNodeId",-1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-riskTaxonomy-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            // archivedReason
            indexKeys = BasicDBObjectBuilder.start().add("archivedReason",-1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-resolution-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            //lastModifiedBy
            indexKeys = BasicDBObjectBuilder.start().add("factInstance.lastModifiedBy",-1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-lastmodified-idx").get();
            collection.createIndex(indexKeys, indexOptions);

            //sent date
            indexKeys = BasicDBObjectBuilder.start().add("factInstance.sent",-1).get();
            indexOptions = BasicDBObjectBuilder.start().add("name", "historicalFactInstance-sent-idx").get();
            collection.createIndex(indexKeys, indexOptions);
        } catch (Exception ex) {
            System.out.println("Exception thrown creating historicalFactInstance indexes");
        }
    }

    /**
     * The reason for renaming the collection is to get shorter index names because of an index name length limit that
     * was encountered on AWS (https://jira.mongodb.org/browse/SERVER-32959).
     */
    @ChangeSet(order = "09", author = "admin", id = "003-09-rename-collection")
    public void indexShortenHistoricalFactInstance(DB db) {
        DBCollection collection = db.getCollection("historicalFactInstance");
        collection.rename("hisFacIns");
    }

    /**
     * This migration makes the indexes even shorter by changing the name to match the shorter new collection name. It
     * is essentially replacing the 08 migration.
     */
    @ChangeSet(order = "10", author = "admin", id = "003-10-rename-indexes")
    public void indexShortenHistoricalFactInstanceIndexes(DB db) {
        DBCollection collection = db.getCollection("hisFacIns");
        collection.dropIndexes();

        DBObject indexKeys = BasicDBObjectBuilder.start().add("factInstance.entities.type", 1).get();
        DBObject indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-entities.type-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("factInstance.entities.name", 1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-entities.name-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("factInstance.predicateTaxonomyNodeId",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-predicateTaxonomy-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("factInstance.riskTaxonomyNodeId",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-riskTaxonomy-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("archivedReason",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-resolution-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("factInstance.lastModifiedBy",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-lastmodified-idx").get();
        collection.createIndex(indexKeys, indexOptions);

        indexKeys = BasicDBObjectBuilder.start().add("factInstance.sent",-1).get();
        indexOptions = BasicDBObjectBuilder.start().add("name", "hisFacIns-sent-idx").get();
        collection.createIndex(indexKeys, indexOptions);
    }
}
