package com.trss.bi.service;

import com.trss.bi.domain.alert.*;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.Event;
import com.trss.bi.domain.factinstance.EventType;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.domain.factinstance.HistoricalFactInstance;
import com.trss.bi.repository.*;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.aws.ApiAlertService;
import com.trss.bi.service.dto.AlertDTO;
import com.trss.bi.service.dto.AlertFilterDTO;
import com.trss.bi.service.dto.FactInstanceDTO;
import com.trss.bi.service.mapper.AlertMapper;
import com.trss.bi.service.mapper.FactInstanceMapper;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class AlertService extends com.trss.bi.service.Service<Alert> {

    private AlertRepository alertRepository;
    private HistoricalFactInstanceRepository historicalFactInstanceRepository;
    private FactFeedbackRepository factFeedbackRepository;
    private FactRepository factRepository;
    private TaxonomyNodeService taxonomyNodeService;
    private FactInstanceMapper factInstanceMapper = new FactInstanceMapper();
    private AlertMapper alertMapper = new AlertMapper();
    private String baseUrl;
    private ApiAlertService apiAlertService;
    private MongoTemplate mongoTemplate;

    @Autowired
    public AlertService(AlertRepository alertRepository, TaxonomyNodeService taxonomyNodeService,
                        HistoricalFactInstanceRepository historicalFactInstanceRepository,
                        FactFeedbackRepository factFeedbackRepository, FactRepository factRepository,
                        @Value("${baseUrl}") String baseUrl, MongoTemplate mongoTemplate, ApiAlertService apiAlertService) {
        super(alertRepository);
        this.alertRepository = alertRepository;
        this.taxonomyNodeService = taxonomyNodeService;
        this.historicalFactInstanceRepository = historicalFactInstanceRepository;
        this.factFeedbackRepository = factFeedbackRepository;
        this.factRepository = factRepository;
        this.baseUrl = baseUrl;
        this.apiAlertService = apiAlertService;
        this.mongoTemplate = mongoTemplate;
    }

    public AlertDTO addFactInstance(Alert alert, FactInstance factInstance) {
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        Long customerId = SecurityUtils.getCurrentCustomerId();

        factInstance.setLastModifiedBy(username);
        factInstance.setLastModifiedDate(Instant.now());
        factInstance.addEvent(
            new Event()
                .type(EventType.ADDED_TO_ALERT_QUEUE)
                .description("Added to Outbox")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
        );

        alert.addFactInstance(factInstance);
        alert.setCustomerId(customerId); // Set CustomerId of the alert as current customer id

        return save(alert);
    }

    public AlertDTO addFactInstanceCreateOrUpdate(FactInstance factInstance) {
        Alert alert = alertRepository.findByClientEntityId(factInstance.getSelectedClientEntity().getId());
        if (alert == null) {
            alert = new Alert();
            alert.setClientEntityId(factInstance.getSelectedClientEntity().getId());
            alert.setClientEntity(factInstance.getSelectedClientEntity());
        }

        return addFactInstance(alert, factInstance);
    }

    public void createOrUpdateWithNotes(FactInstance factInstance, String clientNotes, String analystNotes) {
        Alert alert = alertRepository.findByClientEntityId(factInstance.getSelectedClientEntity().getId());
        if (alert == null) {
            alert = new Alert();
            alert.setClientEntityId(factInstance.getSelectedClientEntity().getId());
            alert.setClientEntity(factInstance.getSelectedClientEntity());
        }

        alert.setClientNotes(clientNotes);
        alert.setAnalystNotes(analystNotes);

        addFactInstance(alert, factInstance);
    }

    public void exportAlertsByAlertIds(List<String> ids, OutputStream outputStream) throws IOException {

        List<ObjectId> objectIds = ids.stream().map(ObjectId::new).collect(Collectors.toList());
        List<Alert> alerts = alertRepository.findAllByIdInOrderByCreatedDateAsc(objectIds);
        AlertExportCsvWriter alertExportCsvWriter = new AlertExportCsvWriter(outputStream, taxonomyNodeService.getUriDisplayName(), baseUrl);
        try {
            for (Alert alert : alerts) {
                alertExportCsvWriter.writeAlertToCsv(alert);
            }
            alertExportCsvWriter.finishCsv();
            alerts.forEach(alert -> acceptAlertAndArchive(alert, EventType.EXPORTED));
        } catch (Exception e) {
            alertExportCsvWriter.closeWriters();
        }
    }

    public void sendAlertToApi(String alertId) {
        Alert alert = findById(alertId);
        apiAlertService.convertAndSendToApi(alert);
        acceptAlertAndArchive(alert, EventType.EXPORTED);
    }

    private void saveAlertFeedback(Alert alert, FeedbackType feedbackType, String reason, String comments) {
        alert.getFactInstances().forEach(factInstance -> {
            Fact originalFact = factRepository.findById(factInstance.getFactId())
                .orElseThrow(() -> new RuntimeException("No Fact found for factId: " + factInstance.getFactId()));
            FactFeedback feedback = new FactFeedback(originalFact, factInstance, feedbackType);
            if (reason != null) {
                feedback.setIgnoreReason(reason);
            }
            if (comments != null) {
                feedback.setComments(comments);
            }
            factFeedbackRepository.save(feedback);
        });
    }

    public AlertDTO update(AlertDTO alertDTO) {
        // Used to remove instances in an alert
        Alert alert = findById(alertDTO.getId());
        Set<ObjectId> newFactInstanceIds = alertDTO.getFactInstances().stream().map(factInstanceDTO -> new ObjectId(factInstanceDTO.getId())).collect(Collectors.toSet());
        if (newFactInstanceIds.size() < alert.getFactInstances().size()) {
            // we need to save the original alert with only fact instances matching the incoming alert so we do not update the timestamps
            Map<Boolean, List<FactInstance>> boolIncludedFactInstancesMap = alert.getFactInstances().stream()
                .collect(Collectors.partitioningBy(factInstance -> newFactInstanceIds.contains(factInstance.getId())));

            alert.setFactInstances(boolIncludedFactInstancesMap.get(true));

            Long customerId = SecurityUtils.getCurrentCustomerId();
            boolIncludedFactInstancesMap.get(false).forEach(factInstance -> historicalFactInstanceRepository.save(new HistoricalFactInstance(factInstance, EventType.REMOVED_FROM_OUTBOX, alert.getAnalystNotes(), alert.getClientNotes(), customerId)));
            return save(alert);
        }
        return save(alertDTO);

    }

    public Alert update(Alert alert) {
        return alertMapper.toEntity(save(alert));
    }

    public AlertDTO updateFactInstanceOnAlert(String alertId, FactInstanceDTO factInstanceDTO) {
        // find the associated alert
        Alert alert = findById(alertId);

        // find the fact instance on the alert
        OptionalInt maybeIndex = IntStream.range(0, alert.getFactInstances().size())
            .filter(i -> alert.getFactInstances().get(i).getId().toString().equals(factInstanceDTO.getId()))
            .findFirst();

        // if we found it, replace it and add an event
        if (maybeIndex.isPresent()) {
            String username = SecurityUtils.getCurrentUserLogin().orElse("");

            FactInstance factInstance = factInstanceMapper.toEntity(factInstanceDTO);
            factInstance.setLastModifiedBy(username);
            factInstance.addEvent(new Event()
                .type(EventType.EDITED_ON_ALERT)
                .description("Edited in Outbox")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString()));

            Optional<FactInstance> maybeOldFactInstance = alert.getFactInstances().stream().filter(fi -> fi.getId().equals(factInstance.getId())).findFirst();
            maybeOldFactInstance.ifPresent(instance -> FactInstanceService.updateEventDetails(instance, factInstance));

            alert.getFactInstances().set(maybeIndex.getAsInt(), factInstance);

            return save(alert);
        }

        throw new RuntimeException("Fact Instance (" + factInstanceDTO.getId() + ") not found on Alert (" + alertId + ")");
    }

    public void delete(String alertId) {
        alertRepository.deleteById(new ObjectId(alertId));
    }

    public List<AlertDTO> findAllById(List<String> ids) {
        List<ObjectId> objectIds = ids.stream().map(ObjectId::new).collect(Collectors.toList());
        return alertMapper.toDto(alertRepository.findByIdInAndCustomerId(objectIds, SecurityUtils.getCurrentCustomerId()));
    }

    // TODO: paging
    public List<AlertDTO> findAll() {
        return alertMapper.toDto(alertRepository.findAllByCustomerIdOrderByCreatedDateAsc(SecurityUtils.getCurrentCustomerId()));
    }

    public AlertDTO findByClientEntityId(String clientEntityId) {
        return alertMapper.toDto(alertRepository.findByClientEntityId(clientEntityId));
    }

    public List<AlertDTO> findByRiskUri(String riskUri) {
        return alertMapper.toDto(alertRepository.findAllByFactInstances_RiskTaxonomyNodeId(riskUri));
    }

    public AlertDTO saveAnalystNotes(String alertId, String notes) {
        Alert alert = findById(alertId);
        alert.setAnalystNotes(notes);
        return save(alert);
    }

    public AlertDTO saveClientNotes(String alertId, String notes) {
        Alert alert = findById(alertId);
        alert.setClientNotes(notes);
        return save(alert);
    }

    public void ignore(String alertId, String reason, String comments) {
        Alert alert = findById(alertId);
        Long customerId = SecurityUtils.getCurrentCustomerId();

        saveAlertFeedback(alert, FeedbackType.IGNORED, reason, comments);

        alert.getFactInstances().forEach(instance -> {
            HistoricalFactInstance historicalFactInstance = new HistoricalFactInstance(instance, EventType.REMOVED_FROM_OUTBOX, alert.getAnalystNotes(), alert.getClientNotes(), customerId);
            historicalFactInstanceRepository.save(historicalFactInstance);
        });
        alertRepository.delete(alert);
    }

    public List<AlertDTO> findByFilters(AlertFilterDTO filters) {
        Query query = buildAlertQuery(filters);
        List<Alert> list = mongoTemplate.find(query, Alert.class);
        return list.stream().map(alert -> alertMapper.toDto(alert)).collect(Collectors.toList());
    }

    private Query buildAlertQuery(AlertFilterDTO filters) {
        Query query = new Query();
        Criteria criteria = new Criteria();

        // Get alerts only for current customerId
        criteria.and("customerId").is(SecurityUtils.getCurrentCustomerId());

        if (!CollectionUtils.isEmpty(filters.getRisks())) {
            criteria = criteria.and("factInstances.riskTaxonomyNodeId").in(filters.getRisks().toArray());
        }
        if (!CollectionUtils.isEmpty(filters.getPredicates())) {
            criteria = criteria.and("factInstances.predicateTaxonomyNodeId").in(filters.getPredicates().toArray());
        }
        if (!CollectionUtils.isEmpty(filters.getEntities())) {
            criteria = criteria.and("factInstances.selectedClientEntity.name").in(filters.getEntities().toArray());
        }
        if (!CollectionUtils.isEmpty(filters.getEntityTypes())) {
            criteria = criteria.and("factInstances.selectedClientEntity.type").in(filters.getEntityTypes().toArray());
        }
        if (!CollectionUtils.isEmpty(filters.getScreeners())) {
            criteria = criteria.and("factInstances.lastModifiedBy").in(filters.getScreeners().toArray());
        }

        if (filters.getStartDate() != null && filters.getEndDate() != null) {
            criteria = criteria.and("factInstances.last_modified_date").gte(filters.getStartDate().toInstant()).lte(filters.getEndDate().toInstant());
        }
        else if (filters.getStartDate() != null) {
            criteria = criteria.and("factInstances.last_modified_date").gte(filters.getStartDate().toInstant());
        }
        else if (filters.getEndDate() != null) {
            criteria = criteria.and("factInstances.last_modified_date").lte(filters.getEndDate().toInstant());
        }

        query.addCriteria(criteria);

        return query;
    }

    public List<Alert> findByFactInstanceFactId(ObjectId factId) {
        return alertRepository.findAllByFactInstances_FactId(factId);
    }

    private Alert findById(String alertId) {
        return alertRepository.findByIdAndCustomerId(new ObjectId(alertId), SecurityUtils.getCurrentCustomerId())
            .orElseThrow(() -> new RuntimeException("No Alert found for alertId: " + alertId + ", customerId: " + SecurityUtils.getCurrentCustomerId()));
    }

    public AlertDTO save(AlertDTO alertDTO) {
        return save(alertMapper.toEntity(alertDTO));
    }

    public AlertDTO save(Alert alert) {
        return alertMapper.toDto(save(alert, alert.getId()));
    }

    public void acceptAlertAndArchive(Alert alert, EventType eventType) {
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        Long customerId = SecurityUtils.getCurrentCustomerId();

        saveAlertFeedback(alert, FeedbackType.ACCEPTED, null, null);
        alert.getFactInstances().forEach(instance -> {
            instance.setLastModifiedBy(username);
            instance.setLastModifiedDate(Instant.now());
            HistoricalFactInstance historicalFactInstance = new HistoricalFactInstance(instance, eventType, alert.getAnalystNotes(), alert.getClientNotes(), customerId);
            historicalFactInstanceRepository.save(historicalFactInstance);
        });
        alertRepository.delete(alert);
    }

    public List findDistinctRisks() {
        return findDistinctWithCount("riskTaxonomyNodeId");
    }

    public List findDistinctPredicates() {
        return findDistinctWithCount("predicateTaxonomyNodeId");
    }

    public List findDistinctScreeners() {
        return findDistinctWithCount("last_modified_by");
    }

    private List findDistinctWithCount(String property) {
        Aggregation agg = Aggregation.newAggregation(
            Aggregation.match(Criteria.where("customerId").is(SecurityUtils.getCurrentCustomerId())),
            Aggregation.unwind("factInstances"),
            Aggregation.replaceRoot("factInstances"),
            Aggregation.group(property).count().as("total"),
            Aggregation.sort(Sort.Direction.DESC, "total")
        );

        AggregationResults results = mongoTemplate.aggregate(agg, "alert", Map.class);

        return results.getMappedResults();
    }
}
