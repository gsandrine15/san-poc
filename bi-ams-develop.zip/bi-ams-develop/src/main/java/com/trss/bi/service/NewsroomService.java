package com.trss.bi.service;

import com.trss.bi.domain.NewsroomPublisher;
import com.trss.bi.repository.NewsroomPublisherRepository;
import com.trss.bi.service.dto.ArticleTextDTO;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.lang.StringUtils;
import org.dom4j.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Service for Newsroom API integration.
 */
@Service
public class NewsroomService {

    private final Logger log = LoggerFactory.getLogger(NewsroomService.class);

    @Value("${newsroom.documentUrl}")
    protected String newsroomDocumentUrl;
    @Value("${newsroom.apiKey}")
    protected String apiKey;

    protected Configuration newsroomFreemarkerConfiguration;
    protected RestTemplate newsroomRestTemplate;
    protected NewsroomPublisherRepository newsroomPublisherRepository;

    private final static NewsroomPublisher UNKNOWN_PUBLISHER = new NewsroomPublisher();
    static {
        UNKNOWN_PUBLISHER.setJournalName("Unknown Publisher");
    }

    /**
     * Constructor.
     *
     * @param newsroomRestTemplate Newsroom RestTemplate
     * @param newsroomFreemarkerConfiguration Newsroom freemarker configuration
     */
    public NewsroomService(RestTemplate newsroomRestTemplate, Configuration newsroomFreemarkerConfiguration, NewsroomPublisherRepository newsroomPublisherRepository) {
        this.newsroomFreemarkerConfiguration = newsroomFreemarkerConfiguration;
        this.newsroomRestTemplate = newsroomRestTemplate;
        this.newsroomPublisherRepository = newsroomPublisherRepository;
    }

    /**
     * Get article text from Newsroom via adverse media feed news source id.
     *
     * @param id Adverse media feed news source id
     * @return ArticleTextDTO
     */
    public ArticleTextDTO getArticleText(String id) {
        if(id.startsWith("tag:reuters.com")) {
            String firstCandidate = StringUtils.substringAfter(id, "_");
            String secondCandidate = StringUtils.substringBefore(firstCandidate, ":");

            String pnac;
            if(!secondCandidate.startsWith("n")) {
                pnac = "n" + secondCandidate;
            } else {
                pnac = secondCandidate;
            }

            return getArticleTextByPnac(pnac);
        } else {
            //guid
            return getArticleTextByGuid(id);
        }
    }

    /**
     * Get article text from Newsroom via PNAC.
     *
     * @param pnac The PNAC
     * @return ArticleTextDTO
     */
    public ArticleTextDTO getArticleTextByPnac(String pnac) {
        String date = new SimpleDateFormat("yyyyMMdd").format(new Date());
        HashMap<String, Object> templateProps = new HashMap<>();
        templateProps.put("pnacs", Arrays.asList(pnac));
        templateProps.put("date", date);

        try {
            Template template = newsroomFreemarkerConfiguration.getTemplate("document-by-pnac-request.ftl");

            StringWriter sw = new StringWriter();
            template.process(templateProps, sw);

            ResponseEntity<String> response = postRequest(sw.toString());

            return processResponse(pnac, response);
        } catch (Exception e) {
            ArticleTextDTO errorResponse = new ArticleTextDTO();
            errorResponse.setId(pnac);
            errorResponse.setErrorMessage(e.getMessage());
            return errorResponse;
        }
    }

    /**
     * Get article text from Newsroom via GUID.
     *
     * @param guid The GUID
     * @return ArticleTextDTO
     */
    public ArticleTextDTO getArticleTextByGuid(String guid) {
        HashMap<String, Object> root = new HashMap<>();
        root.put("guids", Arrays.asList(guid));

        try {
            Template template = newsroomFreemarkerConfiguration.getTemplate("document-by-guid-request.ftl");

            StringWriter sw = new StringWriter();
            template.process(root, sw);

            ResponseEntity<String> response = postRequest(sw.toString());

            return processResponse(guid, response);
        } catch (Exception e) {
            ArticleTextDTO errorResponse = new ArticleTextDTO();
            errorResponse.setId(guid);
            errorResponse.setErrorMessage(e.getMessage());
            return errorResponse;
        }
    }

    /**
     * Post Newsroom API request.
     *
     * @param body Request body.
     * @return ResponseEntity
     */
    private ResponseEntity<String> postRequest(String body) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/xml;charset=UTF-8");
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.set("x-nr-apikey", apiKey);

        final HttpEntity<String> entity = new HttpEntity<>(body, headers);

        return newsroomRestTemplate.exchange(newsroomDocumentUrl, HttpMethod.POST, entity, String.class);
    }

    /**
     * Process the Newsroom API response.
     *
     * @param id Document id
     * @param response ResponseEntity
     * @return ArticleTextDTO
     */
    private ArticleTextDTO processResponse(String id, ResponseEntity<String> response) {
        ArticleTextDTO articleTextResponse = new ArticleTextDTO();
        if(response.getStatusCode().is2xxSuccessful()) {
            articleTextResponse.setId(id);
            try {
                Document document = DocumentHelper.parseText(response.getBody());
                Element newsItemElement = document.getRootElement().element("doc").element("newsItem");
                if(newsItemElement != null) {
                    Element itemMetaElement = newsItemElement.element("itemMeta");
                    if(itemMetaElement != null) {
                        Element titleElement = itemMetaElement.element("title");
                        if(titleElement != null) {
                            articleTextResponse.setArticleTitle(titleElement.getStringValue());
                        }

                        Element firstCreatedElement = itemMetaElement.element("firstCreated");
                        if(firstCreatedElement != null) {
                            String firstCreatedString = firstCreatedElement.getStringValue();
                            try {
                                articleTextResponse.setPublishedDate(Instant.parse(firstCreatedString));
                            } catch(DateTimeParseException e) {
                                log.warn("Unable to parse firstCreated date value: {} for guid: {}", firstCreatedString, id);
                            }
                        }

                        // get publication info
                        Element pubInfoElement = itemMetaElement.element("pubInfo");
                        if (pubInfoElement != null) {
                            Element publicationElement = pubInfoElement.element("publication");
                            if (publicationElement != null) {
                                String pubCode = publicationElement.attributeValue("pubCode");
                                String journalCode = publicationElement.attributeValue("journalCode");
                                NewsroomPublisher publisher = findNewsroomPublisher(pubCode, journalCode);
                                articleTextResponse.setJournalName(publisher.getJournalName());
                            }
                        }
                    }

                    Element contentSetElement = newsItemElement.element("contentSet");

                    if(contentSetElement != null) {
                        // article text available
                        Element inlineXmlElement = contentSetElement.element("inlineXML");
                        if(inlineXmlElement != null) {
                            Element htmlElement = inlineXmlElement.element("html");
                            if(htmlElement != null) {
                                articleTextResponse.setArticleHtml(htmlElement.asXML());
                            }
                        }

                        // no article text but remote url available
                        Element remoteContentElement = contentSetElement.element("remoteContent");
                        if(remoteContentElement != null) {
                            articleTextResponse.setUrl(remoteContentElement.attributeValue("href"));
                        }
                    }
                }
            } catch (Exception e) {
                articleTextResponse.setErrorMessage("Error parsing Newsroom response. " + e.getMessage());
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Newsroom API Error - ")
                .append(response.getStatusCodeValue())
                .append(" ")
                .append(response.getBody());

            articleTextResponse.setId(id);
            articleTextResponse.setErrorMessage(sb.toString());
        }
        return articleTextResponse;
    }

    /**
     * finds the newsroom publisher by pubCode and/or journalCode
     * @param pubCode
     * @param journalCode
     * @return
     */
    private NewsroomPublisher findNewsroomPublisher(String pubCode, String journalCode) {
        if (StringUtils.isNotBlank(pubCode) && StringUtils.isNotBlank(journalCode)) {
            NewsroomPublisher publisher = newsroomPublisherRepository.findByPubCodeAndJournalCode(pubCode, journalCode);
            if (publisher == null) {
                log.warn("Publisher with pubCode={} and journalCode={} was not found in our system. Returning unknown publisher.", pubCode, journalCode);
                publisher = UNKNOWN_PUBLISHER;
            }
            return publisher;
        }
        if (StringUtils.isNotBlank(pubCode)) {
            NewsroomPublisher publisher = newsroomPublisherRepository.findByPubCode(pubCode);
            if (publisher == null) {
                log.warn("Publisher with pubCode={} was not found in our system. Returning unknown publisher.", pubCode);
                publisher = UNKNOWN_PUBLISHER;
            }
            return publisher;
        }
        if (StringUtils.isNotBlank(journalCode)) {
            NewsroomPublisher publisher = newsroomPublisherRepository.findByJournalCode(journalCode);
            if (publisher == null) {
                log.warn("Publisher with journalCode={} was not found in our system. Returning unknown publisher.", journalCode);
                publisher = UNKNOWN_PUBLISHER;
            }
            return publisher;
        }
        log.warn("No publisher information was found.");
        return UNKNOWN_PUBLISHER;

    }
}
