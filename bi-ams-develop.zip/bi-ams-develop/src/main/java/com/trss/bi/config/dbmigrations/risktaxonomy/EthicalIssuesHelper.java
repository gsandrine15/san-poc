package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class EthicalIssuesHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/ethicalissues";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode ethicalIssues = helper.insertNode(rootNode, BASE_URI, "ETHICAL_ISSUES", "Ethical Issues",
            "This is ethical issues");

        // insert all the children
        helper.insertNode(ethicalIssues, BASE_URI + "/animalwelfare", "ANIMAL_WELFARE", "Animal Welfare",
            "This is animal welfare");

        helper.insertNode(ethicalIssues, BASE_URI + "/ecocrime", "ECO_CRIME", "Eco Crime",
            "This is eco crime");

        helper.insertNode(ethicalIssues, BASE_URI + "/healthsafety", "HEALTH_SAFETY", "Health & Safety",
            "This is health and safety");

        helper.insertNode(ethicalIssues, BASE_URI + "/humanrightsbreach", "HUMAN_RIGHTS_BREACH", "Human Rights Breach",
            "This is human rights");

        helper.insertNode(ethicalIssues, BASE_URI + "/mangementcompensation", "MANAGEMENT_COMP", "Management Compensation",
            "This is management compensation");

        helper.insertNode(ethicalIssues, BASE_URI + "/nonecopractice", "NON_ECO_PRACTICE", "Non Eco Practice",
            "This is non eco practice");

        helper.insertNode(ethicalIssues, BASE_URI + "/withholding", "WITHHOLDING", "Withholding",
            "This is withholding");
    }
}
