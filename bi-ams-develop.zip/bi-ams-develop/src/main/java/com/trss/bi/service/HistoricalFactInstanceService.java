package com.trss.bi.service;

import com.trss.bi.domain.factinstance.*;
import com.trss.bi.repository.HistoricalFactInstanceRepository;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.dto.HistoricalFactInstanceFilterDTO;
import com.trss.bi.service.dto.HistoricalFactInstanceDTO;
import com.trss.bi.service.mapper.HistoricalFactInstanceMapper;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class HistoricalFactInstanceService {
    private HistoricalFactInstanceRepository historicalFactInstanceRepository;
    private MongoTemplate mongoTemplate;
    private FactInstanceService factInstanceService;
    private AlertService alertService;
    private HistoricalFactInstanceMapper historicalFactInstanceMapper = new HistoricalFactInstanceMapper();

    public HistoricalFactInstanceService(HistoricalFactInstanceRepository historicalFactInstanceRepository, MongoTemplate mongoTemplate, FactInstanceService factInstanceService, AlertService alertService) {
        this.historicalFactInstanceRepository = historicalFactInstanceRepository;
        this.mongoTemplate = mongoTemplate;
        this.factInstanceService = factInstanceService;
        this.alertService = alertService;
    }

    public Page<HistoricalFactInstanceDTO> findHistoricalFactInstances(Pageable pageable, HistoricalFactInstanceFilterDTO historicalFactInstanceFilterDTO) {
        Query query = buildHistoricalFactInstanceQuery(pageable, historicalFactInstanceFilterDTO);
        List<HistoricalFactInstance> list = mongoTemplate.find(query, HistoricalFactInstance.class);
        long count = mongoTemplate.count(query.limit(-1).skip(-1), HistoricalFactInstance.class);

        Page<HistoricalFactInstance> factInstancePage = new PageImpl<>(list, pageable, count);

        return factInstancePage.map(historicalFactInstanceMapper::toDto);
    }

    public List<HistoricalFactInstance> findFactInstanceByInstanceIdAndCustomerId(ObjectId id, Long customerId) {
        return historicalFactInstanceRepository.findAllByFactInstance_FactIdAndCustomerId(id, customerId);
    }

    public void sendToInbox(String factIdString, String queueIdString) {
        ObjectId factId = new ObjectId(factIdString);
        ObjectId queueId = new ObjectId(queueIdString);

        Long customerId = SecurityUtils.getCurrentCustomerId();

        HistoricalFactInstance historicalFactInstance = findFactInstanceByInstanceIdAndCustomerId(factId, customerId).stream().findFirst().orElseThrow(() -> new RuntimeException("No Historical Alert found for fact id: " + factId));
        FactInstance factInstance = historicalFactInstance.getFactInstance();

        factInstanceService.moveToQueue(factInstance, queueId);
        historicalFactInstanceRepository.deleteAllByFactInstance_FactIdAndCustomerId(factId, customerId);
    }

    public void sendToOutbox(String factIdString, Boolean overwriteNotes) {
        ObjectId factId = new ObjectId(factIdString);
        Long customerId = SecurityUtils.getCurrentCustomerId();
        HistoricalFactInstance historicalFactInstance = findFactInstanceByInstanceIdAndCustomerId(factId, customerId).stream().findFirst().orElseThrow(() -> new RuntimeException("No Historical Alert found for fact id: " + factId));
        FactInstance factInstance = historicalFactInstance.getFactInstance();
        if (overwriteNotes) {
            alertService.createOrUpdateWithNotes(factInstance, historicalFactInstance.getClientNotes(), historicalFactInstance.getAnalystNotes());
        } else {
            alertService.addFactInstanceCreateOrUpdate(factInstance);
        }

        historicalFactInstanceRepository.deleteAllByFactInstance_FactIdAndCustomerId(factId, customerId);
    }

    public Long deleteByFactIds(List<ObjectId> factIds) {
        return historicalFactInstanceRepository.deleteAllByFactInstance_FactIdIn(factIds);
    }

    public List<String> findClientEntityNamesByNameSubstring(String nameSubstringLowerCase) {
        Query query = buildEntityNamesRegexSearchQuery(null, Pattern.quote(nameSubstringLowerCase)); //use Pattern.quote as strings can interfere with regex patterns (particularly special characters)
        Pattern pattern = Pattern.compile("(\\s|^)(" + Pattern.quote(nameSubstringLowerCase) + ")+"); // this is used to search the beginning of any space-separated word
        query.addCriteria(Criteria.where("customerId").is(SecurityUtils.getCurrentCustomerId()));
        List<HistoricalFactInstance> historicalFactInstances = mongoTemplate.find(query, HistoricalFactInstance.class);
        return historicalFactInstances.stream().map(HistoricalFactInstance::getFactInstance)
            .map(FactInstance::getSelectedClientEntity)
            .map(ClientEntity::getName)
            .filter(ce -> pattern.matcher(ce.toLowerCase()).find())
            .distinct()
            .sorted()
            .collect(Collectors.toList());
    }

    private List findDistinctWithCount(String taxonomyNodeId) {
        Aggregation agg = Aggregation.newAggregation(
            Aggregation.match(Criteria.where("customerId").is(SecurityUtils.getCurrentCustomerId())),
            Aggregation.group(taxonomyNodeId).count().as("total"),
            Aggregation.sort(Sort.Direction.DESC, "total")
        );

        AggregationResults results = mongoTemplate.aggregate(agg, "hisFacIns", Map.class);

        return results.getMappedResults();
    }

    public List findDistinctRisks() {
        return findDistinctWithCount("factInstance.riskTaxonomyNodeId");
    }

    public List findDistinctPredicates() {
        return findDistinctWithCount("factInstance.predicateTaxonomyNodeId");
    }

    public List findDistinctScreeners() {
        return findDistinctWithCount("factInstance.last_modified_by");
    }

    public List findDistinctResolutions() {
        return findDistinctWithCount("archivedReason");
    }


    private Query buildEntityNamesRegexSearchQuery(Pageable pageable, String nameSubstringLowerCase) {
        Query query = new Query();
        Criteria criteria = Criteria.where("factInstance.entities.name").regex("([\\s]|^)" + nameSubstringLowerCase, "i");
        query.addCriteria(criteria);
        if (pageable != null) {
            query.with(pageable);
        }
        return query;
    }

    private Query buildHistoricalFactInstanceQuery(Pageable pageable, HistoricalFactInstanceFilterDTO filters) {
        Query query = new Query();
        query.addCriteria(buildHistoricalFactInstanceCriteria(filters));

        if (pageable != null) {
            query.with(pageable);
        }

        query.addCriteria(Criteria.where("customerId").is(SecurityUtils.getCurrentCustomerId()));

        return query;
    }

    private Criteria buildDateCriteria(Criteria criteria, HistoricalFactInstanceFilterDTO filters) {
        if (filters.getStartDate() != null || filters.getEndDate() != null) {
            if (filters.getStartDate() != null && filters.getEndDate() != null) {
                return criteria.and("factInstance.sent").gte(filters.getStartDate().toInstant()).lte(filters.getEndDate().toInstant());
            }
            if (filters.getStartDate() != null) {
                return criteria.and("factInstance.sent").gte(filters.getStartDate().toInstant());
            }
            if (filters.getEndDate() != null) {
                return criteria.and("factInstance.sent").lte(filters.getEndDate().toInstant());
            }
        }
        return criteria;
    }

    private Criteria buildHistoricalFactInstanceCriteria(HistoricalFactInstanceFilterDTO filters) {

        Criteria criteria = new Criteria();

        if (!CollectionUtils.isEmpty(filters.getRisks())) {
            criteria = criteria.and("factInstance.riskTaxonomyNodeId").in(filters.getRisks().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getPredicates())) {
            criteria = criteria.and("factInstance.predicateTaxonomyNodeId").in(filters.getPredicates().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getEntities())) {
            criteria = criteria.and("factInstance.selectedClientEntity.name").in(filters.getEntities().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getEntityTypes())) {
            criteria = criteria.and("factInstance.selectedClientEntity.type").in(filters.getEntityTypes().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getResolutions())) {
            criteria = criteria.and("archivedReason").in(filters.getResolutions().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getScreeners())) {
            criteria = criteria.and("factInstance.lastModifiedBy").in(filters.getScreeners().toArray());
        }

        criteria = buildDateCriteria(criteria, filters);

        return criteria;
    }
}
