package com.trss.bi.config.dbmigrations.predtaxonomy;

import java.util.HashMap;
import java.util.Map;

public class CodeConfig {

    public static Map<String,String> URI_CODES_5_27_2021 = new HashMap<>();

    static {
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to", "IS_RELATED_TO");
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_suspected_of", "IS_SUSPECTED_OF");
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_charged_with", "IS_CHARGED_WITH");
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_convicted_of", "IS_CONVICTED_OF");
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_acquitted_of", "IS_ACQUITTED_OF");
        URI_CODES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/case_dismissed", "CASE_DISMISSED");
    }
}
