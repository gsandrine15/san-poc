package com.trss.bi.domain.factinstance;

import java.util.Optional;

public enum EventType {

    NEW("NEW"),
    OPENED("OPENED"),
    EDITED("EDITED"),
    EDITED_ON_ALERT("EDITED_ON_ALERT"),
    ADDED_TO_ALERT_QUEUE("ADDED_TO_ALERT_QUEUE"),
    SENT_TO_CLIENT("SENT_TO_CLIENT"),
    IGNORED("DISCARDED"),
    REMOVED_FROM_OUTBOX("DISCARDED"),
    EXPORTED("EXPORTED"),
    FLAGGED("FLAGGED"),
    UNFLAGGED("UNFLAGGED"),
    NOTES_SAVED("NOTES_SAVED"),
    ARTICLE_REMOVED("ARTICLE_REMOVED"),
    RETURNED_TO_FOLDER("RETURNED_TO_FOLDER");

    private final String value;

    EventType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static Optional<EventType> getByValueString(String stringValue){
        for(EventType v : values()){
            if( v.getValue().equals(stringValue)){
                return Optional.of(v);
            }
        }
        return Optional.empty();
    }
}
