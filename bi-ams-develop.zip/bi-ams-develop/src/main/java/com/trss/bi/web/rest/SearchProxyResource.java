package com.trss.bi.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.mvc.ProxyExchange;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

import static com.trss.bi.security.AuthorizationConstants.ACCESS_SEARCH;

@RestController
@PreAuthorize(ACCESS_SEARCH)
@RequestMapping("/api/search")
public class SearchProxyResource {

    private final Logger log = LoggerFactory.getLogger(SearchProxyResource.class);


    @Value("${elasticsearch.historicalsearch.baseUrl}")
    private URI historicalSearchUri;

    @GetMapping("/**/_search")
    public ResponseEntity<?> proxySearchPathGet(ProxyExchange<byte[]> proxy) throws Exception {
        if (!isAllowablePath(proxy.path())) {
            throw new UnsupportedOperationException("path is not supported");
        }
        return proxy.uri(historicalSearchUri.toString() + proxy.path("/api/search")).get();
    }

    @PostMapping("/**/_search")
    public ResponseEntity<?> proxySearchPathPost(ProxyExchange<byte[]> proxy) throws Exception {
        if (!isAllowablePath(proxy.path())) {
            throw new UnsupportedOperationException("path is not supported");
        }
        return proxy.uri(historicalSearchUri.toString() + proxy.path("/api/search")).post();
    }

    private boolean isAllowablePath(String path) {
        String removedPrefixPath = path.replace("/api/search/", "");
        String[] pathParts = removedPrefixPath.split("/");
        if (pathParts.length != 2) return false;
        return "_search".equals(pathParts[1]);
    }
}
