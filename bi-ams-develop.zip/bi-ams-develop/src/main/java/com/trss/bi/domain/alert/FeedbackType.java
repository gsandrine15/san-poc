package com.trss.bi.domain.alert;

public enum FeedbackType {
    ACCEPTED("ACCEPTED"),
    ACCEPTED_CHANGED("ACCEPTED_CHANGED"),
    IGNORED("IGNORED");

    private final String value;

    FeedbackType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
