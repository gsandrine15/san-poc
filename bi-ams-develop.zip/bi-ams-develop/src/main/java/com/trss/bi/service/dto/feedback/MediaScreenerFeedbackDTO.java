package com.trss.bi.service.dto.feedback;

import java.util.List;

/**
 * Represents an media screener feedback payload.
 */
public class MediaScreenerFeedbackDTO {

    protected String trssFeedRouterId;
    protected String msFactId;
    protected List<MediaScreenerFeedbackItemDTO> feedback;

    public String getTrssFeedRouterId() {
        return trssFeedRouterId;
    }

    public void setTrssFeedRouterId(String trssFeedRouterId) {
        this.trssFeedRouterId = trssFeedRouterId;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public List<MediaScreenerFeedbackItemDTO> getFeedback() {
        return feedback;
    }

    public void setFeedback(List<MediaScreenerFeedbackItemDTO> feedback) {
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return "MediaScreenerFeedbackDTO{" +
            "trssFeedRouterId='" + trssFeedRouterId + '\'' +
            ", msFactId='" + msFactId + '\'' +
            ", feedback=" + feedback +
            '}';
    }
}
