package com.trss.bi.service;

import com.trss.bi.config.RabbitConfiguration;
import com.trss.bi.service.dto.FeedItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class FeedItemSender {
    private Logger logger = LoggerFactory.getLogger(FeedItemSender.class);

    @Value("${rabbit.fact-feed.exchange}")
    private String exchangeName;

    private RabbitTemplate rabbitTemplate;

    public FeedItemSender(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendFeedItem(FeedItemDTO feedItemDTO) {
        rabbitTemplate.convertAndSend(exchangeName, RabbitConfiguration.KEY_FACT_FEED, feedItemDTO);
        logger.info("Sent feed item. Exchange: " + exchangeName + ", feedItem: " + feedItemDTO);
    }

    public void setExchangeName(String exchangeName) {
        this.exchangeName = exchangeName;
    }
}
