package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class TaxationHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/taxation";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode taxation = helper.insertNode(rootNode,
            BASE_URI, "TAXATION", "Taxation", "This is taxation");

        // insert all the taxation children
        helper.insertNode(taxation,
            BASE_URI + "/taxavoidance", "TAX_AVOIDANCE", "Tax Avoidance", "This is tax avoidance");

        helper.insertNode(taxation,
            BASE_URI + "/taxevasion", "TAX_EVASION", "Tax Evasion", "This is tax evasion");

        helper.insertNode(taxation,
            BASE_URI + "/taxhavens", "TAX_HAVENS", "Tax Havens", "This is tax havens");

        helper.insertNode(taxation,
            BASE_URI + "/smuggling", "SMUGGLING", "Smuggling", "This is smuggling");

    }
}
