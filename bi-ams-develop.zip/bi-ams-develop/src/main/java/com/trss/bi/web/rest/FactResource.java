package com.trss.bi.web.rest;

import com.trss.bi.service.FactService;
import com.trss.bi.service.dto.FactDTO;
import com.trss.bi.service.dto.FactInstanceDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class FactResource {

    private FactService factService;

    public FactResource(FactService factService) {
        this.factService = factService;
    }

    @GetMapping("/fact/{id}")
    public FactDTO getFact(@PathVariable String id) {
        return factService.find(id);
    }
}
