package com.trss.bi.repository;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.domain.FactQueue;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FactQueueRepository extends MongoRepository<FactQueue, ObjectId> {
    FactQueue findByFactQueueConfigId(String factQueueConfigId);
    FactQueue findByFactQueueConfigIdAndCustomerId(String factQueueConfigId, Long customerId);
    List<FactQueue> findByName(String name);
    List<FactQueue> findAllByCustomerId(Long customerId);
    Optional<FactQueue> findByIdAndCustomerId(ObjectId id, Long customerId);
    /**
     * @deprecated use {@link com.trss.bi.service.Service#save(AbstractAuditingEntity, ObjectId)} instead
     * @param factQueue
     * @return
     */
    @Deprecated
    FactQueue save(FactQueue factQueue);
}
