package com.trss.bi.domain.alert;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import java.util.List;

public class AlertFeedback {
    @Id
    private ObjectId id;

    private List<FactFeedback> factFeedbacks;

    public AlertFeedback (ObjectId id, List<FactFeedback> factFeedbacks){
        this.id = id;
        this.factFeedbacks = factFeedbacks;
    }

    public ObjectId getId() {
        return id;
    }

    public List<FactFeedback> getFactFeedbacks() {
        return factFeedbacks;
    }
}
