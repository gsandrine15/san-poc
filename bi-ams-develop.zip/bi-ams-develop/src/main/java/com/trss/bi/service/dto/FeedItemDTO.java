package com.trss.bi.service.dto;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.FeedbackItem;
import com.trss.bi.domain.fact.Subject;
import com.trss.bi.domain.factinstance.ClientEntity;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.Instant;
import java.util.List;

public class FeedItemDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    @NotNull private String msFactId;
    @NotNull private String feedRouterId;
    @NotNull private Subject subject;
    @NotNull private String predicate;
    @NotNull private String risk;
    @NotNull private List<ClientEntity> matchCandidates;
    @NotNull private Instant sent;
    @NotNull private List<Article> articles;
    @NotNull private List<String> matchingFactQueueConfigIds;
    @NotNull private double riskConfidence;
    @NotNull private List<FeedbackItem> feedbackItems;

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public List<String> getMatchingFactQueueConfigIds() {
        return matchingFactQueueConfigIds;
    }

    public void setMatchingFactQueueConfigIds(List<String> matchingFactQueueConfigIds) {
        this.matchingFactQueueConfigIds = matchingFactQueueConfigIds;
    }

    public List<ClientEntity> getMatchCandidates() {
        return matchCandidates;
    }

    public void setMatchCandidates(List<ClientEntity> matchCandidates) {
        this.matchCandidates = matchCandidates;
    }

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public String getPredicate() {
        return predicate;
    }

    public void setPredicate(String predicate) {
        this.predicate = predicate;
    }

    public double getRiskConfidence() {
        return riskConfidence;
    }

    public void setRiskConfidence(double riskConfidence) {
        this.riskConfidence = riskConfidence;
    }

    public Instant getSent() {
        return sent;
    }

    public void setSent(Instant sent) {
        this.sent = sent;
    }

    public List<FeedbackItem> getFeedbackItems() {
        return feedbackItems;
    }

    public void setFeedbackItems(List<FeedbackItem> feedbackItems) {
        this.feedbackItems = feedbackItems;
    }

    @Override
    public String toString() {
        return "FeedItemDTO{" +
            "msFactId='" + msFactId + '\'' +
            ", feedRouterId='" + feedRouterId + '\'' +
            ", subject=" + subject +
            ", predicate='" + predicate + '\'' +
            ", risk='" + risk + '\'' +
            ", matchCandidates=" + matchCandidates +
            ", sent=" + sent +
            ", articles=" + articles +
            ", matchingFactQueueConfigIds=" + matchingFactQueueConfigIds +
            ", riskConfidence=" + riskConfidence +
            ", feedbackItems=" + feedbackItems +
            '}';
    }
}
