package com.trss.bi.service.dto.feedback;

/**
 * Represents an entity matcher feedback item.
 */
public class EntityMatcherFeedbackItemDTO {

    protected String entityId;
    protected String entityName;
    protected Double relevancyScore;
    protected String response;

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public Double getRelevancyScore() {
        return relevancyScore;
    }

    public void setRelevancyScore(Double relevancyScore) {
        this.relevancyScore = relevancyScore;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return "EntityMatcherFeedbackItemDTO{" +
            "entityId='" + entityId + '\'' +
            ", entityName='" + entityName + '\'' +
            ", relevancyScore=" + relevancyScore +
            ", response='" + response + '\'' +
            '}';
    }
}
