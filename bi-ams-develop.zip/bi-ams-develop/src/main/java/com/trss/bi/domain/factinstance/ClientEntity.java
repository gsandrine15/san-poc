package com.trss.bi.domain.factinstance;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class ClientEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String externalId;
    private String type;
    private String name;
    private Double confidenceScore;
    private List<String> factQueueConfigIds;
    private String dob = "";
    private String nationality = "";
    private String positionAtCompany = "";
    private String hqAddress = "";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getConfidenceScore() {
        return confidenceScore;
    }

    public void setConfidenceScore(Double confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public void setConfidenceScore(String confidenceScore) {
        this.confidenceScore = Double.valueOf(confidenceScore);
    }

    public List<String> getFactQueueConfigIds() {
        return factQueueConfigIds;
    }

    public void setFactQueueConfigIds(List<String> factQueueConfigIds) {
        this.factQueueConfigIds = factQueueConfigIds;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getPositionAtCompany() {
        return positionAtCompany;
    }

    public void setPositionAtCompany(String positionAtCompany) {
        this.positionAtCompany = positionAtCompany;
    }

    public String getHqAddress() {
        return hqAddress;
    }

    public void setHqAddress(String hqAddress) {
        this.hqAddress = hqAddress;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientEntity that = (ClientEntity) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
