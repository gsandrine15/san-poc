package com.trss.bi.service.dto;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

public class FactInstanceFilterDTO implements Serializable {
    List<String> risks;
    List<String> predicates;
    List<String> entityTypes;
    List<String> entities;
    String entityId;
    String feedRouterId;
    Double minimumConfidenceScore;
    Boolean flag;
    Instant startDate;
    Instant endDate;

    public List<String> getRisks() {
        return risks;
    }

    public void setRisks(List<String> risks) {
        this.risks = risks;
    }

    public List<String> getPredicates() {
        return predicates;
    }

    public void setPredicates(List<String> predicates) {
        this.predicates = predicates;
    }

    public List<String> getEntityTypes() {
        return entityTypes;
    }

    public void setEntityTypes(List<String> entityTypes) {
        this.entityTypes = entityTypes;
    }

    public List<String> getEntities() {
        return entities;
    }

    public void setEntities(List<String> entities) {
        this.entities = entities;
    }

    public Double getMinimumConfidenceScore() {
        return minimumConfidenceScore;
    }

    public void setMinimumConfidenceScore(Double minimumConfidenceScore) {
        this.minimumConfidenceScore = minimumConfidenceScore;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public Instant getStartDate() {
        return startDate;
    }

    public void setStartDate(Instant startDate) {
        this.startDate = startDate;
    }

    public Instant getEndDate() {
        return endDate;
    }

    public void setEndDate(Instant endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "FactInstanceFilterDTO{" +
            "risks=" + risks +
            ", predicates=" + predicates +
            ", entityTypes=" + entityTypes +
            ", entities=" + entities +
            ", entityId='" + entityId + '\'' +
            ", feedRouterId='" + feedRouterId + '\'' +
            ", minimumConfidenceScore=" + minimumConfidenceScore +
            ", flag=" + flag +
            ", startDate=" + startDate +
            ", endDate=" + endDate +
            '}';
    }
}
