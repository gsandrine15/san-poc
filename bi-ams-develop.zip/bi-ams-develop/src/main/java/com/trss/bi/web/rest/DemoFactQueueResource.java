package com.trss.bi.web.rest;

import com.trss.bi.security.AuthorizationConstants;
import com.trss.bi.service.demo.DemoFactQueueService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class DemoFactQueueResource {

    private DemoFactQueueService demoFactQueueService;

    public DemoFactQueueResource(DemoFactQueueService demoFactQueueService) {
        this.demoFactQueueService = demoFactQueueService;
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_ADMIN)
    @GetMapping("/demo-fact-queue/load")
    public Map<String,String> loadDemoQueue(@RequestParam("factQueueName") String factQueueName) {
        Map<String,String> responseData = new HashMap<>();

        String factQueueId = demoFactQueueService.loadDemoQueue(factQueueName);

        // build the response
        responseData.put("factQueueId", factQueueId);
        return responseData;
    }
}
