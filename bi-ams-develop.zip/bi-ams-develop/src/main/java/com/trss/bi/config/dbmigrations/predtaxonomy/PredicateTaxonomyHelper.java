package com.trss.bi.config.dbmigrations.predtaxonomy;

import com.trss.bi.config.dbmigrations.risktaxonomy.TaxonomySetupHelper;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class PredicateTaxonomyHelper {

    private static final String BASE_URI = "https://graph.thomsonreuters.com/fact_type/risk/pred";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate, "PRED");
        TaxonomyNode rootNode = helper.findRootNode("ROOT_PRED");

        TaxonomyNode predicates = helper.insertNode(rootNode, BASE_URI, "PRED", "Predicate",
            "The Predicate in the semantic triple fact");

        // insert all the children
        helper.insertNode(predicates, BASE_URI + "/is_related_to", "IS_RELATED_TO", "Is related to",
            "NotAvailable");

        helper.insertNode(predicates, BASE_URI + "/suspected", "SUSPECTED", "Suspected",
            "NotAvailable");

        helper.insertNode(predicates, BASE_URI + "/charged", "CHARGED", "Charged",
            "NotAvailable");

        helper.insertNode(predicates, BASE_URI + "/judgement", "JUDGEMENT", "Judgement",
            "NotAvailable");

        helper.insertNode(predicates, BASE_URI + "/not_guilty_or_innocent", "NOT_GUILTY_OR_INNOCENT",
            "Not guilty or innocent", "NotAvailable");

        helper.insertNode(predicates, BASE_URI + "/unknown", "UNKNOWN", "Unknown",
            "NotAvailable");
    }
}
