package com.trss.bi.service.dto;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.FeedbackItem;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.domain.factinstance.SentDateDetails;
import com.trss.bi.domain.factinstance.Event;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.service.mapper.FactInstanceMapper;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class FactInstanceDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String factId; // should this just be a string? any FK enforcement?
    private String feedRouterId;

    private String factQueueId;

    private String msFactId;

    private List<ClientEntity> entities;
    private ClientEntity selectedClientEntity;
    private String riskTaxonomyNodeId; // or full risk taxonomy nodes?
    private String predicateTaxonomyNodeId;

    private List<Article> articles;

    private Boolean flagged = false;

    private List<Event> events = new ArrayList<>();

    private Instant createdDate;
    private Instant sent;

    private List<FeedbackItem> feedbackItems;

    private SentDateDetails sentDateDetails;
    private Instant lastModifiedDate;
    private String lastModifiedBy;

    private String analystNotes;
    private String rationale;

    public FactInstanceDTO() {}

    public FactInstanceDTO(FactInstance entity) {
        this(new FactInstanceMapper().toDto(entity));
    }

    public FactInstanceDTO(FactInstanceDTO dto) {
        id = dto.getId();
        factId = dto.getFactId();
        feedRouterId = dto.getFeedRouterId();
        factQueueId = dto.getFactQueueId();
        msFactId = dto.getMsFactId();
        entities = dto.getEntities();
        selectedClientEntity = dto.getSelectedClientEntity();
        riskTaxonomyNodeId = dto.getRiskTaxonomyNodeId();
        predicateTaxonomyNodeId = dto.getPredicateTaxonomyNodeId();
        articles = dto.getArticles();
        flagged = dto.getFlagged();
        events = dto.getEvents();
        sent = dto.getSent();
        sentDateDetails = dto.getSentDateDetails();
        createdDate = dto.getCreatedDate();
        lastModifiedBy = dto.getLastModifiedBy();
        lastModifiedDate = dto.getLastModifiedDate();
        sentDateDetails = dto.getSentDateDetails();
        analystNotes = dto.getAnalystNotes();
        rationale = dto.getRationale();
        feedbackItems = dto.getFeedbackItems();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFactId() {
        return factId;
    }

    public void setFactId(String factId) {
        this.factId = factId;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public String getFactQueueId() {
        return factQueueId;
    }

    public void setFactQueueId(String factQueueId) {
        this.factQueueId = factQueueId;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public Boolean getFlagged() {
        return flagged;
    }

    public void setFlagged(Boolean flagged) {
        this.flagged = flagged;
    }

    public List<ClientEntity> getEntities() {
        return entities;
    }

    public void setEntities(List<ClientEntity> entities) {
        this.entities = entities;
    }

    public ClientEntity getSelectedClientEntity() {
        // TODO: should this logic be here? or should we just set it on creation?
        if (selectedClientEntity == null && !entities.isEmpty() ) {
            return entities.get(0);
        }
        return selectedClientEntity;
    }

    public void setSelectedClientEntity(ClientEntity selectedClientEntity) {
        this.selectedClientEntity = selectedClientEntity;
    }

    public String getRiskTaxonomyNodeId() {
        return riskTaxonomyNodeId;
    }

    public void setRiskTaxonomyNodeId(String riskTaxonomyNodeId) {
        this.riskTaxonomyNodeId = riskTaxonomyNodeId;
    }

    public String getPredicateTaxonomyNodeId() {
        return predicateTaxonomyNodeId;
    }

    public void setPredicateTaxonomyNodeId(String predicateTaxonomyNodeId) {
        this.predicateTaxonomyNodeId = predicateTaxonomyNodeId;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public SentDateDetails getSentDateDetails() {
        return sentDateDetails;
    }

    public void setSentDateDetails(SentDateDetails sentDateDetails) {
        this.sentDateDetails = sentDateDetails;
    }

    public Instant getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Instant lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getRationale() {
        return rationale;
    }

    public void setRationale(String rationale) {
        this.rationale = rationale;
    }

    public Instant getSent() {
        return this.sent;
    }

    public void setSent(Instant sent) {
        this.sent = sent;
    }

    public List<FeedbackItem> getFeedbackItems() {
        return feedbackItems;
    }

    public void setFeedbackItems(List<FeedbackItem> feedbackItems) {
        this.feedbackItems = feedbackItems;
    }
}
