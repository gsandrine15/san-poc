package com.trss.bi.service.dto.feedback;

/**
 * Represents a AmsFeedback payload.
 */
public class AmsFeedbackDTO {

    protected MediaScreenerFeedbackDTO mediaScreenerFeedback;
    protected EntityMatcherFeedbackDTO entityMatcherFeedback;

    public MediaScreenerFeedbackDTO getMediaScreenerFeedback() {
        return mediaScreenerFeedback;
    }

    public void setMediaScreenerFeedback(MediaScreenerFeedbackDTO mediaScreenerFeedback) {
        this.mediaScreenerFeedback = mediaScreenerFeedback;
    }

    public EntityMatcherFeedbackDTO getEntityMatcherFeedback() {
        return entityMatcherFeedback;
    }

    public void setEntityMatcherFeedback(EntityMatcherFeedbackDTO entityMatcherFeedback) {
        this.entityMatcherFeedback = entityMatcherFeedback;
    }

    @Override
    public String toString() {
        return "AmsFeedbackDTO{" +
            "mediaScreenerFeedback=" + mediaScreenerFeedback +
            ", entityMatcherFeedbackDTO=" + entityMatcherFeedback +
            '}';
    }
}
