package com.trss.bi.web.rest;

import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.service.AlertService;
import com.trss.bi.service.FactInstanceService;
import com.trss.bi.service.dto.AlertDTO;
import com.trss.bi.service.dto.AlertFilterDTO;
import com.trss.bi.service.dto.FactInstanceDTO;
import org.bson.types.ObjectId;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static com.trss.bi.security.AuthorizationConstants.*;

@RestController
@RequestMapping("/api")
public class AlertResource {

    private AlertService alertService;
    private FactInstanceService factInstanceService;
    public AlertResource(AlertService alertService, FactInstanceService factInstanceService) {
        this.alertService = alertService;
        this.factInstanceService = factInstanceService;
    }

    @PreAuthorize(ACCESS_RESOLVE_FACTS)
    @PostMapping("/alerts/fact-instance")
    @Transactional // TODO: should this be at this level? or at the service level? it needs to contain both the alert creation and the fact instance delete
    public AlertDTO addFactInstanceToAlert(@RequestParam("factInstanceId") String factInstanceId, @RequestBody Map<String,String> body) {
        FactInstance factInstance = factInstanceService.findToResolve(new ObjectId(factInstanceId)).orElseThrow(() -> new RuntimeException("No FactInstance found for id '" + factInstanceId + "'"));
        factInstance.setRationale(body.get("rationale"));

        AlertDTO alertDto = alertService.addFactInstanceCreateOrUpdate(factInstance);

        // now that its been added to the alert, remove it from the queue, ie, delete it from the fact instance collection
        factInstanceService.delete(factInstance);

        return alertDto;
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @GetMapping("/alerts")
    public List<AlertDTO> findAll() {
        return alertService.findAll();
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @PostMapping("/alerts/filter")
    public List<AlertDTO> findAlertsWithFilters(@RequestBody AlertFilterDTO filters) {
        return alertService.findByFilters(filters);
    }

    @PreAuthorize(ACCESS_OUTBOX + " or " + ACCESS_INBOX)
    @GetMapping(value = "/alerts", params = "clientEntityId")
    public AlertDTO findByClientEntityId(@RequestParam("clientEntityId") String clientEntityId) {
        return alertService.findByClientEntityId(clientEntityId);
    }

    @PreAuthorize(ACCESS_OUTBOX + " or " + ACCESS_INBOX)
    @GetMapping(value = "/alerts", params = "riskUri")
    public List<AlertDTO> findByRiskUri(@RequestParam("riskUri") String riskUri) {
        return alertService.findByRiskUri(riskUri);
    }

    // this endpoint appears to only be used when removing fact instances from alerts.
    // if we want another POST /alerts which saves information, we to create an additional method and some means to distinguish between the two.
    // Perhaps a removeRisk query param when we are removing information?
    @PreAuthorize(ACCESS_REMOVE_ALERTS)
    @PostMapping("/alerts")
    public AlertDTO update(@RequestBody AlertDTO alertDTO) {
        return alertService.update(alertDTO);
    }

//    @PreAuthorize(ACCESS_REMOVE_ALERTS)
    @PostMapping("/alerts/export")
    public void postMoveToApi(@RequestBody Map<String, String> params) {
        alertService.sendAlertToApi(params.get("alertId"));
    }

    @PreAuthorize(ACCESS_REMOVE_ALERTS)
    @PutMapping("/alerts/{id}/ignore")
    public void ignore(@PathVariable("id") String alertId, @RequestBody Map<String, String> params){
        alertService.ignore(alertId, params.get("reason"), params.get("comments"));
    }

    @PreAuthorize(ACCESS_EDIT_ALERTS)
    @PutMapping("/alerts/{id}/fact-instance")
    public AlertDTO updateFactInstanceOnAlert(@PathVariable String id, @RequestBody FactInstanceDTO factInstanceDTO) {
        return alertService.updateFactInstanceOnAlert(id, factInstanceDTO);
    }

    @PreAuthorize(ACCESS_EXPORT_ALERTS)
    @GetMapping("/alerts/csv")
    public void getAlertsById(HttpServletResponse response, @RequestParam("alertIds") String[] ids) throws IOException {
        response.addHeader("Content-Disposition", "attachment; filename=\"hi.csv\"");
        OutputStream outputStream = response.getOutputStream();
        alertService.exportAlertsByAlertIds(Arrays.asList(ids), outputStream);
        response.flushBuffer();
    }

    @PreAuthorize(ACCESS_EDIT_ALERTS)
    @PutMapping("/alerts/{id}/analystNotes")
    public AlertDTO putAnalystNotes(@PathVariable("id") String alertId, @RequestBody Map<String, String> params){
        return alertService.saveAnalystNotes(alertId, params.get("analystNotes"));
    }

    @PreAuthorize(ACCESS_EDIT_ALERTS)
    @PutMapping("/alerts/{id}/clientNotes")
    public AlertDTO putClientNotes(@PathVariable("id") String alertId, @RequestBody Map<String, String> params){
        return alertService.saveClientNotes(alertId, params.get("clientNotes"));
    }

    @PreAuthorize(ACCESS_REMOVE_ALERTS)
    @DeleteMapping("alerts/{id}")
    public void ignoreAlert(@PathVariable("id") String alertId) {
        alertService.ignore(alertId, null, null);
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @GetMapping(value = "alerts", params = "alertIds")
    public List<AlertDTO> getAllById(@RequestParam("alertIds") List<String> ids) {
        return alertService.findAllById(ids);
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @GetMapping("alerts/risks")
    public List getDistinctRisks() {
        return alertService.findDistinctRisks();
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @GetMapping("alerts/predicates")
    public List getDistinctPredicates() {
        return alertService.findDistinctPredicates();
    }

    @PreAuthorize(ACCESS_OUTBOX)
    @GetMapping("alerts/screeners")
    public List getDistinctScreeners() {
        return alertService.findDistinctScreeners();
    }
}
