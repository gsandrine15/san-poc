package com.trss.bi.service.aws;

import com.trss.bi.domain.alert.Alert;
import com.trss.bi.domain.api.ApiAlert;
import com.trss.bi.domain.api.ApiArticle;
import com.trss.bi.domain.fact.FeedbackItem;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.service.TaxonomyNodeService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ApiAlertService {

    private String baseUrl;
    private TaxonomyNodeService taxonomyNodeService;
    private ApiAlertDao apiAlertDao;

    public ApiAlertService(TaxonomyNodeService taxonomyNodeService, ApiAlertDao apiAlertDao, @Value("${baseUrl}") String baseUrl) {
        this.taxonomyNodeService = taxonomyNodeService;
        this.apiAlertDao = apiAlertDao;
        this.baseUrl = baseUrl;
    }

    public void convertAndSendToApi(Alert alert) {
        ApiAlert apiAlert = new ApiAlert();
        apiAlert.setId(UUID.randomUUID().toString());
        buildEntityFields(apiAlert, alert.getClientEntity());
        List<ApiArticle> articleList = alert.getFactInstances().stream().map(this::buildApiArticle).flatMap(List::stream).collect(Collectors.toList());
        apiAlert.setSupportingArticles(articleList);
        apiAlertDao.saveReport(apiAlert);
    }

    private List<ApiArticle> buildApiArticle(FactInstance factInstance) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
        Map<String, String> taxonomyMap = taxonomyNodeService.getUriDisplayName();

        return factInstance.getArticles().stream().map(a -> {
            ApiArticle article = new ApiArticle();

            String urlParams = a.getGuid();
            article.setArticleUrl(baseUrl + "/#/article-viewer?nr-guids=" + urlParams);

            String publicationDate = a.getPublicationDate();
            article.setArticlePublicationDate(publicationDate);

            String keySentences = factInstance.getFeedbackItems().stream().map(FeedbackItem::getSentence).collect(Collectors.joining(", "));
            article.setArticleKeySentences(keySentences);

            article.setRisk(taxonomyMap.get(factInstance.getRiskTaxonomyNodeId()));
            article.setSentDate(dateFormat.format(Date.from(factInstance.getSent())));

            return article;
        }).collect(Collectors.toList());

    }

    private ApiAlert buildEntityFields(ApiAlert apiAlert, ClientEntity clientEntity) {
        apiAlert.setClientEntityId(clientEntity.getId());
        apiAlert.setEntityName(clientEntity.getName());
        apiAlert.setEntityType(clientEntity.getType());
        apiAlert.setDob(clientEntity.getDob());
        apiAlert.setHqAddress(clientEntity.getHqAddress());
        apiAlert.setNationality(clientEntity.getNationality());
        apiAlert.setPositionAtCompany(clientEntity.getPositionAtCompany());
        return apiAlert;
    }
}
