package com.trss.bi.domain.factinstance;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.FeedbackItem;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Document(collection = "factInstance")
public class FactInstance extends AbstractAuditingEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private ObjectId id;

    private ObjectId factId; // should this just be a string? any FK enforcement?
    private String feedRouterId;

    private ObjectId factQueueId;

    private String msFactId;

    private List<ClientEntity> entities = new ArrayList<>();
    private ClientEntity selectedClientEntity;

    private String riskTaxonomyNodeId; // or full risk taxonomy nodes?
    private String predicateTaxonomyNodeId;

    private List<Article> articles;

    private String analystNotes;
    private String rationale;

    @Field("sent_date_details")
    private SentDateDetails sentDateDetails;
    private Instant sent;

    private List<FeedbackItem> feedbackItems;

    private Boolean flagged = false;

    private List<Event> events = new ArrayList<>();

    public List<Event> addEvent(Event event) {
        events.add(event);
        return events;
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public ObjectId getFactId() {
        return factId;
    }

    public void setFactId(ObjectId factId) {
        this.factId = factId;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public List<ClientEntity> getEntities() {
        return entities;
    }

    public void setEntities(List<ClientEntity> entities) {
        this.entities = entities;
    }

    public String getAnalystNotes() {
        return analystNotes;
    }

    public void setAnalystNotes(String analystNotes) {
        this.analystNotes = analystNotes;
    }

    public String getRationale() {
        return rationale;
    }

    public void setRationale(String rationale) {
        this.rationale = rationale;
    }

    public ClientEntity getSelectedClientEntity() {
        // TODO: should this logic be here? or should we just set it on creation?
        if (selectedClientEntity == null && !entities.isEmpty() ) {
            return entities.get(0);
        }
        return selectedClientEntity;
    }

    public void setSelectedClientEntity(ClientEntity selectedClientEntity) {
        this.selectedClientEntity = selectedClientEntity;
    }

    public String getRiskTaxonomyNodeId() {
        return riskTaxonomyNodeId;
    }

    public void setRiskTaxonomyNodeId(String riskTaxonomyNodeId) {
        this.riskTaxonomyNodeId = riskTaxonomyNodeId;
    }

    public String getPredicateTaxonomyNodeId() {
        return predicateTaxonomyNodeId;
    }

    public void setPredicateTaxonomyNodeId(String predicateTaxonomyNodeId) {
        this.predicateTaxonomyNodeId = predicateTaxonomyNodeId;
    }

    public ObjectId getFactQueueId() {
        return factQueueId;
    }

    public void setFactQueueId(ObjectId factQueueId) {
        this.factQueueId = factQueueId;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public Boolean getFlagged() {
        return flagged;
    }

    public void setFlagged(Boolean flagged) {
        this.flagged = flagged;
    }

    public SentDateDetails getSentDateDetails() {
        return sentDateDetails;
    }

    public void setSentDateDetails(SentDateDetails sentDateDetails) {
        this.sentDateDetails = sentDateDetails;
    }

    public Instant getSent() {
        return sent;
    }

    public void setSent(Instant sent) {
        this.sent = sent;
    }

    public List<FeedbackItem> getFeedbackItems() {
        return feedbackItems;
    }

    public void setFeedbackItems(List<FeedbackItem> feedbackItems) {
        this.feedbackItems = feedbackItems;
    }

    @Override
    public String toString() {
        return "FactInstance{" +
            "id=" + id +
            ", factId=" + factId +
            ", feedRouterId='" + feedRouterId + '\'' +
            ", factQueueId=" + factQueueId +
            ", msFactId='" + msFactId + '\'' +
            ", entities=" + entities +
            ", selectedClientEntity=" + selectedClientEntity +
            ", riskTaxonomyNodeId='" + riskTaxonomyNodeId + '\'' +
            ", predicateTaxonomyNodeId='" + predicateTaxonomyNodeId + '\'' +
            ", articles=" + articles +
            ", analystNotes='" + analystNotes + '\'' +
            ", rationale='" + rationale + '\'' +
            ", sentDateDetails=" + sentDateDetails +
            ", sent=" + sent +
            ", feedbackItems=" + feedbackItems +
            ", flagged=" + flagged +
            ", events=" + events +
            '}';
    }
}
