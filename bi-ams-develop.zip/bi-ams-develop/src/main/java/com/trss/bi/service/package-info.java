/**
 * Service layer beans.
 */
package com.trss.bi.service;
