package com.trss.bi.domain;

import lombok.Getter;
import lombok.Setter;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Document(collection = "factQueue")
public class FactQueue extends AbstractAuditingEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private ObjectId id;

    private String factQueueConfigId; // id from other microservice

    // name, description and ownerId are cached values, the authority of these are in the fact queue config

    @NotNull
    private String name;

    private String description;

    private Long ownerId;
    private String ownerUsername;

    private Long customerId;

    // owned by this microservice
    @NotNull
    private Boolean isFavorite = false;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getFactQueueConfigId() {
        return factQueueConfigId;
    }

    public void setFactQueueConfigId(String factQueueConfigId) {
        this.factQueueConfigId = factQueueConfigId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getOwnerUsername() {
        return ownerUsername;
    }

    public void setOwnerUsername(String ownerUsername) {
        this.ownerUsername = ownerUsername;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Boolean getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(Boolean favorite) {
        isFavorite = favorite;
    }

    @Override
    public String toString() {

        return "FactQueue{" +
            "id=" + id +
            ", factQueueConfigId='" + factQueueConfigId + '\'' +
            ", name='" + name + '\'' +
            ", description='" + description + '\'' +
            ", ownerId=" + ownerId +
            ", customerId=" + customerId +
            ", isFavorite=" + isFavorite +
            '}';
    }
}
