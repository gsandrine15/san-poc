/**
 * JPA domain objects.
 */
package com.trss.bi.domain;
