package com.trss.bi.domain.api;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTyped;

import java.io.Serializable;
import java.util.List;

@DynamoDBDocument
public class ApiArticle implements Serializable {

    private String risk;
    private String sentDate;
    private String articleUrl;
    private String articlePublicationDate;
    private String articleKeySentences;

    public String getRisk() {
        return risk;
    }

    public void setRisk(String risk) {
        this.risk = risk;
    }

    public String getSentDate() {
        return sentDate;
    }

    public void setSentDate(String sentDate) {
        this.sentDate = sentDate;
    }

    public String getArticleUrl() {
        return articleUrl;
    }

    public void setArticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public String getArticlePublicationDate() {
        return articlePublicationDate;
    }

    public void setArticlePublicationDate(String articlePublicationDate) {
        this.articlePublicationDate = articlePublicationDate;
    }

    public String getArticleKeySentences() {
        return articleKeySentences;
    }

    public void setArticleKeySentences(String articleKeySentences) {
        this.articleKeySentences = articleKeySentences;
    }
}
