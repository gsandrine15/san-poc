package com.trss.bi.service.mapper;

import com.trss.bi.domain.taxonomy.TaxonomyNode;
import com.trss.bi.service.dto.TaxonomyNodeDTO;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.stream.Collectors;

public class TaxonomyNodeMapper extends BaseEntityMapper<TaxonomyNodeDTO, TaxonomyNode> {

    private ObjectId stringToObjectId(String id) {
        return id != null ? new ObjectId(id) : null;
    }

    private String objectIdToString(ObjectId id) {
        return id != null ? id.toString() : null;
    }

    private List<ObjectId> stringsToObjectIds(List<String> ids) {
        return ids.stream().map(ObjectId::new).collect(Collectors.toList());
    }

    private List<String> objectIdsToStrings(List<ObjectId> ids) {
        return ids.stream().map(ObjectId::toString).collect(Collectors.toList());
    }

    @Override
    public TaxonomyNode toEntity(TaxonomyNodeDTO dto) {
        if (dto == null) {
            return null;
        }

        TaxonomyNode entity = new TaxonomyNode();
        entity.setId(stringToObjectId(dto.getId()));
        entity.setTaxonomyId(stringToObjectId(dto.getTaxonomyId()));
        entity.setCode(dto.getCode());
        entity.setUri(dto.getUri());
        entity.setDisplayName(dto.getDisplayName());
        entity.setDescription(dto.getDescription());
        entity.setParentNodeIds(stringsToObjectIds(dto.getParentNodeIds()));
        entity.setChildNodeIds(stringsToObjectIds(dto.getChildNodeIds()));
        entity.setSynonyms(dto.getSynonyms());

        return entity;
    }

    @Override
    public TaxonomyNodeDTO toDto(TaxonomyNode entity) {
        if (entity == null) {
            return null;
        }

        TaxonomyNodeDTO dto = new TaxonomyNodeDTO();
        dto.setId(entity.getId().toString());
        dto.setTaxonomyId(objectIdToString(entity.getTaxonomyId()));
        dto.setCode(entity.getCode());
        dto.setUri(entity.getUri());
        dto.setDisplayName(entity.getDisplayName());
        dto.setDescription(entity.getDescription());
        dto.setParentNodeIds(objectIdsToStrings(entity.getParentNodeIds()));
        dto.setChildNodeIds(objectIdsToStrings(entity.getChildNodeIds()));
        dto.setSynonyms(entity.getSynonyms());

        return dto;
    }
}
