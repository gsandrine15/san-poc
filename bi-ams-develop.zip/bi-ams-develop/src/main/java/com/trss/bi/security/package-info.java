/**
 * Spring Security configuration.
 */
package com.trss.bi.security;
