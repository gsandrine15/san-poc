package com.trss.bi.service.mapper;

import com.trss.bi.domain.fact.Fact;
import com.trss.bi.service.dto.FactDTO;
import org.bson.types.ObjectId;

public class FactMapper extends BaseEntityMapper<FactDTO, Fact> {
    @Override
    public Fact toEntity(FactDTO dto) {
        if (dto == null) {
            return null;
        }

        Fact entity = new Fact();
        if (dto.getId() != null) {
            entity.setId(new ObjectId(dto.getId()));
        }

        entity.setMsFactId(dto.getMsFactId());
        entity.setFeedRouterId(dto.getFeedRouterId());
        entity.setSubject(dto.getSubject());
        entity.setNotes(dto.getNotes());
        entity.setEntities(dto.getEntities());
        entity.setSent(dto.getSent());
        entity.setRiskTaxonomyNodeId(dto.getRiskTaxonomyNodeId());
        entity.setPredicateTaxonomyNodeId(dto.getPredicateTaxonomyNodeId());
        entity.setArticles(dto.getArticles());
        entity.setFeedbackItems(dto.getFeedbackItems());

        return entity;
    }

    @Override
    public FactDTO toDto(Fact entity) {
        if (entity == null) {
            return null;
        }

        FactDTO dto = new FactDTO();
        if (entity.getId() != null) {
            dto.setId(entity.getId().toString());
        }

        dto.setMsFactId(entity.getMsFactId());
        dto.setFeedRouterId(entity.getFeedRouterId());
        dto.setSubject(entity.getSubject());
        dto.setNotes(entity.getNotes());
        dto.setSent(entity.getSent());
        dto.setEntities(entity.getEntities());
        dto.setRiskTaxonomyNodeId(entity.getRiskTaxonomyNodeId());
        dto.setPredicateTaxonomyNodeId(entity.getPredicateTaxonomyNodeId());
        dto.setArticles(entity.getArticles());
        dto.setFeedbackItems(entity.getFeedbackItems());

        return dto;
    }
}
