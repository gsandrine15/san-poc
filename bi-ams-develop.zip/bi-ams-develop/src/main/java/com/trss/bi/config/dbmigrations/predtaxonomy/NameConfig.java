package com.trss.bi.config.dbmigrations.predtaxonomy;

import java.util.HashMap;
import java.util.Map;

public class NameConfig {

    public static Map<String,String> URI_NAMES_5_27_2021 = new HashMap<>();

    static {
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to", "Is related to");
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_suspected_of", "Is suspected of");
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_charged_with", "Is charged with");
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_convicted_of", "Is convicted of");
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_acquitted_of", "Is acquitted of");
        URI_NAMES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/case_dismissed", "Case dismissed");
    }
}
