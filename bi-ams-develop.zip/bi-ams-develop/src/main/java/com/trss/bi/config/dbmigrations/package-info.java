/**
 * MongoDB database migrations using MongoBee.
 */
package com.trss.bi.config.dbmigrations;
