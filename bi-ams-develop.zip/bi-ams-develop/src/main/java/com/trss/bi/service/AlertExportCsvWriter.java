package com.trss.bi.service;

import com.trss.bi.domain.alert.Alert;
import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.FeedbackItem;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.domain.factinstance.FactInstance;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.compress.utils.IOUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class AlertExportCsvWriter {
    private static final String VALUE_NOT_AVAILABLE = "notAvailable";

    private String baseUrl;
    private OutputStreamWriter outputStreamWriter;
    private CSVPrinter csvPrinter;
    private Map<String, String> taxonomyMap;

    private static final int RISK_MAX = 5;

    private static final String[] ALERT_CSV_HEADERS = {
        "Alert ID",
        "Entity ID",
        "Entity Type",
        "Entity Name",
        "DOB",
        "Nationality",
        "Position at Company",
        "HQ Address",
        "Screener Notes",
        "Sent Date",
        "Risk",
        "Supporting Articles",
        "Article Publication Dates",
        "Article Key Sentences"
    };

    private static Map<String, String> entityTypeMap = new HashMap<>();

    static {
        entityTypeMap.put("person", "Individual");
        entityTypeMap.put("company", "Organization");
    }

    public AlertExportCsvWriter(OutputStream outputStream, Map<String, String> taxonomyMap, String baseUrl) throws IOException {
        this.taxonomyMap = taxonomyMap;
        this.baseUrl = baseUrl;
        outputStreamWriter = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8);
        this.startCsv();
    }

    private void startCsv() throws IOException {
        csvPrinter = new CSVPrinter(outputStreamWriter, CSVFormat.DEFAULT.withHeader(ALERT_CSV_HEADERS));
    }

    public void writeAlertToCsv(Alert alert) throws IOException {
        List<List<String>> rowsForAlert = convertAlert(alert);
        for (List<String> row : rowsForAlert) {
            csvPrinter.printRecord(row);
        }
    }

    /**
     * Convert an alert to n number of rows where n is the number of fact instances/risks.
     * <p>
     * Each row will contain the same alert id and entity info
     *
     * @param alert
     * @return
     */
    private List<List<String>> convertAlert(Alert alert) {
        List<List<String>> rows = new ArrayList<>();

        List<String> commonRowFields = new ArrayList<>();
        commonRowFields.add(alert.getId().toString());
        commonRowFields.addAll(clientEntityToString(alert.getClientEntity()));
        commonRowFields.add(alert.getClientNotes());

        for (FactInstance factInstance : alert.getFactInstances()) {
            List<String> row = new ArrayList<>();
            row.addAll(commonRowFields);
            row.addAll(factInstanceToString(factInstance));

            rows.add(row);
        }
        return rows;
    }

    private List<String> clientEntityToString(ClientEntity clientEntity) {
        return Arrays.asList(clientEntity.getId(), entityTypeMap.get(clientEntity.getType()), clientEntity.getName(),
            clientEntity.getDob(), clientEntity.getNationality(), clientEntity.getPositionAtCompany(), clientEntity.getHqAddress()
        );
    }

    private List<String> factInstanceToString(FactInstance factInstance) {
        List<String> convertedList = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
        convertedList.add(dateFormat.format(Date.from(factInstance.getSent())));
        convertedList.add(taxonomyMap.get(factInstance.getRiskTaxonomyNodeId()));
        String urlParams = factInstance.getArticles().stream().map(Article::getGuid).collect(Collectors.joining(","));
        convertedList.add(baseUrl + "/#/article-viewer?nr-guids=" + urlParams);
        String publicationDates = factInstance.getArticles().stream().map(Article -> dateFormat.format(new Date(Long.parseLong(Article.getPublicationDate())))).collect(Collectors.joining(", "));
        convertedList.add(publicationDates);
        String keySentences = factInstance.getFeedbackItems().stream().map(FeedbackItem::getSentence).collect(Collectors.joining(", "));
        convertedList.add(keySentences);
        return convertedList;
    }

    public void finishCsv() throws IOException {
        csvPrinter.flush();
        closeWriters();
    }

    public void closeWriters() {
        IOUtils.closeQuietly(outputStreamWriter);
        IOUtils.closeQuietly(csvPrinter);
    }
}
