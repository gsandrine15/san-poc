package com.trss.bi.web.rest;

import com.trss.bi.domain.taxonomy.TaxonomyNode;
import com.trss.bi.service.TaxonomyNodeService;
import com.trss.bi.service.dto.FactQueueDTO;
import com.trss.bi.service.dto.TaxonomyNodeDTO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class TaxonomyNodeResource {

    private TaxonomyNodeService taxonomyNodeService;

    public TaxonomyNodeResource(TaxonomyNodeService taxonomyNodeService) {
        this.taxonomyNodeService = taxonomyNodeService;
    }

    @GetMapping("/taxonomy/{code}")
    public List<TaxonomyNodeDTO> getTaxonomyNodes(@PathVariable String code) {
        return taxonomyNodeService.findAllSortedByTaxonomyCode(code);
    }
}
