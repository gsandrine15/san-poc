package com.trss.bi.cli;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.service.FeedItemService;
import com.trss.bi.service.dto.FeedItemDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.*;

@Service
public class MockFactLoader {

    // TODO: ideally we'd look this up, but for now hardcode which queue to add the mock facts to
    private static final String FACT_QUEUE_CONFIG_ID = "5e99b71247473929a8b8edf6";

    static Random random = new Random();

    FeedItemService feedItemService;

    public MockFactLoader(FeedItemService feedItemService) {
        this.feedItemService = feedItemService;
    }

//    @PostConstruct
//    public void loadFacts() {
//        loadFacts(475); // uncomment to load x number of facts
//    }

    public void loadFacts(int numFacts) {
        for (int i=0; i<numFacts; i++) {
            FeedItemDTO feedItemDTO = new FeedItemDTO();

            feedItemDTO.setFeedRouterId(UUID.randomUUID().toString());
            feedItemDTO.setRisk(ALL_RISKS.get(random.nextInt(ALL_RISKS.size() - 1)));
            feedItemDTO.setArticles(buildMockArticles());

            feedItemDTO.setMatchCandidates(Arrays.asList(buildEntity(), buildEntity()));

            feedItemDTO.setMatchingFactQueueConfigIds(Arrays.asList(FACT_QUEUE_CONFIG_ID)); // TODO: lookup

            feedItemService.loadFeedItem(feedItemDTO);
        }
    }

    final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ12345674890";

    // consider using a Map<String,Boolean> to say whether the identifier is being used or not
    final Set<String> identifiers = new HashSet<>();

    public String randomIdentifier() {
        StringBuilder builder = new StringBuilder();
        while(builder.toString().length() == 0) {
            int length = random.nextInt(5)+5;
            for(int i = 0; i < length; i++) {
                builder.append(lexicon.charAt(random.nextInt(lexicon.length())));
            }
            if(identifiers.contains(builder.toString())) {
                builder = new StringBuilder();
            }
        }
        return builder.toString();
    }

    public ClientEntity buildEntity() {
        String type = "person";
        String name = MOCK_NAMES.get(random.nextInt(50));

        if (random.nextBoolean()) {
            type = "company";
            name = MOCK_COMPANY_NAMES.get(random.nextInt(40));
        }

        ClientEntity clientEntity = new ClientEntity();
        clientEntity.setId(name); // use the name as the stringId so we can start to see some grouping with alerts
        clientEntity.setConfidenceScore(String.valueOf(random.nextInt(100)));
        clientEntity.setName(name);
        clientEntity.setType(type);

        return clientEntity;
    }

    private List<Article> buildMockArticles() {
        List<Article> articles = new ArrayList<>();
        for (int i=0; i<=random.nextInt(5); i++) {
           articles.add(buildMockArticle());
        }
        return articles;
    }

    public Article buildMockArticle() {
        Article article = new Article();
        article.setId(String.valueOf(random.nextInt(1000)));
        article.setUrl("https://www." + randomIdentifier() + ".com/" + randomIdentifier());
        return article;
    }

    private static final List<String> MOCK_COMPANY_NAMES = Arrays.asList(
        "Odds And Ends",
        "Handy Help",
        "Knick Knacks",
        "Nick’S Knacks",
        "Here And There And Everywhere",
        "Et Cetera Systems",
        "Et Cetera Solutions",
        "Closet Of Choices",
        "Random Reasoning",
        "Trusted Assortment",
        "Applicable Assortment",
        "Random Row",
        "Random Reason",
        "Random Riders",
        "Random Repair",
        "Random Resource",
        "Resource Refresh",
        "Random Refresh",
        "The Source",
        "Complete Collection",
        "Sporadic Systems",
        "Sufficient Support",
        "Random Report",
        "Random Warehouse",
        "Wanted Warehouse",
        "Full Force",
        "Complete Competition",
        "Forge Ahead",
        "Make It Count",
        "Count Your Blessings",
        "Creative Content",
        "Content Construct",
        "Clever Counts",
        "Counted Moments",
        "Make It Count",
        "Random Wishes",
        "Wishful Wants",
        "Dream Collection",
        "Contribution Collection",
        "Rock And Random",
        "Race To Random",
        "Trinkets And Toys"
    );

    private static final List<String> MOCK_NAMES = Arrays.asList(
        "Kristy Callan",
        "Corie Nault",
        "Shakira Kluge",
        "Blanch Ater",
        "Page Zentz",
        "Buddy Steinberger",
        "Wanetta Gobeil",
        "Rosia Buras",
        "Iola Currie",
        "Tricia Bormann",
        "Marquerite Sullens",
        "Adolfo Crudup",
        "Lenora Ringgold",
        "Laverna Slagle",
        "Gertha Sirmons",
        "Moses Styles",
        "Carline Bingman",
        "Margene Scharf",
        "Annis Larson",
        "Simone Keleher",
        "Augusta Janson",
        "Willena Hupp",
        "Kyung Ridley",
        "Candida Higham",
        "Maryann Tomberlin",
        "Keitha Rorie",
        "Rhoda Loos",
        "Leland Chenier",
        "Paulina Gohr",
        "Deandra Poll",
        "Rhett Alvord",
        "Dominic Rennick",
        "Weldon Lawlor",
        "Nana Standley",
        "Jimmie Tetzlaff",
        "Izola Erben",
        "Rubie Barcia",
        "Franklyn Goguen",
        "Meaghan Fiorita",
        "Ariel Albertson",
        "Buster Macfarlane",
        "Elvera Wilbert",
        "Rebbecca Helbert",
        "Bettie Hagberg",
        "Noel Beach",
        "Reginald Rape",
        "Dominique Moon",
        "Lezlie Cuadrado",
        "Dana Kneip",
        "Julia Shoultz"
    );

    private static final List<String> ALL_RISKS = Arrays.asList(
        /*"http://graph.mediascreener.com/facttype/other",
        "http://graph.mediascreener.com/facttype/corporatecrime",
        "http://graph.mediascreener.com/facttype/corporatecrime/laundering",
        "http://graph.mediascreener.com/facttype/corporatecrime/bribery",
        "http://graph.mediascreener.com/facttype/corporatecrime/bizcompliance",
        "http://graph.mediascreener.com/facttype/corporatecrime/embezzlement",
        "http://graph.mediascreener.com/facttype/corporatecrime/insider",
        "http://graph.mediascreener.com/facttype/corporatecrime/manipulation",
        "http://graph.mediascreener.com/facttype/corporatecrime/moneyservice",
        "http://graph.mediascreener.com/facttype/corporatecrime/perjury",
        "http://graph.mediascreener.com/facttype/corporatecrime/regaction",
        "http://graph.mediascreener.com/facttype/corporatecrime/secfraud"
        "http://graph.mediascreener.com/facttype/noncorporatecrime",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime",*/
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/armstraffic",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/gambling",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/drugtraffic",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/humantraffic",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/illicitgoods",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/orgcrime",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/organized_crime/sexexploit"
        /*"http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime/injury",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime/kidnap",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime/murder",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime/piracy",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/violentcrime/robbery",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/misappropriation",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/misappropriation/burglary",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/misappropriation/genfraud",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/misappropriation/extortion",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/misappropriation/theft",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/currency",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/drugoffense",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/fugitive",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/ipcrime",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/illegalweapons",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/sexoffense",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/usury",
        "http://graph.mediascreener.com/facttype/noncorporatecrime/othernoncorporate/watchlist",
        "http://graph.mediascreener.com/facttype/taxation",
        "http://graph.mediascreener.com/facttype/taxation/taxavoidance",
        "http://graph.mediascreener.com/facttype/taxation/taxevasion",
        "http://graph.mediascreener.com/facttype/taxation/taxhavens",
        "http://graph.mediascreener.com/facttype/taxation/smuggling",
        "http://graph.mediascreener.com/facttype/legalaction",
        "http://graph.mediascreener.com/facttype/legalaction/antitrust",
        "http://graph.mediascreener.com/facttype/legalaction/classaction",
        "http://graph.mediascreener.com/facttype/itissues",
        "http://graph.mediascreener.com/facttype/itissues/breakdown",
        "http://graph.mediascreener.com/facttype/itissues/cybercrime",
        "http://graph.mediascreener.com/facttype/itissues/databreach",
        "http://graph.mediascreener.com/facttype/itissues/datamisuse",
        "http://graph.mediascreener.com/facttype/political",
        "http://graph.mediascreener.com/facttype/political/corruption",
        "http://graph.mediascreener.com/facttype/political/politicexpprsn",
        "http://graph.mediascreener.com/facttype/political/politicsenscntry",
        "http://graph.mediascreener.com/facttype/political/terrorism",
        "http://graph.mediascreener.com/facttype/sanctioned",
        "http://graph.mediascreener.com/facttype/sanctioned/sanctcountry",
        "http://graph.mediascreener.com/facttype/sanctioned/sanctcompany",
        "http://graph.mediascreener.com/facttype/sanctioned/sanctperson",
        "http://graph.mediascreener.com/facttype/ethicalissues",
        "http://graph.mediascreener.com/facttype/ethicalissues/animalwelfare",
        "http://graph.mediascreener.com/facttype/ethicalissues/ecocrime",
        "http://graph.mediascreener.com/facttype/ethicalissues/healthsafety",
        "http://graph.mediascreener.com/facttype/ethicalissues/humanrightsbreach",
        "http://graph.mediascreener.com/facttype/ethicalissues/managementcompensation",
        "http://graph.mediascreener.com/facttype/ethicalissues/nonecopractice",
        "http://graph.mediascreener.com/facttype/ethicalissues/withholding",
        "http://graph.mediascreener.com/facttype/productfaults",
        "http://graph.mediascreener.com/facttype/productfaults/productrecall",
        "http://graph.mediascreener.com/facttype/productfaults/productscandal"*/
    );
}
