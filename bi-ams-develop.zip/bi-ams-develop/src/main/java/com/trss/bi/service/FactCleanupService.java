package com.trss.bi.service;

import com.trss.bi.domain.alert.Alert;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FactCleanupService {
    private final Logger log = LoggerFactory.getLogger(FactCleanupService.class);

    private FactService factService;
    private FactInstanceService factInstanceService;
    private HistoricalFactInstanceService historicalFactInstanceService;
    private AlertService alertService;


    public FactCleanupService(FactService factService, FactInstanceService factInstanceService, HistoricalFactInstanceService historicalFactInstanceService,
                              AlertService alertService) {
        this.factService = factService;
        this.factInstanceService = factInstanceService;
        this.historicalFactInstanceService = historicalFactInstanceService;
        this.alertService = alertService;
    }

    @Transactional
    public void deleteFactsAndRelatedByDaysOld(int maxDays) {
        log.info("Deleting Facts (and related entities) older than " + maxDays + " days");
        List<ObjectId> factIds = factService.findExpiredFactIds(maxDays);

        log.info("'{}' Expired Facts", factIds.size());

        deleteFactsAndRelated(factIds);
    }

    private void deleteFactsAndRelated(List<ObjectId> factIds) {
        try {
            // fact instances
            deleteFactInstances(factIds);
            deleteHistoricalFactInstances(factIds);

            // alerts
            deleteFactInstancesOnAlerts(factIds);

            // facts
            deleteFacts(factIds);

        } catch (Exception e) {
            log.error("Error: Unable to delete expired facts and related for factIds: '{}'", factIds);
        }
    }

    private void deleteFactInstances(List<ObjectId> factIds) {
        Long numDeleted = factInstanceService.deleteByFactIds(factIds);
        log.info("Deleted {} fact instances.", numDeleted);
    }

    private void deleteHistoricalFactInstances(List<ObjectId> factIds) {
        Long numDeleted = historicalFactInstanceService.deleteByFactIds(factIds);
        log.info("Deleted {} ignored fact instances.", numDeleted);
    }

    // TODO: iterative logic is duplicated for alerts, ignoredalerts and exportedalerts
    // TODO: could create common interface / super class for all the alert services to implement/extend to reduce the code duplication

    private void deleteFactInstancesOnAlerts(List<ObjectId> factIds) {
        int factInstancesDeleted = 0;
        int alertsDeleted = 0;

        // for each expired fact
        for (ObjectId factId : factIds) {
            // find the associated alerts
            List<Alert> alerts = alertService.findByFactInstanceFactId(factId);

            // for each alert
            for (Alert alert : alerts) {
                // remove the factInstance with this factId
                alert.setFactInstances(
                    alert.getFactInstances().stream()
                        .filter(factInstance -> !factId.equals(factInstance.getFactId()))
                        .collect(Collectors.toList())
                );

                // if this alert has no fact instances, delete it
                if (alert.getFactInstances().isEmpty()) {
                    alertService.delete(alert.getId().toString());
                    factInstancesDeleted++;
                    alertsDeleted++;
                }
                // else update it
                else {
                    alertService.update(alert);
                    factInstancesDeleted++;
                }
            }
        }

        log.info("Deleted {} fact instances from alerts, and {} alerts", factInstancesDeleted, alertsDeleted);
    }

    private void deleteFacts(List<ObjectId> factIds) {
        Long numDeleted = factService.deleteByIds(factIds);
        log.info("Deleted {} facts.", numDeleted);
    }
}
