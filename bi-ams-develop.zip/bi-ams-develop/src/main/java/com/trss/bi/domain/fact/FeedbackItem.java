package com.trss.bi.domain.fact;

public class FeedbackItem {

    protected String articleGuid;
    protected String sentence;
    protected int entityPositionStart;
    protected int entityPositionEnd;
    protected int riskPositionStart;
    protected int riskPositionEnd;

    public String getArticleGuid() {
        return articleGuid;
    }

    public void setArticleGuid(String articleGuid) {
        this.articleGuid = articleGuid;
    }

    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public int getEntityPositionStart() {
        return entityPositionStart;
    }

    public void setEntityPositionStart(int entityPositionStart) {
        this.entityPositionStart = entityPositionStart;
    }

    public int getEntityPositionEnd() {
        return entityPositionEnd;
    }

    public void setEntityPositionEnd(int entityPositionEnd) {
        this.entityPositionEnd = entityPositionEnd;
    }

    public int getRiskPositionStart() {
        return riskPositionStart;
    }

    public void setRiskPositionStart(int riskPositionStart) {
        this.riskPositionStart = riskPositionStart;
    }

    public int getRiskPositionEnd() {
        return riskPositionEnd;
    }

    public void setRiskPositionEnd(int riskPositionEnd) {
        this.riskPositionEnd = riskPositionEnd;
    }


}
