package com.trss.bi.domain.taxonomy;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Document(collection = "taxonomyNode")
public class TaxonomyNode implements Serializable {

    @Id
    private ObjectId id;
    private ObjectId taxonomyId;
    private String code;
    private String uri;
    private String displayName;
    private String description;

    private List<ObjectId> parentNodeIds = new ArrayList<>();
    private List<ObjectId> childNodeIds = new ArrayList<>();
    private Set<String> synonyms = new HashSet<>(); // for searching purposes

    public boolean isRoot() {
        return parentNodeIds.isEmpty();
    }

    public boolean hasChildren() {
        return !childNodeIds.isEmpty();
    }

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public ObjectId getTaxonomyId() {
        return taxonomyId;
    }

    public void setTaxonomyId(ObjectId taxonomyId) {
        this.taxonomyId = taxonomyId;
    }

    public TaxonomyNode taxonomyId(ObjectId taxonomyId) {
        setTaxonomyId(taxonomyId);
        return this;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public TaxonomyNode code(String code) {
        setCode(code);
        return this;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public TaxonomyNode uri(String uri) {
        setUri(uri);
        return this;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public TaxonomyNode displayName(String displayName) {
        setDisplayName(displayName);
        return this;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public TaxonomyNode description(String description) {
        setDescription(description);
        return this;
    }

    public Set<String> getSynonyms() {
        return synonyms;
    }

    public void setSynonyms(Set<String> synonyms) {
        this.synonyms = synonyms;
    }

    public TaxonomyNode synonyms(Set<String> synonyms) {
        setSynonyms(synonyms);
        return this;
    }

    public void addSynonym(String synonym) {
        getSynonyms().add(synonym);
    }

    public List<ObjectId> getParentNodeIds() {
        return parentNodeIds;
    }

    public void setParentNodeIds(List<ObjectId> parentNodeIds) {
        this.parentNodeIds = parentNodeIds;
    }

    public TaxonomyNode parentNodeIds(List<ObjectId> parentNodeIds) {
        setParentNodeIds(parentNodeIds);
        return this;
    }

    public void addParentNodeId(ObjectId parentNodeId) {
        getParentNodeIds().add(parentNodeId);
    }

    public List<ObjectId> getChildNodeIds() {
        return childNodeIds;
    }

    public void setChildNodeIds(List<ObjectId> childNodeIds) {
        this.childNodeIds = childNodeIds;
    }

    public TaxonomyNode childNodeIds(List<ObjectId> childNodeIds) {
        setChildNodeIds(childNodeIds);
        return this;
    }

    public void addChildNodeId(ObjectId childNodeId) {
        getChildNodeIds().add(childNodeId);
    }

    @Override
    public String toString() {
        return "TaxonomyNode{" +
            "id=" + id +
            ", taxonomyId=" + taxonomyId +
            ", code='" + code + '\'' +
            ", displayName='" + displayName + '\'' +
            ", description='" + description + '\'' +
            ", synonyms=" + synonyms +
            ", parentNodeIds=" + parentNodeIds +
            ", childNodeIds=" + childNodeIds +
            '}';
    }
}
