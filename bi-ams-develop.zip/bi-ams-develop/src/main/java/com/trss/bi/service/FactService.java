package com.trss.bi.service;

import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.repository.FactRepository;
import com.trss.bi.service.dto.FactDTO;
import com.trss.bi.service.dto.FeedItemDTO;
import com.trss.bi.service.dto.HistoricalSearchDTO;
import com.trss.bi.service.mapper.FactMapper;
import org.bson.types.ObjectId;
import org.semanticweb.yars.nx.Node;
import org.semanticweb.yars.nx.parser.NxParser;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FactService {
    private FactRepository factRepository;
    private static final String RDF_SUBJECT_URI = "http://www.w3.org/1999/02/22-rdf-syntax-ns#subject";
    private static final String RDF_RISK_CONFIDENCE_URI = "https://graph.thomsonreuters.com/fact_type/risk/pred/riskConfidenceLevel";
    private static final String RDF_LABEL_URI = "http://www.w3.org/2000/01/rdf-schema#label";
    private FactMapper factMapper = new FactMapper();
    public FactService(FactRepository factRepository) {
        this.factRepository = factRepository;
    }

    @Transactional
    public Fact create(FeedItemDTO feedItemDTO) {
        Fact fact = new Fact();
        fact.setMsFactId(feedItemDTO.getMsFactId());
        fact.setFeedRouterId(feedItemDTO.getFeedRouterId());
        fact.setSubject(feedItemDTO.getSubject());
        fact.setEntities(feedItemDTO.getMatchCandidates());
        fact.setRiskTaxonomyNodeId(feedItemDTO.getRisk());
        fact.setPredicateTaxonomyNodeId(feedItemDTO.getPredicate());
        fact.setArticles(feedItemDTO.getArticles());
        fact.setRiskConfidence(feedItemDTO.getRiskConfidence());
        fact.setSent(feedItemDTO.getSent());
        fact.setFeedbackItems(feedItemDTO.getFeedbackItems());

        return factRepository.save(fact);
    }

    @Transactional
    public Fact create(HistoricalSearchDTO historicalSearchDTO) {

        // The data below is an example of how we receive data from the feed
        // the NxParser below transforms it into the data we need
        //
        // [
        //  "<https://graph.thomsonreuters.com/fact/1c7700a2-4863-4210-974f-73a7a2f80f46> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/violent_crime/murder> .",
        //  "<https://graph.thomsonreuters.com/fact/1c7700a2-4863-4210-974f-73a7a2f80f46> <https://graph.thomsonreuters.com/fact_type/risk/pred/riskConfidenceLevel> \"[[0.9660330696]]\" .",
        //  "<https://graph.thomsonreuters.com/fact/1c7700a2-4863-4210-974f-73a7a2f80f46> <http://www.w3.org/1999/02/22-rdf-syntax-ns#subject> _:bNode-d9d4160e-c0a1-4e31-9ccc-ff1b3b3e4284 .",
        //  "_:bNode-d9d4160e-c0a1-4e31-9ccc-ff1b3b3e4284 <http://www.w3.org/2000/01/rdf-schema#label>  \"Alexandria Ocasio-Cortez\" .",
        //  "_:bNode-d9d4160e-c0a1-4e31-9ccc-ff1b3b3e4284 <https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to> <https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/violent_crime/murder> ."
        //]

        // Parse fact rdf n-triples
        NxParser nxp = new NxParser();
        nxp.parse(historicalSearchDTO.getFacts());

        // Extract data from triples
        String subject = null;
        String predicate = null;
        String riskConfidenceStringArray = null;
        String label = null;
        for (Node[] node : nxp) {
            if (RDF_SUBJECT_URI.equals(node[1].getLabel())) {
                subject = extractNodeFromTriple(subject, node, "subject");
            } else if (node[0].getLabel().equals(subject) && node[2].getLabel().equals(historicalSearchDTO.getFactType())) {
                predicate = node[1].getLabel();
            } else if (RDF_RISK_CONFIDENCE_URI.equals(node[1].getLabel())) {
                riskConfidenceStringArray = extractNodeFromTriple(riskConfidenceStringArray, node, "risk confidence");
            } else if(RDF_LABEL_URI.equals(node[1].getLabel())) {
                label = extractNodeFromTriple(label, node, "label");
            }
        }

        Fact fact = new Fact();
        fact.setMsFactId(historicalSearchDTO.getMsFactId());
        fact.setFeedRouterId(historicalSearchDTO.getFeedRouterId());
        fact.setSubject(historicalSearchDTO.getSubject());
        fact.setEntities(Collections.singletonList(buildClientEntity(historicalSearchDTO, label)));
        fact.setRiskTaxonomyNodeId(historicalSearchDTO.getRiskTaxonomy());
        fact.setPredicateTaxonomyNodeId(predicate);
        fact.setArticles(historicalSearchDTO.getArticles());
        fact.setRiskConfidence(2);
        fact.setSent(historicalSearchDTO.getSent());
        fact.setFeedbackItems(new ArrayList<>());

        return factRepository.save(fact);
    }

    private ClientEntity buildClientEntity(HistoricalSearchDTO dto, String label) {
        ClientEntity entity = new ClientEntity();
        ClientEntity dtoClientEntity = dto.getClientEntity();
        if ("person".equals(dtoClientEntity.getType())) {
            entity.setDob(dtoClientEntity.getDob());
            entity.setNationality(dtoClientEntity.getNationality());
            entity.setPositionAtCompany(dtoClientEntity.getPositionAtCompany());
        } else {
            entity.setHqAddress(dtoClientEntity.getHqAddress());
        }
        entity.setId(dtoClientEntity.getId());
        entity.setName(dtoClientEntity.getName());
        entity.setConfidenceScore(2.0);
        entity.setType(dtoClientEntity.getType());
        entity.setFactQueueConfigIds(null);
        return entity;
    }

    private String extractNodeFromTriple(String valueToSet, Node[] node, String type) {
        if (valueToSet == null) {
            valueToSet = node[2].getLabel();
        }
        return valueToSet;
    }
    public Fact findByFeedRouterId(String id) {
        return factRepository.findByFeedRouterId(id);
    }

    public FactDTO find(String id) {
        return factMapper.toDto(factRepository.findById(new ObjectId(id))
            .orElseThrow(() -> new RuntimeException("No Fact found with id: '" + id + "'"))
        );
    }

    public List<ObjectId> findExpiredFactIds(int days) {
        return factRepository.findAllByCreatedDateLessThan(Instant.now().minus(days, ChronoUnit.DAYS))
            .stream()
            .map(Fact::getId)
            .collect(Collectors.toList());
    }

    public Long deleteByIds(List<ObjectId> factIds) {
        return factRepository.deleteAllByIdIn(factIds);
    }
}
