package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.config.dbmigrations.predtaxonomy.*;
import com.trss.bi.config.dbmigrations.risktaxonomy.TaxonomySetupHelper;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

@ChangeLog(order = "007")
public class PredicateTaxonomySetup {

    private final static String IS_RELATED_TO = "https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to";

    @ChangeSet(order = "01", author = "admin", id = "01-pred-taxonomy")
    public void createPredTaxonomy(MongoTemplate mongoTemplate) {
        Taxonomy taxonomy = new Taxonomy();
        taxonomy.setCode("PRED");
        taxonomy.setName("Predicate Taxonomy");
        taxonomy.setDescription("The initial version of the predicate taxonomy that mirrors the Reuters taxonomy.");
        taxonomy.setVersion("1.0");

        mongoTemplate.insert(taxonomy);
    }

    @ChangeSet(order = "02", author= "admin", id = "02-root-pred")
    public void createRootPred(MongoTemplate mongoTemplate) {
        Taxonomy taxonomy = new TaxonomySetupHelper(mongoTemplate, "PRED").getTaxonomy();

        TaxonomyNode taxonomyNode = new TaxonomyNode();
        taxonomyNode.setCode("ROOT_PRED");
        taxonomyNode.setTaxonomyId(taxonomy.getId());

        mongoTemplate.insert(taxonomyNode);
    }

    @ChangeSet(order = "03", author = "admin", id = "03-predicates")
    public void createPredicates(MongoTemplate mongoTemplate) {
        PredicateTaxonomyHelper.create(mongoTemplate);
    }

    @ChangeSet(order = "04", author = "admin", id = "04-default-predicate-taxonomy-node-id-in-factInstance")
    public void defaultPredicateTaxonomoyNodeIds(MongoTemplate mongoTemplate){
        // update the fact instances
        List<FactInstance> factInstances = mongoTemplate.findAll(FactInstance.class);
        for (FactInstance factInstance : factInstances) {
            if (factInstance.getPredicateTaxonomyNodeId() == null) {
                factInstance.setPredicateTaxonomyNodeId(IS_RELATED_TO);
                mongoTemplate.save(factInstance);
            }
        }
    }

    @ChangeSet(order = "05", author= "admin", id = "004-05-update-descriptions-5-14-21")
    public void updateDescriptions_5_14_21(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> nodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : nodes) {
            if (!node.isRoot()) {
                String description = DescriptionsConfig.URI_DESCRIPTIONS_5_14_2021.get(node.getUri());
                if (description != null && description.length() > 0) {
                    node.setDescription(description);
                    mongoTemplate.save(node);
                } else {
                    System.out.println("No description found for node: " + node.getUri());
                }
            }
        }
    }

    @ChangeSet(order = "06", author= "admin", id = "004-06-update-predicates-5-27-21")
    public void updatePredicates_5_27_21(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> nodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : nodes) {
            if (!node.isRoot()) {
                boolean save = false;
                String uri = UriConfig.URI_UPDATES_5_27_2021.get(node.getUri());
                String name = NameConfig.URI_NAMES_5_27_2021.get(uri);
                String description = DescriptionsConfig.URI_DESCRIPTIONS_5_27_2021.get(uri);
                String code = CodeConfig.URI_CODES_5_27_2021.get(uri);
                if (uri != null && uri.length() > 0) {
                    node.setUri(uri);
                    save = true;
                }
                if (name != null && name.length() > 0) {
                    node.setDisplayName(name);
                    save = true;
                }
                if (description != null && description.length() > 0) {
                    node.setDescription(description);
                    save = true;
                }
                if (code != null && code.length() > 0) {
                    node.setCode(code);
                    save = true;
                }
                if (save) {
                    mongoTemplate.save(node);
                } else {
                    System.out.println("Nothing found for node: " + node.getUri());
                }
            }
        }
    }

}
