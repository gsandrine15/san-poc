package com.trss.bi.service.mapper;

import com.trss.bi.domain.factinstance.HistoricalFactInstance;
import com.trss.bi.service.dto.HistoricalFactInstanceDTO;

import java.util.List;

public class HistoricalFactInstanceMapper extends BaseEntityMapper<HistoricalFactInstanceDTO, HistoricalFactInstance> {
    private FactInstanceMapper factInstanceMapper = new FactInstanceMapper();

    @Override
    public HistoricalFactInstance toEntity(HistoricalFactInstanceDTO dto) {
        if (dto == null) {
            return null;
        }

        HistoricalFactInstance entity = new HistoricalFactInstance(factInstanceMapper.toEntity(dto.getFactInstanceDTO()), dto.getArchivedReason(), dto.getAnalystNotes(), dto.getClientNotes(), dto.getCustomerId());

        return entity;
    }

    @Override
    public HistoricalFactInstanceDTO toDto(HistoricalFactInstance entity) {
        if (entity == null) {
            return null;
        }

        HistoricalFactInstanceDTO dto = new HistoricalFactInstanceDTO(factInstanceMapper.toDto(entity.getFactInstance()), entity.getArchivedReason(), entity.getAnalystNotes(), entity.getClientNotes(), entity.getCustomerId());

        return dto;
    }

    @Override
    public List<HistoricalFactInstance> toEntity(List<HistoricalFactInstanceDTO> dtoList) {
        return toEntity(dtoList);
    }

    @Override
    public List<HistoricalFactInstanceDTO> toDto(List<HistoricalFactInstance> entityList) {
        return toDto(entityList);
    }
}
