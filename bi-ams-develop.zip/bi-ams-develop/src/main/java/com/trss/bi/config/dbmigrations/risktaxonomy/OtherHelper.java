package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class OtherHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/other";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode other = helper.insertNode(rootNode, BASE_URI, "OTHER", "Other",
            "This is other");

    }
}
