package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class PoliticalHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/political";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode political = helper.insertNode(rootNode, BASE_URI, "POLITICAL", "Political",
            "This is political");

        // insert all the children
        helper.insertNode(political, BASE_URI + "/corruption", "CORRUPTION", "Corruption",
            "This is corruption");

        helper.insertNode(political, BASE_URI + "/politicexpprsn", "POL_EXP_PRSN", "Politically Experienced Person",
            "This is politically experienced person");

        helper.insertNode(political, BASE_URI + "/politicsenscntry", "POL_SENS_CNTRY", "Politically Sensitive Country",
            "This is politically sensitive country");

        helper.insertNode(political, BASE_URI + "/terrorism", "TERRORISM", "Terrorism",
            "This is terrorism");
    }
}
