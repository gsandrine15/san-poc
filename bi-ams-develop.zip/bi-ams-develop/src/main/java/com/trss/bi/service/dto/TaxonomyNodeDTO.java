package com.trss.bi.service.dto;

import org.bson.types.ObjectId;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TaxonomyNodeDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String taxonomyId;
    private String code;
    private String uri;
    private String displayName;
    private String description;

    private List<String> parentNodeIds = new ArrayList<>();
    private List<String> childNodeIds = new ArrayList<>();
    private Set<String> synonyms = new HashSet<>(); // for searching purposes

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTaxonomyId() {
        return taxonomyId;
    }

    public void setTaxonomyId(String taxonomyId) {
        this.taxonomyId = taxonomyId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getParentNodeIds() {
        return parentNodeIds;
    }

    public void setParentNodeIds(List<String> parentNodeIds) {
        this.parentNodeIds = parentNodeIds;
    }

    public List<String> getChildNodeIds() {
        return childNodeIds;
    }

    public void setChildNodeIds(List<String> childNodeIds) {
        this.childNodeIds = childNodeIds;
    }

    public Set<String> getSynonyms() {
        return synonyms;
    }

    public void setSynonyms(Set<String> synonyms) {
        this.synonyms = synonyms;
    }
}
