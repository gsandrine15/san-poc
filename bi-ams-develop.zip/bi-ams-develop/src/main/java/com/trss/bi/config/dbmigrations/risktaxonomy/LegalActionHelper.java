package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class LegalActionHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/legalaction";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode legalAction = helper.insertNode(rootNode, BASE_URI, "LEGAL_ACTION", "Legal Action",
            "This is legal action");

        // insert all the children
        helper.insertNode(legalAction, BASE_URI + "/antitrust", "ANTITRUST", "Antitrust",
            "This is antitrust");

        helper.insertNode(legalAction, BASE_URI + "/classaction", "CLASS_ACTION", "Class Action",
            "This is class action");
    }
}
