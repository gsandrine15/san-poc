package com.trss.bi.service;

import com.trss.bi.domain.FactQueue;
import com.trss.bi.domain.alert.FactFeedback;
import com.trss.bi.domain.alert.FeedbackType;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.*;
import com.trss.bi.repository.*;
import com.trss.bi.security.SecurityUtils;
import com.trss.bi.service.dto.FactInstanceDTO;
import com.trss.bi.service.dto.FactInstanceFilterDTO;
import com.trss.bi.service.mapper.FactInstanceMapper;
import org.apache.commons.lang3.BooleanUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.access.AuthorizationServiceException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.time.ZoneOffset;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.trss.bi.security.AuthorizationConstants.*;
import static java.lang.Long.parseLong;

@Service
public class FactInstanceService extends com.trss.bi.service.Service<FactInstance> {

    private final Logger log = LoggerFactory.getLogger(FactInstanceService.class);

    private FactInstanceRepository factInstanceRepository;
    private HistoricalFactInstanceRepository historicalFactInstanceRepository;
    private FactRepository factRepository;
    private FactFeedbackRepository factFeedbackRepository;
    private FactInstanceMapper factInstanceMapper = new FactInstanceMapper();
    private MongoTemplate mongoTemplate;
    private FactQueueRepository factQueueRepository;

    @Autowired
    public FactInstanceService(FactInstanceRepository factInstanceRepository, HistoricalFactInstanceRepository historicalFactInstanceRepository, FactRepository factRepository, FactFeedbackRepository factFeedbackRepository, MongoTemplate mongoTemplate, FactQueueRepository factQueueRepository) {
        super(factInstanceRepository);
        this.factInstanceRepository = factInstanceRepository;
        this.historicalFactInstanceRepository = historicalFactInstanceRepository;
        this.factRepository = factRepository;
        this.factFeedbackRepository = factFeedbackRepository;
        this.mongoTemplate = mongoTemplate;
        this.factQueueRepository = factQueueRepository;
    }

    public Optional<FactInstance> find(ObjectId id) {
        return factInstanceRepository.findById(id);
    }

    /**
     * Method should be used when resolving an alert/factinstance
     * @param id
     * @return
     */
    public Optional<FactInstance> findToResolve(ObjectId id) {
        Optional<FactInstance> factInstance = find(id);
        if (!factInstance.isPresent()) return factInstance;

        if (SecurityUtils.doesCurrentUserHaveAuthority("INBOX_RESOLVE_MY_FACTS") && !isMyOwnFactQueue(factInstance.get().getFactQueueId())) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return factInstance;
    }

    public void delete(FactInstance factInstance) {
        factInstanceRepository.delete(factInstance);
    }

    public void deleteByFactQueueId(String factQueueId) {
        factInstanceRepository.deleteAllByFactQueueId(new ObjectId(factQueueId));
    }

    public void deleteByFactId(ObjectId factId) {
        factInstanceRepository.deleteAllByFactId(factId);
    }

    @Transactional
    public Long deleteByFactIds(List<ObjectId> factIds) {
        return factInstanceRepository.deleteAllByFactIdIn(factIds);
    }

    /**
     * Find a page of fact instances in a queue given the filters.
     *
     * @param pageable
     * @param factQueueId
     * @param filters
     * @return
     */
    public Page<FactInstanceDTO> findFactInstances(Pageable pageable, String factQueueId, FactInstanceFilterDTO filters) {
        log.debug("Request to get fact instances for fact queue '{}' by paging criteria, '{}'", factQueueId, filters);

        if (pageable.getSort().getOrderFor("day-confidence") != null) {
            Sort sort = getDayConfidenceSort(pageable);
            pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
        }
        Query query = buildFactInstanceQuery(pageable, factQueueId, filters);

        List<FactInstance> list = mongoTemplate.find(query, FactInstance.class);

        long count = mongoTemplate.count(query.limit(-1).skip(-1), FactInstance.class);

        Page<FactInstance> factInstancePage = new PageImpl<>(list, pageable, count);

        return factInstancePage.map(factInstanceMapper::toDto);
    }

    public List<String> findClientEntityNamesByNameSubstring( String factQueueId, String nameSubstringLowerCase) {
        Query query = buildEntityNamesRegexSearchQuery(null, factQueueId, Pattern.quote(nameSubstringLowerCase)); //use Pattern.quote as strings can interfere with regex patterns (particularly special characters)
        Pattern pattern = Pattern.compile("(\\s|^)(" +Pattern.quote(nameSubstringLowerCase) + ")+" ); // this is used to search the beginning of any space-separated word
        List<FactInstance> factInstances = mongoTemplate.find(query, FactInstance.class);
        List<String> clientEntities = factInstances.stream()
            .map(fi -> fi.getEntities())
            .flatMap(List::stream)
            .map(ce -> ce.getName())
            .filter(ce -> pattern.matcher(ce.toLowerCase()).find())
            .distinct()
            .sorted()
            .collect(Collectors.toList());
        return clientEntities;

    }

    private Query buildEntityNamesRegexSearchQuery(Pageable pageable, String factQueueId, String nameSubstringLowerCase) {
        Query query = new Query();
        Criteria criteria = Criteria.where("factQueueId").is(new ObjectId(factQueueId));
        criteria = criteria.and("entities.name").regex("([\\s]|^)" +nameSubstringLowerCase, "i");
        query.addCriteria(criteria);
        if (pageable != null) {
            query.with(pageable);
        }
        return query;
    }

    private Sort getDayConfidenceSort(Pageable pageable) {
        // grab the day-confidence sorting translation from the pageable params
        Sort.Order dayConfidenceOrder = pageable.getSort().getOrderFor("day-confidence");
        Sort.Direction dayConfidenceDirection = dayConfidenceOrder != null ? dayConfidenceOrder.getDirection() : Sort.Direction.ASC;

        return Sort.by(dayConfidenceDirection, "sent_date_details.year", "sent_date_details.day")
                        .and(Sort.by(Sort.Direction.DESC, "selectedClientEntity.confidenceScore"));
    }

    public Long countByFactQueueIdAndCreatedDateAfter(String factQueueId, Instant date, FactInstanceFilterDTO filters) {
        Query query = buildFactInstanceQuery(factQueueId, filters);
        query.addCriteria(Criteria.where("created_date").gte(date));
        return mongoTemplate.count(query, FactInstance.class);
    }

    public Long countByFactQueueIdAndCreatedDateBefore(String factQueueId, Instant date, FactInstanceFilterDTO filters) {
        Query query = buildFactInstanceQuery(factQueueId, filters);
        query.addCriteria(Criteria.where("created_date").lt(date));
        return mongoTemplate.count(query, FactInstance.class);
    }

    public Long countByFactQueueIdAndCreatedDateBeforeAndCreatedDateAfter(String factQueueId, Instant startDate, Instant endDate, FactInstanceFilterDTO filters) {
        Query query = buildFactInstanceQuery(factQueueId, filters);
        // this is how to specify multiple checks on the same value for future reference
        query.addCriteria(new Criteria().andOperator(
            Criteria.where("created_date").lt(startDate),
            Criteria.where("created_date").gte(endDate)
            ));
//        query.addCriteria(Criteria.where("created_date").lt(endDate));
//        query.addCriteria(Criteria.where("created_date").gte(startDate));
        return mongoTemplate.count(query, FactInstance.class);
    }

    private Query buildFactInstanceQuery(String factQueueId, FactInstanceFilterDTO filters) {
        return buildFactInstanceQuery(null, factQueueId, filters);
    }

    /**
     * Build the query to retrieve fact instances for the fact queue pages.
     *
     * @param pageable
     * @param factQueueId
     * @param filters
     * @return
     */
    private Query buildFactInstanceQuery(Pageable pageable, String factQueueId, FactInstanceFilterDTO filters) {
        Query query = new Query();
        query.addCriteria(buildFactInstanceCriteria(factQueueId, filters));

        if (pageable != null) {
            query.with(pageable);
        }

        return query;
    }

    private Criteria buildFactInstanceCriteria(String factQueueId, FactInstanceFilterDTO filters) {

        Criteria criteria = Criteria.where("factQueueId").is(new ObjectId(factQueueId));

        if (!CollectionUtils.isEmpty(filters.getRisks())) {
            criteria = criteria.and("riskTaxonomyNodeId").in(filters.getRisks().toArray());
        }

        if (!CollectionUtils.isEmpty(filters.getPredicates())) {
            criteria = criteria.and("predicateTaxonomyNodeId").in(filters.getPredicates().toArray());
        }

        if (BooleanUtils.isTrue(filters.getFlag())) {
            criteria = criteria.and("flagged").is(true);
        }

        if (!CollectionUtils.isEmpty(filters.getEntities())) {
            criteria = criteria.and("entities.name").in(filters.getEntities().toArray());
        }

        if (filters.getMinimumConfidenceScore() != null) {
            criteria = criteria.and("selectedClientEntity.confidenceScore").gte(filters.getMinimumConfidenceScore());
        }

        if (!CollectionUtils.isEmpty(filters.getEntityTypes())) {
            criteria = criteria.and("entities.type").in(filters.getEntityTypes().toArray());
        }

        if (filters.getEntityId() != null) {
            criteria = criteria.and("selectedClientEntity.id").is(filters.getEntityId());
        }

        if (filters.getFeedRouterId() != null) {
            criteria = criteria.and("feedRouterId").is(filters.getFeedRouterId());
        }

        if (filters.getStartDate() != null && filters.getEndDate() != null) {
            criteria = criteria.and("sent").gte(filters.getStartDate()).lte(filters.getEndDate());
        } else if(filters.getStartDate() != null) {
            criteria = criteria.and("sent").gte(filters.getStartDate());
        } else if (filters.getEndDate() != null) {
            criteria = criteria.and("sent").lte(filters.getEndDate());
        }

        return criteria;
    }

    private List findDistinctTaxonomySpecies(String factQueueId, String taxonomyNodeId) {
        Aggregation agg = Aggregation.newAggregation(
            Aggregation.match(Criteria.where("factQueueId").is(new ObjectId(factQueueId))),
            Aggregation.group(taxonomyNodeId).count().as("total"),
            Aggregation.sort(Sort.Direction.DESC, "total")
        );

        AggregationResults results = mongoTemplate.aggregate(agg, "factInstance", Map.class);

        return results.getMappedResults();
    }

    public List findDistinctRisks(String factQueueId) {
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return findDistinctTaxonomySpecies(factQueueId, "riskTaxonomyNodeId");
    }

    public List findDistinctPredicates(String factQueueId) {
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return findDistinctTaxonomySpecies(factQueueId, "predicateTaxonomyNodeId");
    }

    @Transactional
    public FactInstance create(Fact fact, FactQueue factQueue, List<ClientEntity> entityMatches) {
        FactInstance factInstance = new FactInstance();
        factInstance.setFactQueueId(factQueue.getId());
        factInstance.setFactId(fact.getId());
        factInstance.setMsFactId(fact.getMsFactId());
        factInstance.setFeedRouterId(fact.getFeedRouterId());

        factInstance.setEntities(entityMatches);
        if (factInstance.getEntities() != null && !factInstance.getEntities().isEmpty()) {
            factInstance.setSelectedClientEntity(factInstance.getEntities().get(0));
        }
        factInstance.setRiskTaxonomyNodeId(fact.getRiskTaxonomyNodeId());
        factInstance.setPredicateTaxonomyNodeId(fact.getPredicateTaxonomyNodeId());
        factInstance.setArticles(fact.getArticles());

        SentDateDetails sentDateDetails = new SentDateDetails();
        sentDateDetails.setDay(fact.getSent().atZone(ZoneOffset.UTC).getDayOfYear());
        sentDateDetails.setYear(fact.getSent().atZone(ZoneOffset.UTC).getYear());
        factInstance.setSent(fact.getSent());
        factInstance.setSentDateDetails(sentDateDetails);
        factInstance.setFeedbackItems(fact.getFeedbackItems());

        factInstance.addEvent(
            new Event()
                .type(EventType.NEW)
                .description("Added to Inbox Folder")
                .createdByDisplay(SecurityUtils.getCurrentUserLogin().orElse(""))
                .createdDateDisplay(Instant.now().toString())
        );

        return save(factInstance);
    }

    public void moveToQueue(FactInstance factInstance, ObjectId queueId) {
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        factInstance.addEvent(
            new Event()
                .type(EventType.RETURNED_TO_FOLDER)
                .description("Returned to Inbox")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
        );
        factInstance.setLastModifiedBy(username);
        factInstance.setLastModifiedDate(Instant.now());
        factInstance.setFactQueueId(queueId);
        save(factInstance);
    }

    public FactInstanceDTO setOpened(String factInstanceId) {
        FactInstance factInstance = factInstanceRepository.findById(new ObjectId(factInstanceId))
            .orElseThrow(() -> new RuntimeException("No FactInstance found for factInstanceId: " + factInstanceId));

        Optional<Event> maybeOpenedEvent = factInstance.getEvents().stream()
            .filter(event -> EventType.OPENED.equals(event.getType()))
            .findFirst();

        // if the fact has already been opened, just return it
        if (maybeOpenedEvent.isPresent()) {
            return factInstanceMapper.toDto(factInstance);
        }

        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        factInstance.addEvent(
            new Event()
                .type(EventType.OPENED)
                .description("First Opened")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
        );

        return factInstanceMapper.toDto(save(factInstance));
    }

    public FactInstanceDTO saveWithType(FactInstanceDTO factInstanceDTO, String editType){
        FactInstance factInstance = factInstanceMapper.toEntity(factInstanceDTO);
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        factInstance.setLastModifiedBy(username);
        factInstance.setLastModifiedDate(Instant.now());
        if (editType.equals("ARTICLE_REMOVED")){
            factInstance.addEvent(
                new Event()
                .type(EventType.ARTICLE_REMOVED)
                .description("Article Removed")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
            );
        }
        return factInstanceMapper.toDto(save(factInstance));
    }

    public FactInstanceDTO save(FactInstanceDTO factInstanceDTO) {
        return save(factInstanceDTO, null);
    }

    public FactInstanceDTO save(FactInstanceDTO factInstanceDTO, Event event) {
        FactInstance factInstance = factInstanceMapper.toEntity(factInstanceDTO);
        return save(factInstance, event);
    }

    public FactInstanceDTO save(FactInstance factInstance, Event event){
        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        factInstance.setLastModifiedBy(username);
        factInstance.setLastModifiedDate(Instant.now());

        if (event == null) {
            factInstance.addEvent(
                new Event()
                    .type(EventType.EDITED)
                    .description("Edited")
                    .createdByDisplay(username)
                    .createdDateDisplay(Instant.now().toString())
            );
        } else {
            factInstance.addEvent(event);
        }
        updateEventDetails(factInstance);

        return factInstanceMapper.toDto(save(factInstance));
    }

    private static Event getMostRecentEvent(FactInstance factInstance){
        List<Event> events = factInstance.getEvents();
        return events.get(events.size()-1);
    }

    public void updateEventDetails(FactInstance newFactInstance){
        FactInstance oldFactInstance = factInstanceRepository.findById(newFactInstance.getId())
            .orElseThrow(() -> new RuntimeException("No FactInstance found for factInstanceId: " + newFactInstance.getId()));
        updateEventDetails(oldFactInstance, newFactInstance);
    }

    public static void updateEventDetails(FactInstance oldFactInstance, FactInstance newFactInstance){
        Event newEvent = getMostRecentEvent(newFactInstance);

        String oldRiskId = oldFactInstance.getRiskTaxonomyNodeId();
        String newRiskId = newFactInstance.getRiskTaxonomyNodeId();
        if (!oldRiskId.equals(newRiskId)){
            newEvent.setRiskDetail(new EventRiskDetail(oldRiskId, newRiskId));
        }
        ClientEntity oldClientEntity = oldFactInstance.getSelectedClientEntity();
        ClientEntity newClientEntity = newFactInstance.getSelectedClientEntity();
        if (!oldClientEntity.getId().equals(newClientEntity.getId())){
            newEvent.setEntityDetail(new EventEntityDetail(oldClientEntity, newClientEntity));
        }
    }

    public Long count(String factQueueId) {
       if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
           throw new AuthorizationServiceException("cannot make this request");
        }
        return factInstanceRepository.countByFactQueueId(new ObjectId(factQueueId));
    }

    @Transactional
    public void ignore(String factInstanceId, String reason, String comments) {
        FactInstance factInstance = factInstanceRepository.findById(new ObjectId(factInstanceId))
            .orElseThrow(() -> new RuntimeException("No FactInstance found for factInstanceId: " + factInstanceId));

        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) ||SecurityUtils.doesCurrentUserHaveAuthority("INBOX_RESOLVE_ALL_FACTS")) && !isMyOwnFactInstance(factInstance)) {
            throw new AuthorizationServiceException("cannot make this request");
        }

        HistoricalFactInstance historicalFactInstance = new HistoricalFactInstance(factInstance, EventType.IGNORED, "", "", SecurityUtils.getCurrentCustomerId());
        historicalFactInstanceRepository.save(historicalFactInstance);

        Fact originalFact = factRepository.findById(factInstance.getFactId())
            .orElseThrow(() -> new RuntimeException("No Fact found for factId: " + factInstance.getFactId()));
        FactFeedback feedback = new FactFeedback(originalFact, factInstance, FeedbackType.IGNORED);
        if (reason != null){
            feedback.setIgnoreReason(reason);
        }
        if (comments != null){
            feedback.setComments(comments);
        }
        factFeedbackRepository.save(feedback);

        factInstanceRepository.delete(factInstance);
    }

    private boolean isMyOwnFactInstance(FactInstance factInstance) {
        return isMyOwnFactQueue(factInstance.getFactQueueId());
    }

    private boolean isMyOwnFactQueue(ObjectId factQueueId) {
        Optional<FactQueue> factQueue = factQueueRepository.findById(factQueueId);
        if (!factQueue.isPresent()) {
            return true;
        }
        return SecurityUtils.getCurrentUserLogin().orElse("").equals(factQueue.get().getOwnerUsername());
    }

    public FactInstanceDTO saveAnalystNotes(String factInstanceId, String notes) {
        FactInstance factInstance = find(new ObjectId(factInstanceId))
            .orElseThrow(() -> new RuntimeException("No FactInstance found for factInstanceId: " + factInstanceId));
        Long userId = SecurityUtils.getCurrentUserId();

        if (SecurityUtils.doesCurrentUserHaveAuthority("INBOX_EDIT_MY_FACTS")) {
            Optional<FactQueue> factQueue = factQueueRepository.findById(factInstance.getFactQueueId());
            if(factQueue.isPresent() && !factQueue.get().getOwnerId().equals(userId)) {
                throw new AuthorizationServiceException("cannot make this request");
            }
        }

        factInstance.setAnalystNotes(notes);
        Event event = new Event().type(EventType.NOTES_SAVED)
            .description("Screener notes saved")
            .createdByDisplay(SecurityUtils.getCurrentUserLogin().orElse(""))
            .createdDateDisplay(Instant.now().toString());
        return save(factInstance, event);
    }

    public FactInstanceDTO toggleFlagged(String factInstanceId) {
        FactInstance factInstance = find(new ObjectId(factInstanceId))
            .orElseThrow(() -> new RuntimeException("No FactInstance found for factInstanceId: " + factInstanceId));

        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_EDIT_ALL_FACTS")) && !isMyOwnFactInstance(factInstance)) {
            throw new AuthorizationServiceException("cannot make this request");
        }

        factInstance.setFlagged(!factInstance.getFlagged());

        String username = SecurityUtils.getCurrentUserLogin().orElse("");
        factInstance.addEvent(
            new Event()
                .type(factInstance.getFlagged() ? EventType.FLAGGED : EventType.UNFLAGGED)
                .description(factInstance.getFlagged() ? "Flagged" : "Unflagged")
                .createdByDisplay(username)
                .createdDateDisplay(Instant.now().toString())
        );

        return factInstanceMapper.toDto(save(factInstance));
    }

    public Long countNumFactInstancesBeforeDate(String factQueueId, String date, FactInstanceFilterDTO filters){
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return countByFactQueueIdAndCreatedDateBefore(factQueueId, Instant.ofEpochMilli(parseLong(date)), filters);
    }

    public Long countNumFactInstancesAfterDate(String factQueueId, String date, FactInstanceFilterDTO filters){
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return countByFactQueueIdAndCreatedDateAfter(factQueueId, Instant.ofEpochMilli(parseLong(date)), filters);
    }

    public Long countNumFactInstancesBetweenDates(String factQueueId, String startDate, String endDate, FactInstanceFilterDTO filters){
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return countByFactQueueIdAndCreatedDateBeforeAndCreatedDateAfter(factQueueId, Instant.ofEpochMilli(parseLong(startDate)), Instant.ofEpochMilli(parseLong(endDate)), filters);
    }

    public int countNumFactInstancesFlagged(String factQueueId){
        if (!(SecurityUtils.isCurrentUserInRole(ADMIN, CUSTOMER_ADMIN, USER) || SecurityUtils.doesCurrentUserHaveAuthority("INBOX_VIEW_ALL_FOLDERS")) && !isMyOwnFactQueue(new ObjectId(factQueueId))) {
            throw new AuthorizationServiceException("cannot make this request");
        }
        return factInstanceRepository.countByFactQueueIdAndFlagged(new ObjectId(factQueueId), true);
    }

    public List<FactInstanceDTO> getByRisk(String riskTaxonomyNodeId){
        List<FactInstanceDTO> list = factInstanceRepository.findByRiskTaxonomyNodeIdOrderByCreatedDateDesc(riskTaxonomyNodeId).stream().map(FactInstanceDTO::new).collect(Collectors.toList());
        return list;
    }

    public List<FactInstanceDTO> getByEntity(String clientEntityId){
        List<FactInstanceDTO> list = factInstanceRepository.findBySelectedClientEntity_IdOrderByCreatedDateDesc(clientEntityId).stream().map(FactInstanceDTO::new).collect(Collectors.toList());
        return list;
    }

    public FactInstance save(FactInstance factInstance) {
        return save(factInstance, factInstance.getId());
    }
}
