package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class ITIssuesHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/itissues";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode itIssues = helper.insertNode(rootNode, BASE_URI, "IT_ISSUES", "IT Issues",
            "This is IT issues");

        // insert all the children
        helper.insertNode(itIssues, BASE_URI + "/breakdown", "BREAKDOWN", "Breakdown",
            "This is breakdown");

        helper.insertNode(itIssues, BASE_URI + "/cybercrime", "CYBER_CRIME", "Cyber Crime",
            "This is cyber crime");

        helper.insertNode(itIssues, BASE_URI + "/databreach", "DATA_BREACH", "Data Breach",
            "This is data breach");

        helper.insertNode(itIssues, BASE_URI + "/datamisuse", "DATA_MISUSE", "Data Misuse",
            "This is data misuse");
    }
}
