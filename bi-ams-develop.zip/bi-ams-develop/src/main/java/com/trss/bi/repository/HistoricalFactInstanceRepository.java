package com.trss.bi.repository;

import com.trss.bi.domain.factinstance.HistoricalFactInstance;
import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistoricalFactInstanceRepository extends MongoRepository<HistoricalFactInstance, ObjectId> {

    void deleteAllByFactInstance_FactIdAndCustomerId(ObjectId factId, Long customerId);

    Long deleteAllByFactInstance_FactIdInAndCustomerId(List<ObjectId> factIds, Long customerId);

    /**
     * Only to be used by cron job!
     * @param factIds
     * @return
     */
    Long deleteAllByFactInstance_FactIdIn(List<ObjectId> factIds);

    List<HistoricalFactInstance> findAllByFactInstance_FactIdAndCustomerId(ObjectId id, Long customerId);
}
