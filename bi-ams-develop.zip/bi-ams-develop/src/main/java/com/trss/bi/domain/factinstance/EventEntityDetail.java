package com.trss.bi.domain.factinstance;

public class EventEntityDetail {
    private ClientEntity oldValue;
    private ClientEntity newValue;

    public EventEntityDetail(){};

    public EventEntityDetail(ClientEntity oldValue, ClientEntity newValue) {
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public ClientEntity getOldValue() {
        return oldValue;
    }

    public void setOldValue(ClientEntity oldValue) {
        this.oldValue = oldValue;
    }

    public ClientEntity getNewValue() {
        return newValue;
    }

    public void setNewValue(ClientEntity newValue) {
        this.newValue = newValue;
    }
}
