package com.trss.bi.service.demo;

import java.util.Arrays;
import java.util.List;

public interface DemoFactItems {
    public static final List<String> FACT_ITEM_JSON = Arrays.asList(
        // fact item 1
        "{\n" +
            "    \"feedRouterId\": \"N/A\",\n" + // will be overridden by the loader
            "    \"matchingFactQueueConfigIds\": [\"N/A\"],\n" + // will be overridden by the loader
            "    \"subject\": {\"aliasChain\": [\"N/A\"]},\n" + // not used
            "    \"predicate\": \"https://graph.thomsonreuters.com/pred:associated_with\",\n" + // not used
            "    \"risk\": \"https://graph.thomsonreuters.com/fact_type/risk/corporate_crime/insider_trading\",\n" +
            "    \"matchCandidates\": [\n" +
            "        {\n" +
            "            \"id\": \"Tomer Feingold\",\n" +
            "            \"name\": \"Tomer Feingold\",\n" +
            "            \"confidenceScore\": \"0.8\",\n" +
            "            \"type\": \"person\",\n" +
            "            \"dob\": \"January 21st, 1980\",\n" +
            "            \"nationality\": \"Israeli\"" +

            "        },\n" +
            "        {\n" +
            "            \"id\": \"Tom Feingold\",\n" +
            "            \"name\": \"Tom Feingold\",\n" +
            "            \"confidenceScore\": \"0.5\",\n" +
            "            \"type\": \"person\",\n" +
            "            \"dob\": \"August 28th, 1985\",\n" +
            "            \"nationality\": \"American\"" +
            "        }\n" +
            "    ],\n" +
            "    \"articles\": [\n" +
            "        {\n" +
            "            \"title\": \"SEC Charges Two Additional Traders in International Insider Trading Scheme\",\n" +
            "            \"uri\": \"notAvailable\",\n" +
            "            \"guid\": \"I0c857a605ff211ea996598c5fd2ad78d\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        },\n" +
            "        {\n" +
            "            \"title\": \"SEC Charges Two Additional Traders, Tomer Feingold, Dov Malnik in International Insider Trading Scheme\",\n" +
            "            \"uri\": \"https://www.newsbreak.com/district-of-columbia/washington/news/0OLqE8Qt/sec-charges-two-additional-traders-tomer-feingold-dov-malnik-in-international-insider-trading-scheme\",\n" +
            "            \"guid\": \"notAvailable\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        }\n" +
            "    ]\n" +
        "}"
        // fact item 2 - dov
        ,"{\n" +
            "    \"feedRouterId\": \"N/A\",\n" + // will be overridden by the loader
            "    \"matchingFactQueueConfigIds\": [\"N/A\"],\n" + // will be overridden by the loader
            "    \"subject\": {\"aliasChain\": [\"N/A\"]},\n" + // not used
            "    \"predicate\": \"https://graph.thomsonreuters.com/pred:associated_with\",\n" + // not used
            "    \"risk\": \"https://graph.thomsonreuters.com/fact_type/risk/corporate_crime/insider_trading\",\n" +
            "    \"matchCandidates\": [\n" +
            "        {\n" +
            "            \"id\": \"Dov Malnik\",\n" +
            "            \"name\": \"Dov Malnik\",\n" +
            "            \"confidenceScore\": \"0.85\",\n" +
            "            \"type\": \"person\",\n" +
            "            \"dob\": \"February 1st, 1978\",\n" +
            "            \"nationality\": \"Israeli\"" +
            "        },\n" +
            "        {\n" +
            "            \"id\": \"Dave Melnick\",\n" +
            "            \"name\": \"Dave Melnick\",\n" +
            "            \"confidenceScore\": \"0.4\",\n" +
            "            \"type\": \"person\",\n" +
            "            \"nationality\": \"American\",\n" +
            "            \"positionAtCompany\": \"VP\"\n" +
            "        }\n" +
            "    ],\n" +
            "    \"articles\": [\n" +
            "        {\n" +
            "            \"title\": \"SEC Charges Two Additional Traders in International Insider Trading Scheme\",\n" +
            "            \"uri\": \"notAvailable\",\n" +
            "            \"guid\": \"I0c857a605ff211ea996598c5fd2ad78d\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        },\n" +
            "        {\n" +
            "            \"title\": \"SEC Charges Two Additional Traders, Tomer Feingold, Dov Malnik in International Insider Trading Scheme\",\n" +
            "            \"uri\": \"https://www.newsbreak.com/district-of-columbia/washington/news/0OLqE8Qt/sec-charges-two-additional-traders-tomer-feingold-dov-malnik-in-international-insider-trading-scheme\",\n" +
            "            \"guid\": \"notAvailable\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        }\n" +
            "    ]\n" +
            "}"
        // fact item 3 (article #2)
        ,"{\n" +
            "    \"feedRouterId\": \"N/A\",\n" + // will be overridden by the loader
            "    \"matchingFactQueueConfigIds\": [\"N/A\"],\n" + // will be overridden by the loader
            "    \"subject\": {\"aliasChain\": [\"N/A\"]},\n" + // not used
            "    \"predicate\": \"https://graph.thomsonreuters.com/pred:associated_with\",\n" + // not used
            "    \"risk\": \"https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/violent_crime/kidnap\",\n" +
            "    \"matchCandidates\": [\n" +
            "        {\n" +
            "            \"id\": \"Al-Fatiha Global\",\n" +
            "            \"name\": \"Al-Fatiha Global\",\n" +
            "            \"confidenceScore\": \"0.9\",\n" +
            "            \"type\": \"company\",\n" +
            "            \"hqAddress\": \"Worcester, London\"\n" +
            "        }\n" +
            "    ],\n" +
            "    \"articles\": [\n" +
            "        {\n" +
            "            \"title\": \"'It was an inside job': Brother of ISIS murder victim Alan Henning believes his kidnapping was set up by someone on the same Syrian aid convoy\",\n" +
            "            \"uri\": \"notAvailable\",\n" +
            "            \"guid\": \"I18be6910758a11ea8794e25bf60b11e5\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        }\n" +
            "    ]\n" +
            "}"
        // fact item 4 (article #2)
        ,"{\n" +
            "    \"feedRouterId\": \"N/A\",\n" + // will be overridden by the loader
            "    \"matchingFactQueueConfigIds\": [\"N/A\"],\n" + // will be overridden by the loader
            "    \"subject\": {\"aliasChain\": [\"N/A\"]},\n" + // not used
            "    \"predicate\": \"https://graph.thomsonreuters.com/pred:associated_with\",\n" + // not used
            "    \"risk\": \"https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/violent_crime/murder\",\n" +
            "    \"matchCandidates\": [\n" +
            "        {\n" +
            "            \"id\": \"Al-Fatiha Global\",\n" +
            "            \"name\": \"Al-Fatiha Global\",\n" +
            "            \"confidenceScore\": \"0.9\",\n" +
            "            \"type\": \"company\",\n" +
            "            \"hqAddress\": \"Worcester, London\"\n" +
            "        }\n" +
            "    ],\n" +
            "    \"articles\": [\n" +
            "        {\n" +
            "            \"title\": \"'It was an inside job': Brother of ISIS murder victim Alan Henning believes his kidnapping was set up by someone on the same Syrian aid convoy\",\n" +
            "            \"uri\": \"notAvailable\",\n" +
            "            \"guid\": \"I18be6910758a11ea8794e25bf60b11e5\",\n" +
            "            \"snippet\": \"notAvailable\",\n" +
            "            \"author\": \"notAvailable\",\n" +
            "            \"publicationDate\": \"notAvailable\",\n" +
            "            \"provider\": \"newsroom.thomsonreuters.com\"\n" +
            "        }\n" +
            "    ]\n" +
            "}"
    );
}
