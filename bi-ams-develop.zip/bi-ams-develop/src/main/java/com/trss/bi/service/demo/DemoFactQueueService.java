package com.trss.bi.service.demo;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trss.bi.service.FactQueueService;
import com.trss.bi.service.FeedItemService;
import com.trss.bi.service.dto.FactQueueDTO;
import com.trss.bi.service.dto.FeedItemDTO;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Used to create a fact queue pre-poluated with data for demos.
 */
@Service
public class DemoFactQueueService {

    private FactQueueService factQueueService;
    private FeedItemService feedItemService;

    public DemoFactQueueService(FactQueueService factQueueService, FeedItemService feedItemService) {
        this.factQueueService = factQueueService;
        this.feedItemService = feedItemService;
    }

    private static FeedItemDTO buildFeedItemDTO(String feedItemJson) {
        try {
            // handle &nbsp;
            return new ObjectMapper().readValue(feedItemJson.replace('\u00A0',' '), FeedItemDTO.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String loadDemoQueue(String name) {
        FactQueueDTO factQueueDTO = factQueueService.findByName(name);
        if (factQueueDTO == null) throw new RuntimeException("No Fact Queue found with name: " + name);

        // load the demo data json to memory
        List<String> feedItemJson = DemoFactItems.FACT_ITEM_JSON;
        System.out.println("/n/n/n" + feedItemJson.get(0));

        for (FeedItemDTO feedItemDTO : feedItemJson.stream().map(DemoFactQueueService::buildFeedItemDTO).collect(Collectors.toList())) {
            // set the matching fact queue config id
            feedItemDTO.setMatchingFactQueueConfigIds(Arrays.asList(factQueueDTO.getFactQueueConfigId()));
            feedItemDTO.setSent(Instant.now());

            // set the fact queue config ids within the match candidates
            feedItemDTO.getMatchCandidates().forEach(mc -> {
                mc.setFactQueueConfigIds(Arrays.asList(factQueueDTO.getFactQueueConfigId()));
            });

            // set a random feed router id, since this is demo data
            feedItemDTO.setFeedRouterId(UUID.randomUUID().toString());

            feedItemService.loadFeedItem(feedItemDTO);
        }

        return factQueueDTO.getId();
    }
}
