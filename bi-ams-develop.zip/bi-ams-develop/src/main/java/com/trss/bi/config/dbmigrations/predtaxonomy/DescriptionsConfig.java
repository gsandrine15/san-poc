package com.trss.bi.config.dbmigrations.predtaxonomy;

import java.util.HashMap;
import java.util.Map;

public class DescriptionsConfig {
    public static Map<String,String> URI_DESCRIPTIONS_5_14_2021 = new HashMap<>();

    static {
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to", "An entity or person has been associated with a risk but it is not possible to determine the predicate.");
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/suspected", "A person or entity is informally accused of having committed an offence. They may or may not have been arrested. They have not yet been charged.");
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/charged", "A person or entity has been formally accused by a legal authority of committing an offence under law.");
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/judgement", "If a person or entity has pleaded guilty or been found guilty by a judge or jury in a court of law in relation to the offence.");
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/not_guilty_or_innocent", "A person or entity has been found to be not guilty by a judge or jury in a court of law after trial and is freed from the criminal charge.");
        URI_DESCRIPTIONS_5_14_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/unknown", "An entity or person has been associated with a risk but it is not possible to determine the predicate.");
      }

    public static Map<String,String> URI_DESCRIPTIONS_5_27_2021 = new HashMap<>();

    static {
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to", "An entity or person has been associated with a risk but it is not possible to determine the predicate.");
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_suspected_of", "A person or entity is informally accused of having committed an offence. They may or may not have been arrested. They have not yet been charged.");
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_charged_with", "A person or entity has been formally accused by a legal authority of committing an offence under law.");
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_convicted_of", "If a person or entity has pleaded guilty or been found guilty by a judge or jury in a court of law in relation to the offence.");
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_acquitted_of", "A person or entity has been found to be not guilty by a judge or jury in a court of law after trial and is freed from the criminal charge.");
        URI_DESCRIPTIONS_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/case_dismissed", "A judge has ruled that all or a portion of a case or lawsuit against a person or entity is thrown out without further testimony. The judgement may be made before, during or after a trial. Or a plaintiff has dismissed part or all of a lawsuit against a person or entity as a result of settlement or the inability to prove the case.");
    }
}
