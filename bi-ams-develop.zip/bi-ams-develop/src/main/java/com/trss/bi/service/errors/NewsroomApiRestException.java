package com.trss.bi.service.errors;

import java.io.IOException;

/**
 * Newsroom API Exception.
 */
public class NewsroomApiRestException extends IOException {

    public NewsroomApiRestException() {
        super();
    }

    public NewsroomApiRestException(String message) {
        super(message);
    }

    public NewsroomApiRestException(String message, Throwable cause) {
        super(message, cause);
    }

    public NewsroomApiRestException(Throwable cause) {
        super(cause);
    }
}
