package com.trss.bi.config.dbmigrations.predtaxonomy;

import java.util.HashMap;
import java.util.Map;

public class UriConfig {

    public static Map<String,String> URI_UPDATES_5_27_2021 = new HashMap<>();

    static {
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to", "https://graph.thomsonreuters.com/fact_type/risk/pred/is_related_to");
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/suspected", "https://graph.thomsonreuters.com/fact_type/risk/pred/is_suspected_of");
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/charged", "https://graph.thomsonreuters.com/fact_type/risk/pred/is_charged_with");
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/judgement", "https://graph.thomsonreuters.com/fact_type/risk/pred/is_convicted_of");
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/not_guilty_or_innocent", "https://graph.thomsonreuters.com/fact_type/risk/pred/is_acquitted_of");
        URI_UPDATES_5_27_2021.put("https://graph.thomsonreuters.com/fact_type/risk/pred/unknown", "https://graph.thomsonreuters.com/fact_type/risk/pred/case_dismissed");
    }
}
