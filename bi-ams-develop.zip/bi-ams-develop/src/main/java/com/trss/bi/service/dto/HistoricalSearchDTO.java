package com.trss.bi.service.dto;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.Subject;
import com.trss.bi.domain.factinstance.ClientEntity;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class HistoricalSearchDTO implements Serializable {
    private String queueId;
    private ClientEntity clientEntity;
    private ArrayList<String> facts;
    private String msFactId;
    private String feedRouterId;
    private Subject subject;
    private List<Article> articles;
    private String riskTaxonomy;
    private String factType;
    private Instant sent;

    public String getQueueId() {
        return queueId;
    }

    public void setQueueId(String queueId) {
        this.queueId = queueId;
    }

    public ClientEntity getClientEntity() {
        return clientEntity;
    }

    public void setClientEntity(ClientEntity clientEntity) {
        this.clientEntity = clientEntity;
    }

    public ArrayList<String> getFacts() {
        return facts;
    }

    public void setFacts(ArrayList<String> facts) {
        this.facts = facts;
    }

    public String getRiskTaxonomy() {
        return riskTaxonomy;
    }

    public void setRiskTaxonomy(String riskTaxonomy) {
        this.riskTaxonomy = riskTaxonomy;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }


    public Subject getSubject() {
        return subject;
    }

    public void setSubject(Subject subject) {
        this.subject = subject;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public void setFeedRouterId(String feedRouterId) {
        this.feedRouterId = feedRouterId;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public String getFactType() {
        return factType;
    }

    public void setFactType(String factType) {
        this.factType = factType;
    }

    public Instant getSent() {
        return sent;
    }

    public void setSent(Instant sent) {
        this.sent = sent;
    }

}

