package com.trss.bi.web.rest;

import com.trss.bi.security.AuthorizationConstants;
import com.trss.bi.service.FeedItemSender;
import com.trss.bi.service.FeedItemService;

import com.trss.bi.service.dto.FeedItemDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
public class FeedItemResource {

    private final Logger log = LoggerFactory.getLogger(FeedItemResource.class);

    private FeedItemService feedItemService;
    private FeedItemSender feedItemSender;

    @Value("${rabbit.fact-feed.queue}")
    private String factFeedQueueName;

    public FeedItemResource(FeedItemService feedItemService, FeedItemSender feedItemSender) {
        this.feedItemService = feedItemService;
        this.feedItemSender = feedItemSender;
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_ADMIN_TOOLS)
    @GetMapping("/feed-items/retry")
    public Map<String,Object> retryDLQMessages() {
        Integer numMessages = feedItemService.retryDLQMessages(factFeedQueueName);

        Map<String,Object> response = new HashMap<>();
        response.put(factFeedQueueName, numMessages);

        return response;
    }

    @PreAuthorize(AuthorizationConstants.ACCESS_ADMIN_TOOLS)
    @GetMapping("/feed-items/dlq-count")
    public Integer getDlqCount() {
        return feedItemService.getDLQCount(factFeedQueueName);
    }

    @PostMapping("/feed-item")
    public void loadFeedItem(@RequestBody FeedItemDTO feedItemDTO) {
        feedItemService.loadFeedItem(feedItemDTO);
    }

    @PostMapping("/feed-item-generate")
    public String generateFeedItem(@RequestBody FeedItemDTO feedItemDTO) {
        feedItemSender.sendFeedItem(feedItemDTO);
        return "sent: " + feedItemDTO;
    }

    public String getFactFeedQueueName() {
        return factFeedQueueName;
    }

    public void setFactFeedQueueName(String factFeedQueueName) {
        this.factFeedQueueName = factFeedQueueName;
    }
}
