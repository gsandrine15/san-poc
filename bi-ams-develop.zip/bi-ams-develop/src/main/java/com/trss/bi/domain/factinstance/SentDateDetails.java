package com.trss.bi.domain.factinstance;

public class SentDateDetails {

    private double year;
    private double day;

    public SentDateDetails() {}

    public SentDateDetails(double year, double day) {
        this.year = year;
        this.day = day;
    }

    public double getYear() {
        return year;
    }

    public void setYear(double year) {
        this.year = year;
    }

    public double getDay() {
        return day;
    }

    public void setDay(double day) {
        this.day = day;
    }

    @Override
    public String toString() {
        return "SentDateDetails{" +
            "year=" + year +
            ", day=" + day +
            "}";
    }
}
