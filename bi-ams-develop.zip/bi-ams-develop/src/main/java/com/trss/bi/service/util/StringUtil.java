package com.trss.bi.service.util;

import org.apache.commons.lang.StringUtils;

public class StringUtil {
    private static int HEX = 16;
    private static int MIN_LENGTH = 4;
    private static char PAD_CHAR = '0';

    public static String toHex(Long number) {
        return StringUtils.leftPad(Long.toString(number, HEX), MIN_LENGTH, PAD_CHAR).toUpperCase();
    }

    public static Long toBase10(String value) {
        return Long.parseLong(value, HEX);
    }

    public static String capitalize(String value) {
        return value.substring(0,1).toUpperCase() + value.substring(1).toLowerCase();
    }
    public static void main(String[] args) {
        Long number = 1000L;
        String base36Val = toHex(number);
        Long backToNumber = toBase10(base36Val);
        System.out.println(number + " -> " + base36Val + " -> " + backToNumber);
    }
}
