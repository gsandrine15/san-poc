package com.trss.bi.service.errors;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;

import static org.springframework.http.HttpStatus.Series.CLIENT_ERROR;
import static org.springframework.http.HttpStatus.Series.SERVER_ERROR;

/**
 * ResponseErrorHandler for Newsroom API errors.
 */
@Component
public class NewsroomApiResponseErrorHandler implements ResponseErrorHandler {

    @Override
    public boolean hasError(ClientHttpResponse httpResponse) throws IOException {
        return (httpResponse.getStatusCode().series() == CLIENT_ERROR
            || httpResponse.getStatusCode().series() == SERVER_ERROR);
    }

    @Override
    public void handleError(ClientHttpResponse httpResponse)
        throws IOException {

        StringBuilder sb = new StringBuilder();
        sb.append("Newsroom API Error - ")
            .append(httpResponse.getRawStatusCode())
            .append(" ")
            .append(httpResponse.getStatusText());

        if (httpResponse.getStatusCode().series() == SERVER_ERROR) {
            throw new NewsroomApiRestException(sb.toString());
        } else if (httpResponse.getStatusCode().series() == CLIENT_ERROR) {
            throw new NewsroomApiRestException(sb.toString());
        }
    }
}
