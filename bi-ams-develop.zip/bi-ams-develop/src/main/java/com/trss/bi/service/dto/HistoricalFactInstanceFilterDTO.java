package com.trss.bi.service.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class HistoricalFactInstanceFilterDTO implements Serializable {


    List<String> risks;
    List<String> predicates;
    List<String> entityTypes;
    List<String> entities;
    List<String> resolutions;
    List<String> screeners;
    Date startDate;
    Date endDate;

    public List<String> getRisks() {
        return risks;
    }

    public void setRisks(List<String> risks) {
        this.risks = risks;
    }

    public List<String> getPredicates() {
        return predicates;
    }

    public void setPredicates(List<String> predicates) {
        this.predicates = predicates;
    }

    public List<String> getEntityTypes() {
        return entityTypes;
    }

    public void setEntityTypes(List<String> entityTypes) {
        this.entityTypes = entityTypes;
    }

    public List<String> getEntities() {
        return entities;
    }

    public void setEntities(List<String> entities) {
        this.entities = entities;
    }

    public List<String> getResolutions() {
        return resolutions;
    }

    public void setResolutions(List<String> resolutions) {
        this.resolutions = resolutions;
    }

    public List<String> getScreeners() {
        return screeners;
    }

    public void setScreeners(List<String> screeners) {
        this.screeners = screeners;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }
}
