package com.trss.bi.domain.factinstance;

import com.trss.bi.domain.AbstractAuditingEntity;

import java.io.Serializable;
import java.time.Instant;
import java.util.List;

public class Event extends AbstractAuditingEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    private EventType type;
    private String description;
    private String createdByDisplay;
    private String createdDateDisplay;
    private EventEntityDetail entityDetail;
    private EventRiskDetail riskDetail;

    public Event type(EventType type) {
        setType(type);
        return this;
    }

    public Event description(String description) {
        setDescription(description);
        return this;
    }

    public Event createdByDisplay(String createdByDisplay) {
        setCreatedByDisplay(createdByDisplay);
        return this;
    }

    public Event createdDateDisplay(String createdDateDisplay) {
        setCreatedDateDisplay(createdDateDisplay);
        return this;
    }

    public EventType getType() {
        return type;
    }

    public void setType(EventType type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreatedByDisplay(String createdByDisplay) {
        this.createdByDisplay = createdByDisplay;
    }

    public void setCreatedDateDisplay(String createdDateDisplay) {
        this.createdDateDisplay = createdDateDisplay;
    }

    public String getCreatedByDisplay() {
        return this.createdByDisplay;
    }

    public String getCreatedDateDisplay() {
        return this.createdDateDisplay;
    }

    public String getCreatedDateDisplayOld() {
        return getCreatedDate().toString();
    }

    public EventEntityDetail getEntityDetail() {
        return entityDetail;
    }

    public void setEntityDetail(EventEntityDetail entityDetail) {
        this.entityDetail = entityDetail;
    }

    public EventRiskDetail getRiskDetail() {
        return riskDetail;
    }

    public void setRiskDetail(EventRiskDetail riskDetail) {
        this.riskDetail = riskDetail;
    }
}
