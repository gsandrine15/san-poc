package com.trss.bi.config;

public class AWSElasticSearchCredentialsConfiguration

{
}
