package com.trss.bi.jobs.cleanup;

import com.trss.bi.service.FactCleanupService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class CleanupJob {
    private final Logger log = LoggerFactory.getLogger(CleanupJob.class);

    private FactCleanupService factCleanupService;
    private int maxDays;
    private boolean enabled;

    public CleanupJob(FactCleanupService factCleanupService, @Value("${cleanup-job.max-days}") int maxDays, @Value("${cleanup-job.enabled}") boolean enabled) {
        this.factCleanupService = factCleanupService;
        this.maxDays = maxDays;
        this.enabled = enabled;
    }

    @Scheduled(cron = "${cleanup-job.cron}", zone = "Europe/London")
    public void scheduledRun() {
        if (enabled) {
            log.info("FactCleanupJob starting...");
            factCleanupService.deleteFactsAndRelatedByDaysOld(maxDays);
        }
        else {
            log.info("FactCleanupJob disabled. Skipping...");
        }
    }
}
