/**
 * View Models used by Spring MVC REST controllers.
 */
package com.trss.bi.web.rest.vm;
