package com.trss.bi.domain;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;

@Document(collection = "newsroomPublisher")
public class NewsroomPublisher implements Serializable {

    @Id
    private ObjectId id;

    private String journalCode;
    private String journalName;
    private String status;
    private String ipProductName;
    private String pubCode;
    private String type;

    public ObjectId getId() {
        return id;
    }

    public void setId(ObjectId id) {
        this.id = id;
    }

    public String getJournalCode() {
        return journalCode;
    }

    public void setJournalCode(String journalCode) {
        this.journalCode = journalCode;
    }

    public String getJournalName() {
        return journalName;
    }

    public void setJournalName(String journalName) {
        this.journalName = journalName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIpProductName() {
        return ipProductName;
    }

    public void setIpProductName(String ipProductName) {
        this.ipProductName = ipProductName;
    }

    public String getPubCode() {
        return pubCode;
    }

    public void setPubCode(String pubCode) {
        this.pubCode = pubCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "NewsroomPublisher{" +
            "id=" + id +
            ", journalCode='" + journalCode + '\'' +
            ", journalName='" + journalName + '\'' +
            ", status='" + status + '\'' +
            ", ipProductName='" + ipProductName + '\'' +
            ", pubCode='" + pubCode + '\'' +
            ", type='" + type + '\'' +
            '}';
    }
}
