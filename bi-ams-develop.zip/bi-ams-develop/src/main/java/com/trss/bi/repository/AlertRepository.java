package com.trss.bi.repository;

import com.trss.bi.domain.AbstractAuditingEntity;
import com.trss.bi.domain.alert.Alert;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AlertRepository extends MongoRepository<Alert, ObjectId> {
    Alert findByClientEntityId(String clientEntityId);
    Optional<Alert> findByIdAndCustomerId(ObjectId id, Long customerId);
    List<Alert> findAllByIdInOrderByCreatedDateAsc(List<ObjectId> ids);
    List<Alert> findAllByCustomerIdOrderByCreatedDateAsc(Long customerId);
    List<Alert> findByIdInAndCustomerId(List<ObjectId> objectIds, Long customerId);

    List<Alert> findAllByFactInstances_RiskTaxonomyNodeId(String riskTaxonomyNodeId);

    List<Alert> findAllByFactInstances_FactId(ObjectId objectId);

    /**
     * @deprecated use {@link com.trss.bi.service.Service#save(AbstractAuditingEntity, ObjectId)} instead
     * @param alert
     * @return
     */
    @Deprecated
    Alert save(Alert alert);
}
