package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.domain.factinstance.HistoricalFactInstance;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

@ChangeLog(order = "009")
public class ResolutionNameUpdate {
    @ChangeSet(order = "02", author = "admin", id = "009-02-update-historical-fact-instance-resolution-name")
    public void updateHistoricalFactInstanceResolutionNames(MongoTemplate mongoTemplate){
        Query query = new Query();
        query.addCriteria(Criteria.where("archivedReason").is("IGNORED"));
        Update update = new Update();
        update.set("archivedReason", "DISCARDED");
        mongoTemplate.updateMulti(query, update, HistoricalFactInstance.class);

    }
}
