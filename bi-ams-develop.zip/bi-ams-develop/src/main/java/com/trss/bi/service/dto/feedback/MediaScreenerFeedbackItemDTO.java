package com.trss.bi.service.dto.feedback;

/**
 * Represents media screener single sentence feedback.
 */
public class MediaScreenerFeedbackItemDTO {

    protected String sentence;
    protected String riskUri;
    protected int riskOffsetStart;
    protected int riskOffsetEnd;
    protected int entityOffsetStart;
    protected int entityOffsetEnd;
    protected String predicate;
    protected boolean isCompletelyValid;
    protected boolean isCompletelyInvalid;

    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public String getRiskUri() {
        return riskUri;
    }

    public void setRiskUri(String riskUri) {
        this.riskUri = riskUri;
    }

    public int getRiskOffsetStart() {
        return riskOffsetStart;
    }

    public void setRiskOffsetStart(int riskOffsetStart) {
        this.riskOffsetStart = riskOffsetStart;
    }

    public int getRiskOffsetEnd() {
        return riskOffsetEnd;
    }

    public void setRiskOffsetEnd(int riskOffsetEnd) {
        this.riskOffsetEnd = riskOffsetEnd;
    }

    public int getEntityOffsetStart() {
        return entityOffsetStart;
    }

    public void setEntityOffsetStart(int entityOffsetStart) {
        this.entityOffsetStart = entityOffsetStart;
    }

    public int getEntityOffsetEnd() {
        return entityOffsetEnd;
    }

    public void setEntityOffsetEnd(int entityOffsetEnd) {
        this.entityOffsetEnd = entityOffsetEnd;
    }

    public String getPredicate() {
        return predicate;
    }

    public void setPredicate(String predicate) {
        this.predicate = predicate;
    }

    public boolean isCompletelyValid() {
        return isCompletelyValid;
    }

    public void setCompletelyValid(boolean completelyValid) {
        isCompletelyValid = completelyValid;
    }

    public boolean isCompletelyInvalid() {
        return isCompletelyInvalid;
    }

    public void setCompletelyInvalid(boolean completelyInvalid) {
        isCompletelyInvalid = completelyInvalid;
    }

    @Override
    public String toString() {
        return "MediaScreenerFeedbackItemDTO{" +
            "sentence='" + sentence + '\'' +
            ", riskUri='" + riskUri + '\'' +
            ", riskOffsetStart=" + riskOffsetStart +
            ", riskOffsetEnd=" + riskOffsetEnd +
            ", entityOffsetStart=" + entityOffsetStart +
            ", entityOffsetEnd=" + entityOffsetEnd +
            ", predicate='" + predicate + '\'' +
            ", isCompletelyValid=" + isCompletelyValid +
            ", isCompletelyInvalid=" + isCompletelyInvalid +
            '}';
    }
}
