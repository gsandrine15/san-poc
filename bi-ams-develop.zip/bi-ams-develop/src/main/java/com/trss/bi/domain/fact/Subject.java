package com.trss.bi.domain.fact;

import java.util.List;

public class Subject {
    private String uri;
    private List<String> aliasChain;
    private double entityConfidence;
    private double entityRiskConfidence;

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public List<String> getAliasChain() {
        return aliasChain;
    }

    public void setAliasChain(List<String> aliasChain) {
        this.aliasChain = aliasChain;
    }

    public double getEntityConfidence() {
        return entityConfidence;
    }

    public void setEntityConfidence(double entityConfidence) {
        this.entityConfidence = entityConfidence;
    }

    public double getEntityRiskConfidence() {
        return entityRiskConfidence;
    }

    public void setEntityRiskConfidence(double entityRiskConfidence) {
        this.entityRiskConfidence = entityRiskConfidence;
    }
}
