package com.trss.bi.domain.factinstance;

public enum EventDetailType {
    RISK("RISK"),
    ENTITY("ENTITY");

    private final String value;

    EventDetailType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
