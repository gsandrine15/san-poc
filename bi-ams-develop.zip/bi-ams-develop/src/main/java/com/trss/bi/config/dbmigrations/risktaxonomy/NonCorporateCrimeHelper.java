package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.Taxonomy;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class NonCorporateCrimeHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/noncorporatecrime";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode nonCorporateCrime = helper.insertNode(rootNode,
            BASE_URI, "NON_CORP_CRIME", "Non-Corporate Crime", "This is non-corporate crime");

        // children

        // organized crime
        TaxonomyNode organizedCrime = helper.insertNode(nonCorporateCrime,
            BASE_URI + "/organized_crime", "ORG_CRIME", "Organized Crime", "This is organized crime");
        createOrganizedCrimeChildren(helper, organizedCrime);

        // violent crime
        TaxonomyNode violentCrime = helper.insertNode(nonCorporateCrime,
            BASE_URI + "/violentcrime", "VLNT_CRIME", "Violent Crime", "This is violent crime");
        createViolentCrimeChildren(helper, violentCrime);

        // misappropriation
        TaxonomyNode misappropriation = helper.insertNode(nonCorporateCrime,
            BASE_URI + "/misappropriation", "MISAPPROPRIATION", "Misappropriation", "This is misappropriation");
        createMisappropriationChildren(helper, misappropriation);

        // other non-corporate
        TaxonomyNode otherNonCorporate = helper.insertNode(nonCorporateCrime,
            BASE_URI + "/othernoncorporate", "OTHER_NON_CORP", "Other Non-Corporate", "This is other non-corporate");
        createOtherNonCorporateChildren(helper, otherNonCorporate);
    }

    private static void createOrganizedCrimeChildren(TaxonomySetupHelper helper, TaxonomyNode organizedCrime) {
        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/armstraffic", "ARMS_TRAFFIC", "Arms Trafficking", "This is arms trafficking");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/gambling", "GAMBLING", "Gambling", "This is gambling");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/drugtraffic", "DRUG_TRAFFIC", "Drug Trafficking", "This is drug trafficking");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/humantraffic", "HUMAN_TRAFFIC", "Human Trafficking", "This is human trafficking");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/illicitgoods", "ILLICIT_GOODS", "Illicit Goods", "This is illicit goods");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/orgcrime", "ORG_CRIME_LEAF", "Organized Crime (leaf)", "This is organized crime (leaf)");

        helper.insertNode(organizedCrime,
            BASE_URI + "/organized_crime/sexexploit", "SEX_EXPLOIT", "Sexual Exploitation", "This is sexual exploitation");
    }

    private static void createViolentCrimeChildren(TaxonomySetupHelper helper, TaxonomyNode violentCrime) {
        helper.insertNode(violentCrime,
            BASE_URI + "/violentcrime/injury", "INJURY", "Injury", "This is injury");

        helper.insertNode(violentCrime,
            BASE_URI + "/violentcrime/kidnap", "KIDNAP", "Kidnap", "This is kidnapping");

        helper.insertNode(violentCrime,
            BASE_URI + "/violentcrime/murder", "MURDER", "Murder", "This is murder");

        helper.insertNode(violentCrime,
            BASE_URI + "/violentcrime/piracy", "PIRACY", "Piracy", "This is piracy");

        helper.insertNode(violentCrime,
            BASE_URI + "/violentcrime/robbery", "ROBBERY", "Robbery", "This is robbery");
    }

    private static void createMisappropriationChildren(TaxonomySetupHelper helper, TaxonomyNode misappropriation) {
        helper.insertNode(misappropriation,
            BASE_URI + "/misappropriation/burglary", "BURGLARY", "Burglary", "This is burglary");

        helper.insertNode( misappropriation,
            BASE_URI + "/misappropriation/genfraud", "GENFRAUD", "General Fraud", "This is general fraud");

        helper.insertNode(misappropriation,
            BASE_URI + "/misappropriation/extortion", "EXTORTION", "Extortion", "This is extortion");

        helper.insertNode(misappropriation,
            BASE_URI + "/misappropriation/theft", "THEFT", "Theft", "This is theft");
    }

    private static void createOtherNonCorporateChildren(TaxonomySetupHelper helper, TaxonomyNode misappropriation) {
        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/currency", "CURRENCY", "Currency", "This is currency");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/drugoffense", "DRUG_OFFENSE", "Drug Offense", "This is drug offense");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/ipcrime", "IP_CRIME", "IP Crime", "This is IP crime");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/fugitive", "FUGITIVE", "Fugitive", "This is fugitive");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/illegalweapons", "ILLEGAL_WEAPONS", "Illegal Weapons", "This is illegal weapons");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/sexoffense", "SEX_OFFENSE", "Sex Offense", "This is sex offense");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/usury", "USURY", "Usury", "This is usury");

        helper.insertNode(misappropriation,
            BASE_URI + "/othernoncorporate/watchlist", "WATCH_LIST", "Watch list", "This is watch list");
    }
}
