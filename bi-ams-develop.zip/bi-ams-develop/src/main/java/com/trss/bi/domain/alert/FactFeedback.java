package com.trss.bi.domain.alert;

import com.trss.bi.domain.article.Article;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.ClientEntity;
import com.trss.bi.domain.factinstance.FactInstance;

import java.util.List;

public class FactFeedback {
    private FeedbackType feedbackType;
    private String feedRouterId;

    private String originalRiskURI;
    private String currentRiskURI;

    private String originalPredicateURI;
    private String currentPredicateURI;

    private double entityConfidence;
    private ClientEntity originalEntity;
    private ClientEntity currentEntity;

    private List<Article> originalArticles;
    private List<Article> currentArticles;

    private String ignoreReason;
    private String comments;

    public FactFeedback (Fact originalFact, FactInstance currentFact, FeedbackType type){
        feedRouterId = originalFact.getFeedRouterId();

        originalRiskURI = originalFact.getRiskTaxonomyNodeId();
        currentRiskURI = currentFact.getRiskTaxonomyNodeId();

        originalPredicateURI = originalFact.getPredicateTaxonomyNodeId();
        currentPredicateURI = currentFact.getPredicateTaxonomyNodeId();

        entityConfidence = currentFact.getSelectedClientEntity().getConfidenceScore();
        originalEntity = originalFact.getEntities().get(0);
        currentEntity = currentFact.getSelectedClientEntity();

        originalArticles = originalFact.getArticles();
        currentArticles = currentFact.getArticles();

        if (type == FeedbackType.ACCEPTED){
            if (!originalRiskURI.equals(currentRiskURI) || !originalEntity.getId().equals(currentEntity.getId())){
                type = FeedbackType.ACCEPTED_CHANGED;
            }
        }
        feedbackType = type;
    }

    public String getFeedRouterId() {
        return feedRouterId;
    }

    public FeedbackType getFeedbackType() {
        return feedbackType;
    }

    public String getOriginalRiskURI() {
        return originalRiskURI;
    }

    public String getCurrentRiskURI() {
        return currentRiskURI;
    }

    public String getOriginalPredicateURI() {
        return originalPredicateURI;
    }

    public String getCurrentPredicateURI() {
        return currentPredicateURI;
    }

    public double getEntityConfidence() {
        return entityConfidence;
    }

    public ClientEntity getOriginalEntity() {
        return originalEntity;
    }

    public ClientEntity getCurrentEntity() {
        return currentEntity;
    }

    public List<Article> getOriginalArticles() {
        return originalArticles;
    }

    public List<Article> getCurrentArticles() {
        return currentArticles;
    }

    public String getIgnoreReason() {
        return ignoreReason;
    }

    public void setIgnoreReason(String ignoreReason) {
        this.ignoreReason = ignoreReason;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
