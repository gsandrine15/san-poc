package com.trss.bi.config.dbmigrations.risktaxonomy;

import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

public class ProductFaultsHelper {

    private static final String BASE_URI = "http://graph.mediascreener.com/facttype/productfaults";

    public static void create(MongoTemplate mongoTemplate) {
        TaxonomySetupHelper helper = new TaxonomySetupHelper(mongoTemplate);
        TaxonomyNode rootNode = helper.findRootNode();

        TaxonomyNode productFaults = helper.insertNode(rootNode, BASE_URI, "PRODUCT_FAULTS", "Product Faults",
            "This is product faults");

        // insert all the children
        helper.insertNode(productFaults, BASE_URI + "/productrecall", "PRODUCT_RECALL", "Product Recall",
            "This is product recall");

        helper.insertNode(productFaults, BASE_URI + "/productscandal", "PRODUCT_SCANDAL", "Product Scandal",
            "This is product scandal");
    }
}
