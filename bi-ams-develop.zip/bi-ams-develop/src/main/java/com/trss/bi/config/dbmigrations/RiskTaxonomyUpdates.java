package com.trss.bi.config.dbmigrations;

import com.github.mongobee.changeset.ChangeLog;
import com.github.mongobee.changeset.ChangeSet;
import com.trss.bi.config.dbmigrations.risktaxonomy.TaxonomyMayUpdatesConfig;
import com.trss.bi.domain.alert.Alert;
import com.trss.bi.domain.fact.Fact;
import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.domain.taxonomy.TaxonomyNode;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.List;

@ChangeLog(order = "005")
public class RiskTaxonomyUpdates {

    private String getNewUri(String oldUri) {
        return TaxonomyMayUpdatesConfig.URI_MAP.get(oldUri);
    }

    @ChangeSet(order = "01", author = "admin", id = "005-01-update-uris")
    public void updateUris(MongoTemplate mongoTemplate) {
        // update the taxonomy nodes themselves
        List<TaxonomyNode> taxonomyNodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : taxonomyNodes) {
            if (!node.isRoot()) {
                String newUri = getNewUri(node.getUri());
                if (newUri != null && newUri.length() > 0) {
                    node.setUri(newUri);
                    mongoTemplate.save(node);
                } else {
                    System.out.println("[TaxonomyNode] No New URI found for node: " + node.getUri());
                }
            }
        }

        // update the fact instances
        List<FactInstance> factInstances = mongoTemplate.findAll(FactInstance.class);
        for (FactInstance factInstance : factInstances) {
            if (factInstance.getRiskTaxonomyNodeId() != null) {
                String newUri = getNewUri(factInstance.getRiskTaxonomyNodeId());
                if (newUri != null && newUri.length() > 0) {
                    factInstance.setRiskTaxonomyNodeId(newUri);
                    mongoTemplate.save(factInstance);
                } else {
                    System.out.println("[FactInstance] No New URI found for node: " + factInstance.getRiskTaxonomyNodeId());
                }
            }
        }

        // update the facts
        List<Fact> facts = mongoTemplate.findAll(Fact.class);
        for (Fact fact : facts) {
            if (fact.getRiskTaxonomyNodeId() != null) {
                String newUri = getNewUri(fact.getRiskTaxonomyNodeId());
                if (newUri != null && newUri.length() > 0) {
                    fact.setRiskTaxonomyNodeId(newUri);
                    mongoTemplate.save(fact);
                } else {
                    System.out.println("[Fact] No New URI found for node: " + fact.getRiskTaxonomyNodeId());
                }
            }
        }

        // update the alerts
        List<Alert> alerts = mongoTemplate.findAll(Alert.class);
        for (Alert alert : alerts) {
            for (FactInstance factInstance : alert.getFactInstances()) {
                if (factInstance.getRiskTaxonomyNodeId() != null) {
                    String newUri = getNewUri(factInstance.getRiskTaxonomyNodeId());
                    if (newUri != null && newUri.length() > 0) {
                        factInstance.setRiskTaxonomyNodeId(newUri);
                    } else {
                        System.out.println("[Alert.FactInstance] No New URI found for node: " + factInstance.getRiskTaxonomyNodeId());
                    }
                }
            }
            mongoTemplate.save(alert);
        }
    }

    @ChangeSet(order = "02", author = "admin", id = "005-02-update-politically_exposed_person")
    public void updatePoliticallyExposedPerson(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> taxonomyNodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : taxonomyNodes) {
            if (!node.isRoot() && node.getUri().equals("https://graph.thomsonreuters.com/fact_type/risk/political/politically_exposed_person")) {
                node.setDisplayName("Politically Exposed Person");
                mongoTemplate.save(node);
            } else {
                System.out.println("No taxonomy node for https://graph.thomsonreuters.com/fact_type/risk/political/politically_exposed_person");
            }
        }
    }

    @ChangeSet(order = "03", author = "admin", id = "005-03-update-racketeering")
    public void updateRacketeering(MongoTemplate mongoTemplate) {
        List<TaxonomyNode> taxonomyNodes = mongoTemplate.findAll(TaxonomyNode.class);
        for (TaxonomyNode node : taxonomyNodes) {
            if (!node.isRoot() && node.getUri().equals("https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/organized_crime/racket")) {
                node.setDisplayName("Racketeering");
                node.setCode("RACKETEERING");
                mongoTemplate.save(node);
            } else {
                System.out.println("No taxonomy node for https://graph.thomsonreuters.com/fact_type/risk/non-corporate_crime/organized_crime/racket");
            }
        }
    }
}
