package com.trss.bi.service.dto.feedback;

/**
 * Represents an entity matcher feedback payload.
 */
public class EntityMatcherFeedbackDTO {

    protected String trssFeedRouterId;
    protected String msFactId;
    protected EntityMatcherFeedbackItemDTO feedback;

    public String getTrssFeedRouterId() {
        return trssFeedRouterId;
    }

    public void setTrssFeedRouterId(String trssFeedRouterId) {
        this.trssFeedRouterId = trssFeedRouterId;
    }

    public String getMsFactId() {
        return msFactId;
    }

    public void setMsFactId(String msFactId) {
        this.msFactId = msFactId;
    }

    public EntityMatcherFeedbackItemDTO getFeedback() {
        return feedback;
    }

    public void setFeedback(EntityMatcherFeedbackItemDTO feedback) {
        this.feedback = feedback;
    }

    @Override
    public String toString() {
        return "EntityMatcherFeedbackDTO{" +
            "trssFeedRouterId='" + trssFeedRouterId + '\'' +
            ", msFactId='" + msFactId + '\'' +
            ", feedback=" + feedback +
            '}';
    }
}
