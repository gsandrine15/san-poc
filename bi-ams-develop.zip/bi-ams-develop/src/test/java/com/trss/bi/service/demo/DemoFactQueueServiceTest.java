package com.trss.bi.service.demo;

import com.trss.bi.service.FactQueueService;
import com.trss.bi.service.FeedItemService;
import com.trss.bi.service.dto.FactQueueDTO;
import com.trss.bi.service.dto.FeedItemDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for the DemoFactQueueService class
 *
 * @see DemoFactQueueService
 */
@RunWith(MockitoJUnitRunner.class)
public class DemoFactQueueServiceTest {
    // mock service
    @Mock
    private FactQueueService factQueueService;
    @Mock
    private FeedItemService feedItemService;

    // mock variables
    @Mock
    private FactQueueDTO factQueueDTO;

    // argument captors
    @Captor
    private ArgumentCaptor<FeedItemDTO> feedItemDTOArgumentCaptor;


    // class being tested
    @InjectMocks
    private DemoFactQueueService demoFactQueueService;

    @Test(expected = RuntimeException.class)
    public void testLoadDemoQueue_noFactQueueDTOFound_throwsRuntimeException() {
        when(factQueueService.findByName(anyString())).thenReturn(null);
        demoFactQueueService.loadDemoQueue("wont find me");
    }

    @Test
    public void testLoadDemoQueue_factQueueDTOFound_loadsFeedItemsAndReturnsId() {
        // variables used for verification
        String fqci = "fqci";
        List<String> expectedFactQueueConfigIds = Arrays.asList(fqci);

        // setup mock behavior
        when(factQueueService.findByName(anyString())).thenReturn(factQueueDTO);
        when(factQueueDTO.getFactQueueConfigId()).thenReturn(fqci);
        doNothing().when(feedItemService).loadFeedItem(any(FeedItemDTO.class));

        // execute method under test
        demoFactQueueService.loadDemoQueue("finds me");

        verify(factQueueDTO, atLeastOnce()).getFactQueueConfigId();
        // capture the arguments
        assertTrue(true);
        verify(feedItemService, times(4)).loadFeedItem(feedItemDTOArgumentCaptor.capture());

        // verify capture
        FeedItemDTO feedItemDTO = feedItemDTOArgumentCaptor.getValue();
        assertEquals(expectedFactQueueConfigIds, feedItemDTO.getMatchingFactQueueConfigIds());
        assertEquals(expectedFactQueueConfigIds, feedItemDTO.getMatchCandidates().get(0).getFactQueueConfigIds());
    }
}
