package com.trss.bi.service;

import com.trss.bi.domain.factinstance.FactInstance;
import com.trss.bi.repository.FactFeedbackRepository;
import com.trss.bi.repository.FactInstanceRepository;
import com.trss.bi.repository.FactRepository;
import com.trss.bi.repository.HistoricalFactInstanceRepository;
import com.trss.bi.service.dto.FactInstanceFilterDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for the FactInstanceService class
 *
 * @see FactInstanceService
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class FactInstanceServiceTest {

    // mock repositories
    @Mock
    private FactInstanceRepository factInstanceRepository;
    @Mock
    private HistoricalFactInstanceRepository historicalFactInstanceRepository;
    @Mock
    private FactRepository factRepository;
    @Mock
    private FactFeedbackRepository factFeedbackRepository;

    // mocked objects
    @Mock
    private Pageable pageable;
    @Mock
    private Sort sort;
    @Mock
    private Iterator<Sort.Order> orderIterator;
    @Mock
    private Sort.Order order;

    // mock mongo template
    @Mock
    private MongoTemplate mongoTemplate;

    @Captor
    private ArgumentCaptor<Query> queryCaptor;

    // class being tested
    @InjectMocks
    private FactInstanceService factInstanceService;

    private List<FactInstance> factInstances = new ArrayList<>();

    // must be 24 length hex
    private static final String FACT_QUEUE_ID = "aaaaaaaaaaaaaaaaaaaaaaaa";

    @Before
    public void setup() {
        when(pageable.getSort()).thenReturn(sort);
        when(sort.iterator()).thenReturn(orderIterator);
        when(orderIterator.hasNext()).thenReturn(false);
    }

    @Test
    public void testFindFactInstances_noFiltersOrSortSpecified() {
        factInstanceService.findFactInstances(pageable, FACT_QUEUE_ID, new FactInstanceFilterDTO());

        verify(mongoTemplate).find(any(Query.class), eq(FactInstance.class));
        verify(mongoTemplate).count(queryCaptor.capture(), eq(FactInstance.class));
        Query query = queryCaptor.getValue();
        assertEquals(-1, query.getLimit());
        assertEquals(-1, query.getSkip());
    }

    @Test
    public void testFindFactInstances_noFiltersSortByDayConfidence() {
        when(pageable.getPageNumber()).thenReturn(0);
        when(pageable.getPageSize()).thenReturn(20);
        when(orderIterator.hasNext()).thenReturn(true, false);
        when(orderIterator.next()).thenReturn(order);
        when(sort.getOrderFor("day-confidence")).thenReturn(order);
        when(order.getDirection()).thenReturn(Sort.Direction.ASC);

        factInstanceService.findFactInstances(pageable, FACT_QUEUE_ID, new FactInstanceFilterDTO());

        verify(mongoTemplate).find(queryCaptor.capture(), any(Class.class));
        Query query = queryCaptor.getValue();
        assertThat(query.getSortObject().toString(), containsString("sent_date_details.year"));
        assertThat(query.getSortObject().toString(), containsString("sent_date_details.day"));
        assertThat(query.getSortObject().toString(), containsString("selectedClientEntity.confidenceScore"));

        verify(mongoTemplate).count(queryCaptor.capture(), eq(FactInstance.class));
        query = queryCaptor.getValue();
        assertEquals(-1, query.getLimit());
        assertEquals(-1, query.getSkip());
    }

}
